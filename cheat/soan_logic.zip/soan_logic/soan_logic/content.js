// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  // Chủ đề 1
  {
    question: "Câu 1. Cho các câu dưới đây, câu nào không phải là phán đoán?",
    answer: "A. a, f",
  },
  {
    question: "Câu 2. Các phán đoán đơn là:",
    answer: "A. 1, 2, 5, 6",
  },
  {
    question: "Câu 3. Trong các câu sau, câu nào không phải là phán đoán?",
    answer: "A. Buồn ngủ quá!",
  },
  {
    question: "Câu 4. Trong các câu sau, có bao nhiêu câu là phán đoán?",
    answer: "B. 3",
  },
  {
    question:
      "Câu 5. Cho mệnh đề “9 là số nguyên tố”, tìm mệnh đề phủ định của mệnh đề trên?",
    answer: "C. “9 không là số nguyên tố”",
  },
  {
    question: "Câu 6. Phán đoán có tính chất nào sau đây?",
    answer: "C. Đúng hoặc sai",
  },
  {
    question:
      "Câu 7. Cho phán đoán P là “Hùng khéo tay”. Khi đó, phán đoán “¬P” được diễn giải bằng lời như sau:",
    answer: "B. Hùng không khéo tay",
  },
  {
    question: "Câu 8. Tìm phán đoán sai trong các phán đoán sau:",
    answer: "D. 10 là số nguyên tố và là số tự nhiên nhỏ nhất có 2 chữ số",
  },
  {
    question: "Câu 9. Trong các câu sau, có bao nhiêu câu là phán đoán?",
    answer: "C. 3",
  },
  {
    question: "Câu 10. Chọn phán đoán đúng",
    answer: "A. Số 23 là số nguyên tố",
  },
  {
    question: "Câu 11. Chọn phán đoán đúng:",
    answer: "D. Nguyễn Đình Chiểu là tác giả của Truyện Lục Vân Tiên",
  },
  {
    question: "Câu 12. Chọn phán đoán đúng:",
    answer:
      "D. Số 1,234234…234… (vô hạn lần số 234 lặp lại ở phần thập phân) là số vô tỷ",
  },
  {
    question: "Câu 13. Chọn khẳng định đúng trong các câu sau:",
    answer: "B. Quả đất quay quanh mặt trời",
  },
  {
    question: "Câu 14. Chọn khẳng định đúng trong các câu sau:",
    answer: "C. Dây chì dẫn điện",
  },
  {
    question: "Câu 15. Chọn phán đoán sai:",
    answer: "A. Mây bay",
  },
  {
    question: "Câu 16. Chọn khẳng định đúng trong các câu sau:",
    answer: "B. “Không phải dây đồng dẫn điện” là phán đoán phủ định",
  },
  {
    question: "Câu 17. Câu nào sau đây là mệnh đề:",
    answer: "B. “n là số chẵn”",
  },
  // Chủ đề 2
  {
    question:
      "Câu 1. Xác định phép logic trong câu thơ sau:\n“Vừa tài sắc, lại nết na\nĐồng thời hiếu với mẹ cha sinh thành”",
    answer: "A. Phép hội",
  },
  {
    question:
      "Câu 2. Xác định phép logic trong câu thơ sau:\n“Một là cứ phép gia hình\nHai là phó mặc lầu xanh đi về”",
    answer: "B. Phép tuyển chặt",
  },
  {
    question:
      "Câu 3. Xác định phép logic trong câu thơ:\n“Áo chàng đỏ tựa ráng pha,\nNgựa chàng sắc trắng như là tuyết in.”",
    answer: "A. Phép hội",
  },
  {
    question:
      "Câu 4. Xác định phép logic trong phán đoán:\n“Khi một dân tộc đã đoàn kết nhất trí, đấu tranh giành độc lập tự do thì nhất định họ sẽ thắng lợi.”",
    answer: "C. Phép kéo theo",
  },
  {
    question:
      "Câu 5. Xác định phép logic trong phán đoán:\n“Hễ còn một tên xâm lược trên nước ta thì ta còn phải tiếp tục chiến đấu, quét sạch nó đi.”",
    answer: "C. Phép kéo theo",
  },
  {
    question:
      "Câu 6. Tìm phán đoán hội của 2 phán đoán: “Nam chăm chỉ” và “Nam học rất giỏi”?",
    answer: "A. Nam chăm chỉ và Nam học rất giỏi.",
  },
  {
    question: "Câu 7. Chọn phán đoán đúng:",
    answer: "D. Phép kéo theo P ⇒ Q chỉ sai khi P đúng và Q sai.",
  },
  {
    question:
      "Câu 8. Các dấu phẩy ở phán đoán sau có ý nghĩa của phép logic gì?\n“Vân Tiên đầu đội kim khôi, (1)\nTay cầm siêu bạc, (2) mình ngồi ngựa ô.”",
    answer: "B. (1) phép hội, (2) phép hội.",
  },
  {
    question:
      'Câu 9. Phát biểu phán đoán phản đảo của phán đoán kéo theo:\n"Khi tôi thức khuya cần phải để tôi ngủ đến trưa"',
    answer: "A. Nếu tôi không ngủ đến trưa thì tôi không thức khuya.",
  },
  {
    question:
      'Câu 10. Định lý "Nếu hai tam giác bằng nhau thì chúng có diện tích bằng nhau" được viết dưới dạng "điều kiện đủ" là:',
    answer:
      "A. Hai tam giác bằng nhau là điều kiện đủ để chúng có diện tích bằng nhau.",
  },
  {
    question:
      'Câu 11. Định lý "Nếu a = b thì a² = b²" được viết dưới dạng "điều kiện cần" là:',
    answer: "B. Để a² = b² điều kiện cần là a = b.",
  },
  {
    question:
      'Câu 12. Định lý "Nếu A… thì B" được viết dưới dạng "điều kiện cần" là:',
    answer: "C. B là điều kiện cần để có A.",
  },
  {
    question:
      "Câu 13: Phép tính logic nào cho giá trị đúng khi phán đoán P và Q có giá trị khác nhau?",
    answer: "D. Phép phủ định",
  },
  {
    question:
      'Câu 14. Phán đoán “Nếu ông ấy phạm tội thì ông ấy bị phạt tù” có thể viết dưới "điều kiện đủ" là:',
    answer: "D. Ông ấy phạm tội là điều kiện đủ để ông bị phạt tù.",
  },
  {
    question:
      'Câu 15. Phán đoán "Hùng ghét bóng đá nhưng thích nấu ăn" được viết dưới dạng công thức là:',
    answer: "C. ¬P ∧ ¬Q",
  },
  {
    question:
      'Câu 16. Phán đoán "Hùng vừa thích bóng đá vừa thích nấu ăn" được viết dưới dạng công thức là:',
    answer: "A. P ∧ ¬Q",
  },
  {
    question:
      'Câu 17. Phán đoán "Hùng thích bóng đá và nấu ăn hay Hùng ghét bóng đá nhưng thích nấu ăn" được viết dưới dạng công thức là:',
    answer: "A. (P ∧ Q) ∨ (¬P ∧ Q)",
  },
  {
    question:
      "Câu 18. Phán đoán “Tránh điều trách cứ, tránh câu giận hờn” có thể viết dưới dạng công thức:",
    answer: "C. ¬P ∧ ¬Q",
  },
  {
    question:
      "Câu 19. Phán đoán “Siêng thì muôn việc ở trong tay người” có thể viết dưới dạng công thức:",
    answer: "B. P ⇒ Q",
  },
  {
    question: 'Câu 20. Phán đoán "¬(P ∧ Q)" được diễn giải bằng lời như sau:',
    answer: "D. Hùng không khéo tay cũng không chăm chỉ.",
  },
  {
    question: "Câu 21. Tìm phán đoán hội trong các phán đoán sau:",
    answer: "A. Mưa to, gió lớn",
  },
  {
    question: "Câu 22. Tìm phán đoán tuyển trong các phán đoán sau:",
    answer: "B. 10 chia hết cho 5 hoặc 10 chia hết cho 2",
  },
  {
    question: "Câu 23. Tìm phán đoán hội trong các phán đoán sau:",
    answer: "B. Trời xanh, mây trắng",
  },
  {
    question: "Câu 24. Phán đoán nào là phép tuyển chặt:",
    answer:
      "C. Góp phần chống Covid 19 chúng ta hoặc phải đeo khẩu trang hoặc rửa tay sát khuẩn thường xuyên",
  },
  {
    question: "Câu 25. Phán đoán nào là phép tuyển không chặt:",
    answer:
      "A. Góp phần chống Covid 19 chúng ta phải đeo khẩu trang hoặc rửa tay sát khuẩn thường xuyên",
  },
  {
    question:
      "Câu 26. Liên từ logic “hay” ở phán đoán:\n“Tỷ lệ học sinh đậu tốt nghiệp là 76% hay 78%, có thể tìm trong báo Tuổi Trẻ hay báo Thanh Niên.”\nÝ nghĩa phép logic là:",
    answer: "D. (1) phép tuyển, (2) phép tuyển chặt",
  },
  {
    question:
      "Câu 27. Phán đoán “Khi mùa xuân đến những bông hoa đua nở” được viết dưới dạng công thức là:",
    answer: "B. P ⇒ Q",
  },
  {
    question:
      "Câu 28. Phán đoán “Mùa xuân đến và những bông hoa đua nở” được viết dưới dạng công thức là:",
    answer: "D. P ∧ Q",
  },
  {
    question:
      "Câu 29. Phán đoán “Những bông hoa đua nở báo hiệu mùa xuân đến” được viết dưới dạng công thức là:",
    answer: "D. Q ⇒ P",
  },
  {
    question:
      "Câu 30. Phán đoán “Anh ấy đi học hay đi làm đều bằng xe đạp” được viết dưới dạng công thức là:",
    answer: "D. (P ∨ Q)",
  },
  {
    question:
      "Câu 31. Phán đoán “Anh ấy đi học bằng xe đạp nhưng đi làm bằng xe máy” được viết dưới dạng công thức là:",
    answer: "C. P ∧ ¬Q",
  },
  {
    question:
      "Câu 32. Phán đoán “Lan thích cả múa và hát hay Lan thích múa mà không thích hát” được viết dưới dạng công thức là:",
    answer: "B. (P ∧ Q) ∨ (P ∧ ¬Q)",
  },
  {
    question: "Câu 33. Phán đoán phản đảo của “Đến rằm thì trăng tròn” là:",
    answer: "C. Trăng không tròn là chưa đến rằm",
  },
  {
    question: "Câu 34. Phán đoán phản đảo của “Có lửa thì có khói” là:",
    answer: "C. Không có khói thì không có lửa",
  },
  {
    question:
      "Câu 35. Phán đoán “Có lửa thì có khói” có thể viết dưới “điều kiện đủ” là:",
    answer: "A. Có lửa là điều kiện đủ để có khói",
  },
  {
    question:
      "Câu 36. Phán đoán phản đảo của: “Nếu hàm số f có đạo hàm tại x = a thì f liên tục tại x = a” là:",
    answer:
      "B. Nếu hàm số f không liên tục tại x = a thì f không có đạo hàm tại x = a",
  },
  {
    question:
      "Câu 37. Phán đoán “Chiều nay tôi sẽ đến thăm anh trừ phi Trời mưa” tương đương với:",
    answer: "A. Nếu Trời không mưa thì chiều nay tôi sẽ đến thăm anh.",
  },
  {
    question:
      "Câu 38. Phán đoán “Bệnh này không thể qua khỏi trừ phi có thuốc tiên” tương đương với:",
    answer: "A. Nếu không có thuốc tiên thì bệnh này không thể qua khỏi.",
  },
  {
    question:
      "Câu 39. Phán đoán “Không có sách thì không có tri thức” tương đương với công thức:",
    answer: "A. P ⇒ Q",
  },
  // Chủ đề 3
  {
    question: "Câu 1: Phủ định của phán đoán “Nó đi Vũng tàu hay Đà lạt” là:",
    answer: "A. Nó không đi Vũng tàu và cũng không đi Đà lạt.",
  },
  {
    question:
      "Câu 2: Lập mệnh đề phủ định của mệnh đề: “Số 6 chia hết cho 2 và 3”.",
    answer: "C. Số 6 không chia hết cho 2 hoặc 3.",
  },
  {
    question:
      "Câu 3: Phán đoán “Không phải nó vừa học đàn, vừa học bơi” có thể viết dưới dạng công thức:",
    answer: "A. ¬(P ∧ Q) = ¬P ∨ ¬Q",
  },
  {
    question: "Câu 4: Tìm phủ định của phán đoán (P ∧ Q) ⇒ R:",
    answer: "C. P ∧ Q ∧ ¬R",
  },
  {
    question:
      'Câu 5: Phán đoán "Không phải vì anh yêu em mà em đến đây" được viết dưới dạng công thức là:',
    answer: "C. ¬(Q ⇒ P) = Q ∧ ¬P",
  },
  {
    question: "Câu 6: Nếu x² − 5x + 6 ≠ 0 thì:",
    answer: "A. x ≠ 2 ∧ x ≠ 3",
  },
  {
    question: "Câu 7: Cho A = {x ∈ R | −2 ≤ x ≤ 3}, y ∉ A thì y có tính chất:",
    answer: "D. y ≤ −2 ∨ y ≥ 3",
  },
  {
    question:
      "Câu 8: Phủ định của phán đoán “Anh ấy không đi Hà Nội mà đi Thái Bình” là:",
    answer: "A. Anh ấy đi Hà Nội hoặc không đi Thái Bình.",
  },
  {
    question:
      'Câu 9: Phán đoán phủ định của phán đoán "Tôi không thể ngủ nếu tôi đói bụng" là:',
    answer: "A. Tôi đói bụng nhưng vẫn ngủ được.",
  },
  {
    question:
      'Câu 10: Phán đoán phủ định của phán đoán "Tuổi của Tuấn khoảng từ 15 đến 20" là:',
    answer: "A. Tuổi của Tuấn hoặc dưới 15 hoặc trên 20.",
  },
  {
    question:
      'Câu 11: Phán đoán phủ định của phán đoán "Nếu ngày mai là thứ tư thì hôm nay phải là thứ hai" là:',
    answer: "A. Hôm nay không phải là thứ hai và ngày mai là thứ tư.",
  },
  {
    question:
      "Câu 12: Phán đoán phủ định của phán đoán “Đến rằm thì trăng tròn” là:",
    answer: "A. Đến rằm mà trăng vẫn không tròn.",
  },
  {
    question:
      "Câu 13: Phán đoán phủ định của phán đoán “Có lửa thì có khói” là:",
    answer: "A. Có lửa mà không có khói.",
  },
  {
    question:
      "Câu 14: Phán đoán phủ định của phán đoán “Hôm nay là ngày Chủ nhật hay hôm nay là ngày lễ” là:",
    answer: "B. Hôm nay không phải là ngày Chủ nhật và ngày lễ.",
  },
  {
    question: "Câu 15: Nếu x² − 4x + 3 ≠ 0 thì:",
    answer: "A. x ≠ 1 ∧ x ≠ 3",
  },
  {
    question: "Câu 16: Phủ định phán đoán: “Hôm nay tôi học Toán và logic”",
    answer: "A. Hôm nay tôi không học toán hay logic.",
  },
  {
    question: "Câu 17: Nếu y ∉ {x ∈ R | 1 < x < 3} thì y có tính chất:",
    answer: "A. y ≤ 1 ∨ y ≥ 3",
  },
  {
    question: "Câu 18: Nếu x² − 5x + 4 ≠ 0 thì:",
    answer: "A. x ≠ 1 ∧ x ≠ 4",
  },
  {
    question:
      "Câu 19: Phủ định phán đoán: “Em bé 5 tuổi biết đọc thông thạo và viết văn trôi chảy” là:",
    answer:
      "B. Em bé 5 tuổi không thể biết đọc thông thạo hay viết văn trôi chảy được.",
  },
  {
    question:
      "Câu 20: Phán đoán: “Trước, sau nào thấy bóng người” tương đương với phán đoán:",
    answer: "A. Trước không có người và sau cũng không có người.",
  },
  // Chủ đề 4
  {
    question:
      "Câu 1: Nhận định nào dưới đây vi phạm quy luật logic cấm mâu thuẫn?",
    answer:
      "A. Mọi loại xà phòng đều làm khô bạn, riêng chỉ có xà phòng Lux làm bạn trắng trẻo, mịn màng.",
  },
  {
    question:
      "Câu 2: Lý luận sau vi phạm quy luật logic nào? 'Bởi tất cả hàng hóa đều có giá trị sử dụng nên có thể khẳng định rằng mọi vật có giá trị sử dụng thì chắc chắn là hàng hóa'",
    answer: "A. Quy luật lý do đầy đủ",
  },
  {
    question:
      "Câu 3: Bạn B nói: 'Do cô ấy đẹp nên là học sinh xuất sắc'. Câu nói của bạn B vi phạm quy luật logic nào?",
    answer: "A. Quy luật lý do đầy đủ",
  },
  {
    question:
      "Câu 4: Nhận định: 'Tất cả giá cả hàng hoá trong nền kinh tế thị trường đều là biểu hiện bằng tiền của giá trị, tuy nhiên cũng có một số hàng hoá trong nền kinh tế đó không phải như vậy' vi phạm quy luật logic nào dưới đây?",
    answer: "B. Vi phạm quy luật mâu thuẫn",
  },
  {
    question:
      "Câu 5: Một sinh viên khẳng định: 'Bạn Nam đạt giải nhất với số điểm tuyệt đối trong kỳ thi sinh viên giỏi Toán của trường tôi. Chắc chắn bạn ấy sẽ đạt giải nhất trong kỳ thi học sinh giỏi toán toàn quốc lần này'. Vi phạm quy luật logic nào?",
    answer: "A. Quy luật lý do đầy đủ",
  },
  {
    question:
      "Câu 6: Tư tưởng “Có thương thì nói rằng thương. Không thương thì nói một đường cho xong” bị chi phối bởi quy luật logic nào?",
    answer: "C. Quy luật bài trung",
  },
  {
    question:
      "Câu 7: Nhận định “Thuốc này là thuốc tốt vì giá của nó rất cao.” vi phạm quy luật logic nào?",
    answer: "A. Quy luật lý do đầy đủ",
  },
  {
    question:
      "Câu 8: Câu hát: 'Nếu anh nói anh vẫn chưa yêu, thì thực ra anh đang dối mình; Còn anh nói anh đã trót yêu em rồi là dường như anh đang dối em' vi phạm quy luật logic nào?",
    answer: "C. Quy luật bài trung",
  },
  {
    question:
      "Câu 9: Cặp phán đoán “Người Việt Nam yêu nước” và “Người Việt Nam không yêu nước” bị chi phối bởi quy luật logic nào?",
    answer: "A. Quy luật bài trung và quy luật cấm mâu thuẫn",
  },
  {
    question: "Câu 10: Luật bài trung được thể hiện qua phán đoán nào sau đây?",
    answer:
      "D. “Có yêu thì yêu cho chắc, bằng như trúc trắc thì trục trặc cho luôn” (Ca dao)",
  },
  {
    question:
      "Câu 11: Hai mệnh đề: P: 'Tất cả sinh viên đều chăm học.' và Q: 'Một số sinh viên không chăm học.' có quan hệ gì với nhau?",
    answer: "B. Mâu thuẫn",
  },
  {
    question:
      "Câu 12: Xét hai mệnh đề: P: 'Nếu trời mưa thì tôi mang ô.' và Q: 'Trời mưa và tôi không mang ô.' P và Q có quan hệ gì?",
    answer: "B. Mâu thuẫn",
  },
  {
    question:
      "Câu 13: Cho ba phát biểu: Nếu trời mưa, đường sẽ trơn. Nếu đường trơn, xe sẽ khó chạy. Trời đang mưa. Kết luận nào sau đây là đúng?",
    answer: "A. Xe sẽ khó chạy.",
  },
  // Chủ đề 5
  {
    question:
      "Câu 1: Phủ định phán đoán sau: “Với mọi số tự nhiên n, 3n + 1 đều là số lẻ”",
    answer: "B. Có số tự nhiên n, 3n + 1 là số chẵn.",
  },
  {
    question: "Câu 2: Phủ định phán đoán sau: ∀x ∈ R, x² ≥ 0",
    answer: "D. ∃x ∈ R, x² < 0",
  },
  {
    question:
      "Câu 3: Phủ định phán đoán “Không ai tắm hai lần trong một dòng sông”",
    answer: "B. Có người tắm hai lần trong một dòng sông.",
  },
  {
    question: "Câu 4: Phủ định phán đoán “Mọi trẻ em đều mong Tết đến”",
    answer: "B. Một số trẻ em không mong Tết đến.",
  },
  {
    question: "Câu 5: Phán đoán ∀x, [P(x) ∨ Q(x)] có thể viết bằng câu sau:",
    answer:
      "B. Tất cả những sinh viên trong lớp đều đã đọc Truyện Kiều hoặc truyện Lục Vân Tiên.",
  },
  {
    question: "Câu 6: Phán đoán ∀x, P(x) ∧ ∃x, Q(x) có thể viết bằng câu sau:",
    answer:
      "A. Tất cả sinh viên trong lớp đọc Truyện Kiều nhưng một số bạn chưa đọc truyện Lục Vân Tiên.",
  },
  {
    question:
      'Câu 7: Mệnh đề nào sau đây là phủ định của mệnh đề "Mọi động vật đều di chuyển"?',
    answer: "C. Có ít nhất một động vật không di chuyển.",
  },
  {
    question:
      "Câu 8: Chọn phán đoán đúng về mệnh đề ∀x ∈ R, ∀y ∈ R: y < 3x − 2",
    answer: "D. ∀x ∈ R, ∀y ∈ R: y < 3x − 2",
  },
  {
    question: "Câu 9: Chọn phán đoán đúng",
    answer: "D. ∀x ∈ R, x² + 2x + 3 > 0",
  },
  {
    question:
      'Câu 10: Mệnh đề phủ định của "∃x ∈ R: x² + 2x + 5 là số nguyên tố" là:',
    answer: "C. ∀x ∈ R: x² + 2x + 5 là hợp số.",
  },
  {
    question: "Câu 11: Chọn phán đoán đúng",
    answer: "A. Một số người Việt Nam là nhà thơ.",
  },
  {
    question:
      "Câu 12: Cho p(x) = 3x − 7 là số nguyên tố, x ∈ Z. Chọn phán đoán đúng:",
    answer: "B. p(5)",
  },
  {
    question:
      "Câu 13: Phán đoán 'Có người Việt Nam được giải Nobel Văn học' viết là:",
    answer: "D. ∃x, p(x)",
  },
  {
    question:
      "Câu 14: Phán đoán ∀x, p(x), với p(x) = x thích mỡ, x là mèo có thể viết bằng lời:",
    answer: "D. Tất cả con mèo đều thích mỡ.",
  },
  {
    question:
      "Câu 15: Phán đoán “Trong Hội nghị không phải không có người tán thành ý kiến ấy” có thể viết là:",
    answer: "B. ∃x, p(x)",
  },
  {
    question:
      "Câu 16: Phát biểu lại: “Không phải tất cả những người hay cười là những người hạnh phúc” tương đương với:",
    answer: "B. Có những người hay cười là những người không hạnh phúc.",
  },
  {
    question:
      "Câu 17: Tìm phán đoán phủ định của phán đoán “Lúc nào cũng cần nói đúng sự thật”",
    answer: "D. Có lúc không cần nói đúng sự thật.",
  },
  {
    question: "Câu 18: Phán đoán phủ định của “∀x ∈ R, x² − 2x + 111 = 0” là:",
    answer: "A. ∃x ∈ R, x² − 2x + 111 ≠ 0",
  },
  {
    question: "Câu 19: Phán đoán phủ định của “∃x ∈ R, x² − 2x + 1 ≥ 0” là:",
    answer: "A. ∀x ∈ R, x² − 2x + 1 < 0",
  },
  {
    question:
      "Câu 20: Phán đoán “∃n ∈ N: (n² + 13n + 1)/(2n + 1) ∈ Z” phủ định là:",
    answer: "C. ∀n ∈ N: (n² + 13n + 1)/(2n + 1) ∉ Z",
  },
  {
    question:
      "Câu 21: Phán đoán “Trong lớp không phải không có sinh viên đồng ý với ý kiến” viết là:",
    answer: "B. ∃x, p(x)",
  },
  {
    question:
      "Câu 22: Phủ định phán đoán: “Không một ai muốn nghèo đói hoặc bệnh tật”",
    answer: "C. ∃x ∈ S, P(x) ^ ∃x ∈ S, Q(x)",
  },
  // Chủ đề 6
  {
    question:
      "Câu 1: Phán đoán “Mọi sinh viên khoa Ngoại ngữ sẽ học tất cả các môn của khoa Ngoại ngữ” có thể viết dưới dạng công thức là:",
    answer: "C. ∀x ∈ S, ∀y ∈ T, P(x, y)",
  },
  {
    question:
      "Câu 2: Phán đoán “Có sinh viên khoa Ngoại ngữ không học tất cả các môn của khoa Ngoại ngữ” có thể viết dưới dạng công thức là:",
    answer: "D. ∃x ∈ S, ∃y ∈ T, ¬P(x, y)",
  },
  {
    question:
      "Câu 3: Phán đoán “Có sinh viên khoa Ngoại ngữ học một số môn của khoa Ngoại ngữ” có thể viết dưới dạng công thức là:",
    answer: "B. ∃x ∈ S, ∃y ∈ T, P(x, y)",
  },
  {
    question:
      "Câu 4: Phán đoán “Mọi sinh viên trong lớp đều biết bạn lớp trưởng An” viết dưới dạng công thức:",
    answer: "D. ∀x ∈ S, P(x, An)",
  },
  {
    question:
      "Câu 5: Phán đoán “Lan biết Thu mà Thu không biết Lan” viết dưới dạng công thức:",
    answer: "B. P(Lan, Thu) ∧ ¬P(Thu, Lan)",
  },
  {
    question:
      "Câu 6: Phán đoán “Mọi sinh viên trong lớp đều biết nhau” viết dưới dạng công thức:",
    answer: "C. ∀x ∈ S, ∀y ∈ S, P(x, y)",
  },
  {
    question: "Câu 7: Cho x, y ∈ R, P(x, y) = x + y = 3. Chọn phán đoán đúng:",
    answer: "D. ∃x, ∃y, P(x, y)",
  },
  {
    question: "Câu 8: Cho x, y ∈ R, P(x, y) = x + y = 3. Chọn phán đoán sai:",
    answer: "C. ∀x, ∀y, P(x, y)",
  },
  {
    question:
      "Câu 9: Câu “Mọi chàng trai đều yêu các cô gái” có thể diễn tả bằng công thức:",
    answer: "C. ∀x ∈ A, ∀y ∈ B, ¬P(x, y)",
  },
  {
    question:
      "Câu 10: Câu “Có những con mèo mà mọi con chó đều ngưỡng mộ” có thể diễn tả bằng công thức:",
    answer: "B. ∃y ∈ B, ∀x ∈ A, P(x, y)",
  },
  {
    question:
      "Câu 11: Phủ định của phán đoán “Có những con chó mà mọi con mèo đều ngưỡng mộ” là:",
    answer: "A. Có những con mèo không ngưỡng mộ mọi con chó.",
  },
  {
    question:
      "Câu 12: Phán đoán “Một số chìa khóa mở được mọi ổ khóa” có công thức:",
    answer: "A. ∃x ∈ S, ∀y ∈ T, P(x, y)",
  },
  {
    question:
      "Câu 13: Viết phán đoán “Một số người không yêu ai cả” dưới dạng công thức:",
    answer: "D. ∃x ∈ S, ∀y ∈ S, ¬P(x, y)",
  },
  {
    question:
      "Câu 14: Viết phán đoán “Có người yêu tất cả mọi người” dưới dạng công thức:",
    answer: "B. ∃x ∈ S, ∀y ∈ S, P(x, y)",
  },
  // Chủ đề 7
  {
    question:
      "Câu 1: Xét xem lập luận sau có hợp logic không? “Nếu không phải An và Bình đã đến đúng giờ thì An không đến đúng giờ hay Bình không đến đúng giờ.”",
    answer: "A. Hợp logic vì tuân theo quy tắc",
  },
  {
    question:
      "Câu 2: Xét lập luận: “Nếu ở lớp học có bạn hay ở thư viện có bạn đều chẳng phải, thì ở lớp học không có bạn và ở thư viện cũng không có bạn.”",
    answer: "A. Hợp logic vì tuân theo quy tắc",
  },
  {
    question:
      "Câu 3: “Tôi không đi Đà Lạt và tôi cũng không đi Vũng Tàu. Vậy nghĩa là tôi đi Đà Lạt hay tôi đi Vũng Tàu đều không đúng.”",
    answer: "A. Hợp logic vì tuân theo quy tắc",
  },
  {
    question:
      "Câu 4: Sinh viên không được vừa học vừa sử dụng điện thoại. Vậy sinh viên không học hoặc không sử dụng điện thoại.",
    answer: "A. Hợp logic vì tuân theo quy tắc",
  },
  {
    question:
      "Câu 5: Từ tiền đề “Nếu đi xe máy thì phải đội mũ bảo hiểm”, kết luận hợp logic được rút ra là:",
    answer: "A. Không đi xe máy hoặc phải đội mũ bảo hiểm.",
  },
  {
    question:
      "Câu 6: Từ tiền đề “Tôi không thể vừa học vừa làm”, kết luận hợp logic được rút ra là:",
    answer: "B. Tôi không học hoặc không làm.",
  },
  {
    question:
      "Câu 7: Nếu bạn đi học bằng xe máy thì hãy mang theo bằng lái xe. Vậy nếu bạn không mang theo bằng lái xe thì bạn không nên đi học bằng xe máy. Suy luận trên có hợp logic không?",
    answer: "A. Hợp logic vì dùng quy tắc Modus Tollens",
  },
  {
    question:
      "Câu 8: Nếu vi phạm nội quy phòng thi thì thí sinh bị hủy bài thi. Kết luận hợp logic được rút ra là:",
    answer: "B. Không vi phạm nội quy phòng thi hoặc bị hủy bài thi.",
  },
  {
    question:
      "Câu 9: Nếu trời mưa thì đường ướt. Mà đường không bị ướt. Suy luận hợp logic là:",
    answer: "B. Trời không mưa (Modus Tollens)",
  },
  {
    question:
      "Câu 10: Nếu học hỏi thì là người có tri thức, nếu là người có tri thức thì phải trung thực. Mà anh ta không trung thực.",
    answer: "A. Vậy anh ta không học hỏi.",
  },
  {
    question: "Câu 11: Tôi suy nghĩ, vậy tôi tồn tại (Rene Descartes).",
    answer: "A. Lập luận hợp logic vì dùng sơ đồ Modus Ponens",
  },
  {
    question:
      "Câu 12: Anh ấy là một người trung thực, có thể tin anh ấy. Lập luận rút gọn này tuân theo quy tắc nào?",
    answer: "A. Quy tắc Modus Ponens",
  },
  {
    question:
      "Câu 13: Nếu mùa Hạ thì có hoa sen nở. Mà khi hoa sen nở thì có thể nghe tiếng ve. Vậy nếu mùa Hạ thì có thể nghe tiếng ve.",
    answer: "B. Lập luận hợp logic vì dùng quy tắc bắc cầu của phép kéo theo.",
  },
  {
    question:
      "Câu 14: Nếu trường không có cơ sở vật chất tốt mà có chất lượng giáo dục tốt thì trường phải có thầy giáo tốt.",
    answer: "D. Lập luận hợp logic vì dùng quy tắc Modus Tollens",
  },
  {
    question:
      "Câu 15: Khi tôi thức khuya thì tôi ngủ đến trưa. Vậy suy luận hợp logic là:",
    answer: "C. Nếu tôi không ngủ đến trưa thì tôi không thức khuya.",
  },
  // Chủ đề 8
  {
    question:
      "Câu 1: Lập luận sau có hợp logic không: “Nếu cúp điện thì đèn không sáng. Mà hiện tại đèn không sáng. Vậy, điện đã bị cúp.”",
    answer: "A. Lập luận không hợp logic vì dùng sơ đồ P ⇒ Q, Q ⇒ P",
  },
  {
    question:
      "Câu 2: Xét xem lập luận sau có hợp logic không? “Hai tam giác bằng nhau thì có diện tích bằng nhau. Vậy, hai tam giác có diện tích bằng nhau thì bằng nhau.”",
    answer: "A. Lập luận không hợp logic vì dùng sơ đồ P ⇒ Q, Q ⇒ P",
  },
  {
    question:
      "Câu 3: Xét xem lập luận sau có hợp logic không? “Nếu bạn vượt đèn đỏ thì bạn phạm luật giao thông. Mà bạn vượt đèn đỏ. Vậy, bạn phạm luật giao thông.”",
    answer: "C. Lập luận hợp logic vì dùng sơ đồ P ⇒ Q, P ⟹ Q",
  },
  {
    question:
      "Câu 4. Xét xem lập luận sau có hợp logic không? “Nếu hai góc đối đỉnh thì bằng nhau. Vậy, hai góc không đối đỉnh thì không bằng nhau.”",
    answer: "C. Lập luận không hợp logic vì dùng sơ đồ ~P ⇒ ~Q",
  },
  {
    question:
      "Câu 5: Xét xem lập luận sau có hợp logic không? “Nếu có dấu chân trên bờ biển thì có người đã đi qua đây. Mà sáng nay không có dấu chân nào cả. Vậy, sáng nay không có ai đến bờ biển này.”",
    answer: "B. Lập luận hợp logic vì dùng sơ đồ: ~Q ⇒ ~P",
  },
  {
    question:
      "Câu 6: Xét xem lập luận sau có hợp logic không? “Nếu mùa xuân thì hoa mai nở. Vậy, bây giờ không phải mùa xuân.”",
    answer: "C. Lập luận không hợp logic vì dùng sơ đồ: ~P ⇒ ~Q",
  },
  {
    question:
      "Câu 7: Lập luận sau tuân theo sơ đồ nào: “Nếu bạn không tham dự khóa học điều khiển xe hơi thì bạn không được cấp giấy phép lái xe hơi. Nếu bạn không được cấp giấy phép lái xe hơi thì bạn không được điều khiển xe hơi. Vậy, nếu bạn không tham dự khóa học điều khiển xe hơi thì bạn không được điều khiển xe hơi.”",
    answer: "D. Sơ đồ bắc cầu của phép kéo theo",
  },
  {
    question:
      "Câu 8: Lập luận sau tuân theo sơ đồ nào: “Nếu bạn qua sông thì bạn phải nhờ đò chở. Nếu nhờ đò chở thì bạn phải nghe theo sự hướng dẫn của người lái đò. Mà bạn lại qua sông. Vậy, bạn phải nghe theo sự hướng dẫn của người lái đò.”",
    answer: "D. Sơ đồ bắc cầu của phép kéo theo",
  },
  {
    question:
      "Câu 9: Xét xem lập luận sau có hợp logic không. “Nếu hôm nay là ngày Quốc tế lao động thì các công nhân không phải đi làm việc. Mà hôm nay đúng là ngày Quốc tế lao động. Vậy, các công nhân không phải đi làm việc.”",
    answer: "C. Lập luận hợp logic vì dùng sơ đồ modus ponens",
  },
  {
    question:
      "Câu 10: Xét xem lập luận sau có hợp logic không. “Nếu bạn dưới 18 tuổi thì bạn không được đăng ký kết hôn. Mà bạn dưới 18 tuổi.”",
    answer: "C. Lập luận hợp logic vì dùng sơ đồ modus ponens",
  },
  {
    question:
      "Câu 11: Xét xem lập luận sau có hợp logic không? “Số có tổng các chữ số chia hết cho 9 thì chia hết cho 9. Số 8154 có tổng chia hết cho 9 nên chia hết cho 9.”",
    answer: "C. Lập luận hợp logic vì dùng sơ đồ P ⇒ Q, P ⟹ Q",
  },
  {
    question:
      "Câu 12: Xét xem lập luận sau có hợp logic không? “Số chia hết cho 9 thì chia hết cho 3. Số 8154 chia hết cho 9 nên chia hết cho 3.”",
    answer: "C. Lập luận hợp logic vì dùng sơ đồ P ⇒ Q, P ⟹ Q",
  },
  {
    question:
      "Câu 13: Từ hai phán đoán tiền đề là P ∨ Q và ¬P, ta rút ra kết luận:",
    answer: "B. Q",
  },
  {
    question:
      "Câu 14: Từ hai phán đoán tiền đề là P ∨ Q và ¬Q, ta rút ra kết luận:",
    answer: "A. P",
  },
  {
    question:
      "Câu 15: Từ hai phán đoán tiền đề là ¬P ∨ Q và P, ta rút ra kết luận:",
    answer: "B. Q",
  },
  {
    question:
      "Câu 16: Xét xem lập luận sau có hợp logic không? “Nếu chiều thứ bảy mà Trời mưa thì chúng ta không đi cắm trại. Nếu chiều thứ bảy chúng ta không đi cắm trại thì sáng chủ nhật chúng ta đi sớm. Vậy thì nếu chiều thứ bảy trời mưa thì sáng chủ nhật chúng ta đi cắm trại sớm.”",
    answer: "B. Lập luận hợp logic vì dùng quy tắc bắc cầu của phép kéo theo",
  },
  {
    question:
      "Câu 17: Xét xem lập luận sau có hợp logic không? “Anh ấy nói anh ấy được nhận học bổng, do đó tôi nghĩ anh ấy học giỏi. Vì sinh viên học giỏi thì mới được nhận học bổng.”",
    answer: "A. Lập luận hợp logic vì dùng sơ đồ: P ⇒ Q, P ⟹ Q",
  },
  {
    question:
      "Câu 18: Xét xem lập luận sau có hợp logic không? “Nếu là con người mà khi ta nắm tay hắn, hắn thẹn thùng thì hắn là gái. Lúc nãy, khi nắm tay hắn nhảy qua bờ suối, mặt hắn thẹn thùng e ngại. Vậy hắn đích thực là gái giả trai đi tu rồi.”",
    answer: "B. Lập luận hợp logic vì dùng sơ đồ modus ponens",
  },
  {
    question:
      "Câu 19: Xét xem lập luận sau có hợp logic không? “Nếu số tự nhiên N chia hết cho 6 thì N chia hết cho 3.”",
    answer: "C. Lập luận hợp logic vì dùng sơ đồ P ⇒ Q",
  },
  {
    question:
      "Câu 20: Rút ra kết luận trong lập luận sau: “Nếu học hỏi thì là người có tri thức, nếu là người có tri thức thì phải trung thực. Mà anh ta không trung thực.”",
    answer: "A. Vậy anh ta không học hỏi.",
  },
  {
    question:
      "Câu 21: Cho biết phán đoán đã bị lược đi trong suy luận sau. “Nếu Trời mưa thì đường ướt. Mà đường không bị ướt.”",
    answer: "B. Trời không mưa",
  },
  {
    question:
      "Câu 22: Tìm lại phán đoán đã bị lược đi trong lập luận sau, và xét xem lập luận có hợp logic không. “Anh mà làm được việc ấy thì tôi đi bằng đầu.”",
    answer:
      "D. “Tôi không đi bằng đầu. Vậy anh không làm được việc ấy.”. Suy luận hợp logic.",
  },
  {
    question:
      "Câu 23: Xét xem lập luận sau có hợp logic không. “Hàng hóa tăng giá là do cung không đủ cầu hoặc do lạm phát. Nhưng vừa qua hàng hóa tăng giá không phải do cung không đủ cầu. Vậy hàng hóa tăng vừa qua là do lạm phát.”",
    answer: "A. Lập luận hợp logic vì dùng sơ đồ lựa chọn.",
  },
  {
    question:
      "Câu 24: Tìm lại phán đoán đã bị lược đi trong lập luận sau: “Tôi suy nghĩ, vậy tôi tồn tại” (Rene Descartes). Xét xem lập luận có hợp logic hay không.",
    answer:
      "A. Nếu tôi suy nghĩ thì tôi tồn tại. Lập luận hợp logic vì dùng sơ đồ modus ponens.",
  },
  {
    question:
      "Câu 25: Lập luận sau tuân theo quy tắc nào? “Năm học vừa rồi An không được xếp loại giỏi. Vì nếu được xếp loại giỏi thì điểm trung bình của An phải không dưới 8.0.”",
    answer: "D. A ⇒ B, ¬B ⟹ ¬A (Modus Tollens)",
  },
  {
    question:
      "Câu 26: Tìm lại các phán đoán đã được lược đi trong các suy luận rút gọn sau đây “Anh ấy là một người trung thực, có thể tin anh ấy.”",
    answer: "A. Nếu anh ấy là người trung thực thì có thể tin anh ấy.",
  },
  {
    question:
      "Câu 27: Lập luận rút gọn sau tuân theo quy tắc nào? “Anh ấy là một người trung thực, có thể tin anh ấy.”",
    answer: "A. Quy tắc Modus Ponens",
  },
  {
    question:
      "Câu 28: Xét xem đoạn lập luận sau có hợp logic hay không? “Nếu mùa Hạ thì có hoa sen nở. Mà khi hoa sen nở thì có thể nghe tiếng ve. Vậy, nếu mùa Hạ thì có thể nghe tiếng ve.”",
    answer: "B. Lập luận hợp logic vì dùng quy tắc bắc cầu của phép kéo theo.",
  },
  {
    question:
      "Câu 29: Xét xem đoạn lập luận sau có hợp logic hay không? “Nếu trường học không có thầy giáo tốt và không có cơ sở vật chất tốt thì không có chất lượng giáo dục tốt. Trường X không có cơ sở vật chất tốt mà có chất lượng giáo dục tốt. Vậy trường X có thầy giáo tốt.”",
    answer: "D. Lập luận hợp logic vì dùng quy tắc modus tollens.",
  },
  // Chủ đề 9
  {
    question:
      "Câu 1: Cho tam đoạn luận: “Mọi sinh viên khoa Công nghệ thông tin đều học Toán. Vậy mà ở trường Đại học DNTU có một số sinh viên không học Toán. Cho nên ở trường Đại học DNTU có một số sinh viên không phải là sinh viên khoa Công nghệ thông tin”. Mô hình hóa quan hệ giữa các thuật ngữ S, P, M của suy luận trên là:",
    answer: "D. P M   S M, S P",
  },
  {
    question:
      "Câu 2: Cho tam đoạn luận: “Mọi nhà thơ đều không phải là sinh viên lớp K19. Mọi người ở câu lạc bộ Tiếng thơ đều là nhà thơ. Vậy mọi người ở câu lạc bộ Tiếng Thơ không phải là sinh viên lớp K19”. Mô hình hóa quan hệ giữa các thuật ngữ S, P, M của suy luận trên là:",
    answer: "D. M P  M S, S P",
  },
  {
    question:
      "Câu 3: Từ hai phán đoán làm tiền đề là: “Mọi loài hoa cúc đều không có gai” và “Một số loài hoa nở vào mùa thu có gai”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "B. Một số loài hoa nở vào mùa thu không phải là hoa cúc.",
  },
  {
    question:
      "Câu 4: Từ hai phán đoán tiền đề là: “Mọi động vật dưới nước đều biết bơi” và “Một số loài Gấu không biết bơi”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "A. Một số loài Gấu không phải là động vật dưới nước.",
  },
  {
    question:
      "Câu 5: Cho tam đoạn luận rút gọn: “Vì một số người lao động là nông dân cho nên một số trí thức không là người lao động” Mô hình hóa quan hệ giữa các thuật ngữ S, P, M của suy luận trên là:",
    answer: "C. M S, S P",
  },
  {
    question:
      "Câu 6: Từ hai phán đoán làm tiền đề là: “Mọi sinh viên là người chăm học” và “Một số người chăm học không phải là người thông minh”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "B. Một số sinh viên không phải là người thông minh.",
  },
  {
    question:
      "Câu 7: Xác định sơ đồ chuẩn của tam đoạn luận sau: “Tất cả người Việt nam đều yêu nước. Mọi người yêu nước đều yêu hòa bình. Vậy mọi người Việt Nam đều yêu hòa bình”.",
    answer: "B. S M, M P ⟹ S P",
  },
  {
    question:
      "Câu 8: Cho tam đoạn luận: “Ong là loài côn trùng. Ong có ích. Vậy một số loài côn trùng có ích”. Mô hình hóa quan hệ giữa các thuật ngữ S, P, M của suy luận trên là:",
    answer: "D. M S, S P",
  },
  {
    question:
      "Câu 9. Từ hai phán đoán làm tiền đề là: “Mọi người yêu nước đều yêu hòa bình” và “Mọi người yêu hòa bình tham gia các phong trào làm từ thiện”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "A. Mọi người yêu nước đều tham gia các phong trào làm từ thiện.",
  },
  {
    question:
      "Câu 10: Từ hai phán đoán làm tiền đề là: “Mọi động vật ăn thịt đều hung dữ” và “Một số loài mèo không hung dữ”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "B. Một số loài mèo không là động vật ăn thịt.",
  },
  {
    question:
      "Câu 11. Từ hai phán đoán làm tiền đề là: “Mọi hình chữ nhật đều là hình bình hành” và “Một số hình thoi là hình chữ nhật”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "C. Một số hình thoi là hình bình hành.",
  },
  {
    question:
      "Câu 12. Từ hai phán đoán làm tiền đề là: “Hầu hết những người làm thơ có đọc Truyện Kiều” và “Mọi người đọc Truyện Kiều đều biết tiểu sử ông Nguyễn Du”. Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:",
    answer: "B. Một số người biết tiểu sử ông Nguyễn Du có làm thơ.",
  },
  {
    question:
      'Câu 13. Từ hai phán đoán làm tiền đề: "Mọi thi sĩ đều làm thơ" và "Một số người ở thành phố Hồ Chí Minh không biết làm thơ". Suy luận bằng cách dùng tam đoạn luận, kết luận được rút ra là:',
    answer: "A. Một số người ở thành phố Hồ Chí Minh không phải là thi sĩ.",
  },
  // Chủ đề 10
  {
    question:
      'Câu 1. Xét lập luận: "Vì (a − b)^2 ≥ 0 nên a^2 − 2ab + b^2 ≥ 0”. Các bạn hãy chọn mệnh đề đúng:',
    answer:
      "A. Luận đề là: a^2 − 2ab + b^2 ≥ 0, luận cứ là:  (a − b)^2 ≥ 0, luận chứng là luật đồng nhất.",
  },
  {
    question:
      "Câu 2. Xét lập luận: “Vì mọi cây hoa lài đều ra hoa màu trắng nên một số cây ra hoa màu trắng là cây hoa lài”. Chọn đáp án đúng.",
    answer:
      "A. Luận đề là: Một số cây có hoa màu trắng là hoa lài, luận cứ là: Mọi cây hoa lài đều ra hoa màu trắng, luận chứng là quy tắc từ cái chung rút ra cái riêng.",
  },
  {
    question:
      "Câu 3. Luận đề: số 57912 chia hết cho 3. Luận cứ: Số có tổng các chữ số chia hết cho 3 thì số đó chia hết cho 3. Chọn luận chứng đúng:",
    answer: "A. Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 4. Xét lập luận: Do 20 > 15 ; 15 > 10 nên 20 > 10. Chọn đáp án đúng:",
    answer: "C. Luận chứng: Quy luật bắc cầu.",
  },
  {
    question:
      "Câu 5. Xét lập luận: “Vì số 57912 có tổng các chữ số của nó chia hết cho 3. Nên số 57912 chia hết cho 3”. Chọn đáp án đúng.",
    answer: "A. Luận chứng: Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 6. Xét lập luận: “Vì số 57924 chia hết cho 9 nên nó chia hết cho 3”. Chọn đáp án đúng.",
    answer: "A. Luận chứng: Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 7. Xét lập luận: “Vì số 5792 có tận cùng là số chẵn nên nó chia hết cho 2”. Chọn đáp án đúng.",
    answer: "C. Luận chứng: Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 8. Xét lập luận: “Tứ giác ABCD là một hình thoi có hai đường chéo AC = BD nên tứ giác ABCD là hình vuông”. Chọn đáp án đúng.",
    answer: "A. Luận chứng: Quy tắc đồng nhất.",
  },
  {
    question: "Câu 9. Cho các số: 10, π, 5425, √2, e. Tìm các số vô tỷ.",
    answer: "A. π, √2, e",
  },
  {
    question:
      "Câu 10. Xét lập luận: “Vì số 5795 có tận cùng là số 5 nên nó chia hết cho 5”. Chọn đáp án đúng.",
    answer: "C. Luận chứng: Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 11. Xét lập luận: “Nếu một số chia hết cho 2 và 5 thì nó chia hết cho 10. Vì 5790 chia hết cho 2 và 5 nên 5790 chia hết cho 10”. Chọn đáp án đúng.",
    answer: "B. Luận chứng: Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 12. Xét lập luận: “Vì số 1234 không chia hết cho 2 nên nó là số lẻ”. Chọn đáp án đúng.",
    answer: "A. Luận chứng: Quy tắc modus ponens.",
  },
  {
    question:
      "Câu 13. Xét lập luận: “Vì mọi học sinh đều yêu quý thầy cô, mà Minh là học sinh nên Minh yêu quý thầy cô”. Chọn đáp án đúng.",
    answer: "C. Luận chứng: Từ cái chung suy ra cái riêng.",
  },
  {
    question:
      "Câu 14. Xét lập luận: “Vì (a + b)^2 = a^2 + 2ab + b^2 nên a^2 + 2ab + b^2 = (a + b)^2”. Chọn đáp án đúng.",
    answer: "A. Luận chứng: Quy tắc đồng nhất.",
  },
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
    // Xóa biểu tượng nếu có
    const iconPrevios = document.getElementById("textScannerIcon");
    if (iconPrevios) {
      iconPrevios.remove();
    }
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
