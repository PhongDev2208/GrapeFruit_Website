// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  
  { question: "Trong môi trường điện toán đám mây, dịch vụ nào cung cấp cơ sở dữ liệu dưới dạng dịch vụ (DBaaS)?", answer: "NoSQL" },
  { question: "Trong các hệ thống dữ liệu lớn (Big Data), mô hình cơ sở dữ liệu nào thường được sử dụng để xử lý dữ liệu phi cấu trúc?", answer: "Amazon RDS" },
  { question: "Trong Cơ sở dữ liệu phân tán, thuật toán nào được sử dụng để đảm bảo tính nhất quán giữa các node?", answer: "Two-Phase Commit (2PC)" },
  { question: "Trong Trí tuệ nhân tạo (AI), công nghệ nào giúp tối ưu hóa truy vấn cơ sở dữ liệu bằng cách học từ các mẫu dữ liệu trước đó?", answer: "Machine Learning" },
  { question: "Kỹ thuật nào giúp tối ưu hóa truy vấn bằng cách lưu trữ tạm thời các kết quả đã tính toán trước?", answer: "Caching" },
  { question: "Kiến trúc nào thường được sử dụng để mở rộng hệ thống cơ sở dữ liệu bằng cách phân chia dữ liệu thành nhiều phần trên các máy chủ khác nhau?", answer: "Sharding" },
  { question: "Cơ sở dữ liệu đa mô hình (Multi-Model Database) hỗ trợ lưu trữ và xử lý loại dữ liệu nào?", answer: "Cả dữ liệu có cấu trúc và phi cấu trúc" },
  { question: "Phương pháp nào được sử dụng để đảm bảo bảo mật dữ liệu trong cơ sở dữ liệu nâng cao?", answer: "Encryption" },
  { question: "Trong các hệ thống xử lý dữ liệu thời gian thực, yếu tố nào giúp đảm bảo khả năng phản hồi nhanh chóng?", answer: "In-Memory Processing" },
  { question: "Kỹ thuật nào giúp tăng tốc truy vấn bằng cách sử dụng cấu trúc dữ liệu đặc biệt để tìm kiếm nhanh hơn?", answer: "Indexing" },
  { question: "Trong tối ưu hóa kế hoạch thực thi truy vấn, hệ quản trị CSDL làm gì để cải thiện hiệu suất?", answer: "Chọn kế hoạch tối ưu dựa trên chi phí" },
  { question: "Kỹ thuật nào giúp chia nhỏ bảng dữ liệu lớn để tăng hiệu suất truy vấn và quản lý?", answer: "Partitioning" },
  { question: "Công nghệ nào thường được sử dụng để lưu trữ tạm thời dữ liệu và giảm tải truy vấn trực tiếp vào CSDL?", answer: "Redis" },
  { question: "Connection Pooling có tác dụng gì trong việc tối ưu hóa CSDL?", answer: "Giảm thời gian thiết lập kết nối" },
  { question: "Kỹ thuật nào giúp chia nhỏ dữ liệu và phân tán trên nhiều máy chủ để tăng khả năng xử lý?", answer: "Sharding" },
  { question: "Phương pháp nào giúp đảm bảo tính sẵn sàng của dữ liệu bằng cách sao chép dữ liệu trên nhiều node?", answer: "Replication" },
  { question: "Load Balancing trong hệ thống CSDL phân tán có tác dụng gì?", answer: "Phân phối đều tải giữa các node" },
  { question: "Trong kiến trúc CSDL nâng cao, yếu tố nào giúp cải thiện hiệu suất và đảm bảo hệ thống luôn hoạt động?", answer: "High Availability" },
  { question: "Trong môi trường cơ sở dữ liệu, đặc điểm nào giúp giảm thiểu sự lặp lại thông tin?", answer: "Normalization" },
  { question: "Môi trường cơ sở dữ liệu có đặc điểm gì quan trọng?", answer: "Tính nhất quán (Consistency)" },
  { question: "Trong hệ thống cơ sở dữ liệu, ai chịu trách nhiệm thiết kế mô hình dữ liệu?", answer: "Database Designer" },
  { question: "Người dùng cuối (End User) trong hệ thống cơ sở dữ liệu là ai?", answer: "Người sử dụng dữ liệu" },
  { question: "CSDL nâng cao hỗ trợ mô hình quan hệ và kết hợp nhiều loại dữ liệu nào?", answer: "Quan hệ, phi cấu trúc, đồ thị" },
  { question: "Hệ quản trị cơ sở dữ liệu nào thuộc nhóm CSDL quan hệ (RDBMS)?", answer: "PostgreSQL" },
  { question: "Hệ quản trị cơ sở dữ liệu nào thuộc nhóm Key-Value trong NoSQL Database?", answer: "Redis" },
  { question: "Mục đích của Query Optimization là gì?", answer: "Tăng tốc độ thực thi truy vấn" },
  { question: "Apache Spark có ưu điểm gì so với Hadoop MapReduce?", answer: "Xử lý trong bộ nhớ (In-Memory)" },
  { question: "Một ứng dụng phổ biến của Apache Spark là gì?", answer: "Phân tích dữ liệu lớn" },
  { question: "HDFS đảm bảo điều gì trong hệ thống lưu trữ dữ liệu lớn?", answer: "Tính chịu lỗi (Fault Tolerance)" },
  { question: "Kỹ thuật nào giúp giảm thời gian truy vấn bằng cách lưu trữ dữ liệu gần người dùng hơn?", answer: "Caching" },
  { question: "Trong hệ thống CSDL, khái niệm ACID đảm bảo điều gì?", answer: "Tính nhất quán và toàn vẹn dữ liệu" },
  { question: "Cơ chế nào giúp đảm bảo giao dịch trong CSDL phân tán?", answer: "Two-Phase Commit" },
  { question: "Trong NoSQL, mô hình nào phù hợp nhất với dữ liệu dạng đồ thị?", answer: "Graph Database" },
  { question: "Công nghệ nào thường được sử dụng để xử lý dữ liệu lớn trong thời gian thực?", answer: "Apache Kafka" },
  { question: "Kỹ thuật nào giúp giảm tải cơ sở dữ liệu bằng cách lưu trữ dữ liệu trung gian?", answer: "Materialized View" },
  { question: "Trong hệ thống phân tán, CAP Theorem bao gồm những yếu tố nào?", answer: "Consistency, Availability, Partition Tolerance" },
  { question: "Hệ CSDL nào phù hợp với dữ liệu dạng cột (Column-Family)?", answer: "Cassandra" },
  { question: "Trong tối ưu hóa CSDL, khái niệm Denormalization được sử dụng để làm gì?", answer: "Tăng tốc độ truy vấn" },
  { question: "Kỹ thuật nào giúp đảm bảo dữ liệu luôn có sẵn ngay cả khi một node bị lỗi?", answer: "Replication" },
  { question: "Trong hệ thống CSDL, Transaction Log có vai trò gì?", answer: "Ghi lại các thay đổi để phục hồi" },
  { question: "Công nghệ nào hỗ trợ truy vấn dữ liệu lớn bằng cách phân tích song song?", answer: "Apache Spark" },
  { question: "Trong hệ thống phân tán, Quorum được sử dụng để làm gì?", answer: "Đảm bảo tính nhất quân" },
  { question: "Kỹ thuật nào giúp giảm độ phức tạp khi truy vấn dữ liệu lớn?", answer: "Indexing" },
  { question: "Trong CSDL, Foreign Key đảm bảo điều gì?", answer: "Tính toàn vẹn tham chiếu" },
  { question: "Hệ quản trị CSDL nào hỗ trợ cả SQL và NoSQL?", answer: "Couchbase" },
  { question: "Trong Big Data, Data Lake được sử dụng để làm gì?", answer: "Lưu trữ dữ liệu thô đa dạng" },
  { question: "Kỹ thuật nào giúp cải thiện hiệu suất bằng cách giảm số lần truy cập đĩa?", answer: "In-Memory Database" },
  { question: "Trong hệ thống CSDL, Trigger có vai trò gì?", answer: "Tự động thực thi hành động" },
  { question: "Công nghệ nào thường được sử dụng để phân tích dữ liệu lớn theo thời gian thực?", answer: "Apache Flink" },
  { question: "CTE cải thiện hiệu suất truy vấn SQL bằng cách nào?", answer: "Lưu trữ tạm trong bộ nhớ" },
  { question: "CTE khác với bảng tạm truyền thống ở điểm nào về mặt lưu trữ?", answer: "Không ghi ra đĩa" },
  { question: "Khi nào CTE trở nên hữu ích nhất trong việc tối ưu hóa truy vấn?", answer: "Khi tái sử dụng biểu thức phức tạp" },
  { question: "CTE hỗ trợ tái sử dụng mã truy vấn bằng cách nào?", answer: "Định nghĩa biểu thức dùng lại" },
  { question: "Truy vấn đệ quy (Recursive Query) hoạt động dựa trên nguyên tắc nào?", answer: "Lập lại đến khi đạt điều kiện" },
  { question: "Công cụ nào thường được sử dụng để triển khai truy vấn đệ quy trong SQL?", answer: "CTE" },
  { question: "Truy vấn đệ quy thường được áp dụng cho loại dữ liệu nào trong quản lý tổ chức?", answer: "Dữ liệu phân cấp" },
  { question: "Truy vấn đệ quy có thể giải quyết vấn đề gì trong mạng xã hội?", answer: "Duyệt mối quan hệ bạn bè" },
  { question: "Trong một mạng lưới, truy vấn đệ quy có thể giúp tìm kiếm điều gì?", answer: "Đường đi ngắn nhất" },
  { question: "Truy vấn đệ quy hỗ trợ xây dựng báo cáo phức tạp bằng cách nào?", answer: "Tạo cấu trúc đệ quy" },
  { question: "Window Functions trong SQL Server được thiết kế để thực hiện tính toán như thế nào?", answer: "Trên tập dữ liệu con" },
  { question: "Window Functions cải thiện hiệu suất so với subquery bằng cách nào?", answer: "Tính toán cục bộ trên window" },
  { question: "Trong SQL, việc thao tác dữ liệu như chèn hoặc xóa được thực hiện thông qua cơ chế nào?", answer: "Các lệnh điều khiển dữ liệu" },
  { question: "Việc định nghĩa cấu trúc bảng trong SQL được thực hiện như thế nào?", answer: "Qua các lệnh tạo và sửa đổi cấu trúc" },
  { question: "Quyền truy cập vào cơ sở dữ liệu được kiểm soát bằng cách nào trong SQL?", answer: "Qua các lệnh cấp và thu hồi quyền" },
  { question: "Giao dịch trong SQL được quản lý như thế nào để đảm bảo tính toàn vẹn?", answer: "Qua các lệnh xác nhận và hoàn tác" },
  { question: "CTE kết hợp với truy vấn đệ quy có thể giải quyết vấn đề gì trong phân tích dữ liệu?", answer: "Xử lý dữ liệu phân cấp" },
  { question: "Truy vấn đệ quy có thể được áp dụng để duyệt qua cấu trúc nào trong hệ thống tệp?", answer: "Cây thư mục" },
  { question: "Window Functions có thể thay thế kỹ thuật nào để đơn giản hóa truy vấn phức tạp?", answer: "Subquery" },
  { question: "CTE giảm tải cho cơ sở dữ liệu bằng cách nào so với việc truy vấn trực tiếp?", answer: "Giảm truy cập ổ đĩa" },
  { question: "Truy vấn đệ quy có thể được sử dụng để quản lý danh mục sản phẩm như thế nào?", answer: "Xử lý danh mục con" },
  { question: "Window Functions thường được ứng dụng trong phân tích dữ liệu theo cách nào?", answer: "Phân tích theo cửa sổ dữ liệu" },
  { question: "CTE giúp tối ưu hóa truy vấn phức tạp bằng cách nào ngoài việc lưu trữ tạm?", answer: "Tải sử dụng biểu thức" },
  { question: "Truy vấn đệ quy có thể tạo danh sách dựa trên nguyên tắc nào?", answer: "Quy tắc đệ quy" },
  { question: "Việc chèn hoặc cập nhật dữ liệu trong SQL nhằm mục đích gì?", answer: "Thay đổi nội dung cơ sở dữ liệu" },
  { question: "Việc tạo bảng hoặc chỉ mục trong SQL phục vụ mục đích gì?", answer: "Xác định cấu trúc cơ sở dữ liệu" },
  { question: "Việc xác nhận hoặc hoàn tác giao dịch trong SQL đảm bảo điều gì?", answer: "Tính toàn vẹn của dữ liệu" },
  { question: "Việc cấp quyền truy cập trong SQL giúp giải quyết vấn đề gì?", answer: "Bảo mật và phân quyền" },
  { question: "CTE và truy vấn đệ quy kết hợp có thể tối ưu hóa việc xử lý dữ liệu như thế nào?", answer: "Giảm độ phức tạp của truy vấn phân cấp" },
  { question: "Window Functions giúp phân tích dữ liệu hiệu quả hơn bằng cách nào so với truy vấn thông thường?", answer: "Tính toán trên tập con cụ thể" },
  { question: "Index trong cơ sở dữ liệu là gì?", answer: "Cấu trúc dữ liệu tăng tốc truy vấn" },
  { question: "Index cải thiện hiệu suất truy vấn bằng cách nào?", answer: "Giảm lượng truy cập bộ nhớ" },
  { question: "Hash Index phù hợp nhất với loại truy vấn nào?", answer: "Truy vấn với toán tử = hoặc <>" },
  { question: "Nhược điểm của Hash Index khi sử dụng với ORDER BY là gì?", answer: "Không tìm được phần tử tiếp theo" },
  { question: "B-Tree Index lưu trữ dữ liệu theo cấu trúc nào?", answer: "Cây cân bằng (Tree)" },
  { question: "Node nào trong B-Tree không trỏ đến node khác?", answer: "Leaf Node" },
  { question: "B-Tree Index hiệu quả nhất cho loại truy vấn nào?", answer: "Truy vấn khoảng (BETWEEN, >, <)" },
  { question: "Hash Index sử dụng cơ chế nào để ánh xạ dữ liệu?", answer: "Hàm băm (Hash Function)" },
  { question: "Nhược điểm chính của việc sử dụng Index trong cơ sở dữ liệu là gì?", answer: "Tổn thêm bộ nhớ" },
  { question: "Khi nào nên sử dụng Index cho một bảng?", answer: "Bảng có dữ liệu lớn (>100K dòng)" },
  { question: "Trường hợp nào không nên sử dụng Index?", answer: "Dữ liệu thay đổi thường xuyên" },
  { question: "Index làm chậm hoạt động nào trong cơ sở dữ liệu?", answer: "Insert và Update" },
  { question: "Ưu điểm chính của View trong cơ sở dữ liệu là gì?", answer: "Đơn giản hóa truy vấn phức tạp" },
  { question: "View giúp giới hạn dữ liệu truy cập như thế nào?", answer: "Chỉ định row/column theo điều kiện" },
  { question: "Option nào trong View cung cấp lớp bảo mật bổ sung?", answer: "READ ONLY" },
  { question: "Nhược điểm chính của View về hiệu suất là gì?", answer: "Phụ thuộc vào base table" },
  { question: "View trở nên invalid khi nào?", answer: "Base table thay đổi cấu trúc" },
  { question: "T-SQL khác với SQL chuẩn ở điểm nào?", answer: "Có thêm kiểm soát giao dịch và biến" },
  { question: "Stored Procedure là gì?", answer: "Tập hợp câu lệnh T-SQL lưu trên server" },
  { question: "Stored Procedure cải thiện hiệu suất bằng cách nào?", answer: "Sử dụng lại plan cache" },
  { question: "Stored Procedure giúp DBA như thế nào?", answer: "Che giấu logic xử lý" },
  { question: "Ưu điểm nào của Stored Procedure liên quan đến bảo mật?", answer: "Giới hạn truy cập trực tiếp vào bằng" },
  { question: "Nhược điểm nào của Stored Procedure gây khó khăn cho lập trình viên?", answer: "Khó gỡ lỗi" },
  { question: "Trigger trong cơ sở dữ liệu là gì?", answer: "Thủ tục tự động chạy khi có sự kiện" },
  { question: "Trigger được kích hoạt trong trường hợp nào?", answer: "Sự kiện trên bảng hoặc view" },
  { question: "B-Tree Index phù hợp nhất cho cột nào trong bảng?", answer: "Cột dùng để tìm kiếm khoảng giá trị" },
  { question: "Hash Index không hiệu quả với truy vấn nào?", answer: "Truy vấn với toán tử > hoặc <" },
  { question: "Việc đánh Index bừa bãi có thể dẫn đến hậu quả gì?", answer: "Giảm hiệu năng hoạt động" },
  { question: "View cung cấp khả năng gì khi cấu trúc dữ liệu thay đổi?", answer: "Tương thích ngược" },
  { question: "Stored Procedure tăng năng suất nhờ tính năng nào?", answer: "Tái sử dụng mã" },
  { question: "Trigger thường được sử dụng để tự động hóa việc gì?", answer: "Kiểm soát thay đổi dữ liệu" },
  { question: "Nhược điểm nào của Stored Procedure liên quan đến thay đổi hệ thống?", answer: "Khó xác định phần sử dụng" },
  { question: "Index nên được áp dụng cho cột nào trong mệnh đề SQL?", answer: "Cột trong WHERE, JOIN, ORDER BY" },
  { question: "View phức tạp từ nhiều bảng có thể ảnh hưởng đến điều gì?", answer: "Hiệu suất truy vấn" },
  { question: "T-SQL bổ sung tính năng nào để xử lý lỗi tốt hơn SQL chuẩn?", answer: "Xử lý lỗi (TRY-CATCH)" },
  { question: "Stored Procedure giảm tải network bằng cách nào?", answer: "Gửi một câu lệnh duy nhất" },
  { question: "Hash Index có thể được sử dụng để tối ưu hóa truy vấn nào?", answer: "SELECT WHERE column value" },
  { question: "B-Tree Index có ưu điểm gì so với Hash Index?", answer: "Hỗ trợ truy vấn khoảng" },
  { question: "Trigger khác với Stored Procedure ở điểm nào?", answer: "Tự động chạy khi có sự kiện" },
  { question: "Việc sử dụng Index cần lưu ý điều gì về thứ tự cột?", answer: "Thứ tự cột trong Index nhiều trường" },
  { question: "Kỹ thuật nào sau đây giúp bảo vệ dữ liệu trong CSDL khỏi truy cập trái phép?", answer: "Mã hóa dữ liệu" },
  { question: "Trong CSDL, xác thực (authentication) dùng để làm gì?", answer: "Xác minh danh tính người dùng" },
  { question: "Một cách đơn giản để bảo mật CSDL là gì?", answer: "Sử dụng mật khẩu mạnh" },
  { question: "Mã hóa dữ liệu tại rest (encryption at rest) có ý nghĩa gì trong CSDL?", answer: "Bảo vệ dữ liệu khi không sử dụng" },
  { question: "Trong CSDL, phân quyền (authorization) dùng để làm gì?", answer: "Kiểm soát quyền truy cập" },
  { question: "Kỹ thuật nào giúp ngăn chặn tấn công SQL Injection?", answer: "Sử dụng câu lệnh có tham số" },
  { question: "Một biện pháp bảo mật cơ bản cho CSDL là gì?", answer: "Cập nhật phần mềm thường xuyên" },
  { question: "Trong CSDL, nhật ký hoạt động (audit log) dùng để làm gì?", answer: "Theo dõi các hành động trên CSDL" },
  { question: "Kỹ thuật nào giúp bảo vệ dữ liệu khi truyền qua mạng?", answer: "Mã hóa SSL/TLS" },
  { question: "Một nguyên tắc bảo mật CSDL là gì?", answer: "Chỉ cấp quyền tối thiểu cần thiết" },
  { question: "Trong CSDL, sao lưu dữ liệu (backup) giúp gì trong bảo mật?", answer: "Khôi phục dữ liệu sau sự cố" },
  { question: "Tấn công nào sau đây phổ biến với CSDL?", answer: "SQL Injection" },
  { question: "Một cách để bảo vệ mật khẩu trong CSDL là gì?", answer: "Băm (hash) mật khẩu" },
  { question: "Trong CSDL, firewall dùng để làm gì?", answer: "Ngăn chặn truy cập trái phép" },
  { question: "Kỹ thuật nào giúp phát hiện truy cập bất thường vào CSDL?", answer: "Giám sát hành vi (monitoring)" },
  { question: "Trong CSDL, quyền đọc (read) và quyền ghi (write) được quản lý như thế nào?", answer: "Qua phân quyền người dùng" },
  { question: "Một biện pháp bảo mật CSDL khỏi tấn công từ bên trong là gì?", answer: "Kiểm soát quyền truy cập" },
  { question: "Trong CSDL, mã hóa khóa đối xứng (symmetric encryption) sử dụng bao nhiêu khóa?", answer: "Một khóa" },
  { question: "Kỹ thuật nào giúp ngăn chặn truy cập trái phép qua mạng?", answer: "Sử dụng VPN" },
  { question: "Trong CSDL, việc vô hiệu hóa tài khoản mặc định giúp gì?", answer: "Giảm nguy cơ bị tấn công" },
  { question: "Một cách để bảo vệ CSDL khỏi mất dữ liệu là gì?", answer: "Sao lưu định kỳ" },
  { question: "Trong CSDL, xác thực hai yếu tố (2FA) có lợi ích gì?", answer: "Tăng cường bảo mật đăng nhập" },
  { question: "Kỹ thuật nào giúp phát hiện và ngăn chặn tấn công DDoS vào CSDL?", answer: "Sử dụng WAF (Web Application Firewall)" },
  { question: "Trong CSDL, việc mã hóa dữ liệu nhạy cảm như thế nào là an toàn nhất?", answer: "Mã hóa trước khi lưu trữ" },
  { question: "Một biện pháp bảo mật CSDL khi triển khai trên đám mây là gì?", answer: "Sử dụng xác thực đa lớp" },
  { question: "Trong CSDL, việc xóa dữ liệu nhạy cảm không sử dụng nữa giúp gì?", answer: "Giảm nguy cơ rò rỉ dữ liệu" },
  { question: "Kỹ thuật nào giúp bảo vệ CSDL khỏi tấn công brute force?", answer: "Giới hạn số lần đăng nhập sai" },
  { question: "Trong CSDL, việc sử dụng giao thức an toàn như HTTPS giúp gì?", answer: "Bảo vệ dữ liệu khi truyền tải" },
  { question: "Một cách để kiểm tra lỗ hổng bảo mật trong CSDL là gì?", answer: "Thực hiện kiểm tra xâm nhập (penetration testing)" },
  { question: "Trong CSDL, việc sử dụng khóa công khai và khóa riêng (public/private key) thuộc loại mã hóa nào?", answer: "Mã hóa bất đối xứng" },
  { question: "Trong CSDL, kỹ thuật database activity monitoring (DAM) chủ yếu dựa vào yếu tố nào để phát hiện mối đe dọa?", answer: "Phân tích hành vi truy vấn" },
  { question: "Khi triển khai mã hóa TDE (Transparent Data Encryption) trong CSDL, dữ liệu được mã hóa ở cấp độ nào?", answer: "Cấp độ tập hoặc khối lưu trữ" },
  { question: "Trong MongoDB, để ngăn chặn tấn công từ chối dịch vụ (DoS) qua truy vấn nặng, kỹ thuật nào được khuyến nghị?", answer: "Giới hạn tài nguyên truy vấn (query quota)" },
  { question: "Kỹ thuật row-level security (RLS) trong CSDL được triển khai như thế nào để bảo vệ dữ liệu nhạy cảm?", answer: "Áp dụng chính sách truy cập trên từng hàng" },
  { question: "Trong CSDL phân tán, việc sử dụng secure multi-party computation (SMPC) giúp gì?", answer: "Thực hiện tính toán mà không lộ dữ liệu" },
  { question: "Một biện pháp bảo vệ CSDL khỏi tấn công data exfiltration là gì?", answer: "Triển khai DLP (Data Loss Prevention)" },
  { question: "Trong CSDL, kỹ thuật tokenization khác với mã hóa ở điểm nào?", answer: "Thay thế dữ liệu bằng mã token không thể đảo ngược" },
  { question: "Khi sử dụng giao thức TLS trong CSDL, perfect forward secrecy (PFS) đảm bảo điều gì?", answer: "Khóa phiên không thể bị lộ ngay cả khi khóa dài hạn bị xâm phạm" },
  { question: "Trong MongoDB, để bảo vệ dữ liệu khi sử dụng sharding, kỹ thuật nào cần áp dụng?", answer: "Mã hóa dữ liệu trước khi phân mảnh" },
  { question: "Kỹ thuật homomorphic encryption cho phép làm gì trên dữ liệu mã hóa trong CSDL?", answer: "Thực hiện tính toán mà không cần giải mà" },
  { question: "Trong CSDL, việc triển khai attribute-based access control (ABAC) dựa trên yếu tố nào?", answer: "Thuộc tính của người dùng và tài nguyên" },
  { question: "Một cách để phát hiện tấn công privilege escalation trong CSDL là gì?", answer: "Giám sát thay đổi quyền bất thường" },
  { question: "Trong CSDL, zero trust architecture yêu cầu nguyên tắc nào khi xác thực truy cập?", answer: "Xác minh liên tục mọi yêu cầu" },
  { question: "Kỹ thuật nào giúp ngăn chặn tấn công man-in-the-middle (MITM) khi truyền dữ liệu CSDL?", answer: "Sử dụng chứng chỉ số (digital certificate)" },
  { question: "Trong MongoDB, để bảo vệ replica set khỏi truy cập trái phép, cần cấu hình gì?", answer: "Xác thực khóa nội bộ (internal key authentication)" },
  { question: "Kỹ thuật data masking trong CSDL được sử dụng khi nào để tăng cường bảo mật?", answer: "Khi chia sẻ dữ liệu với bên thứ ba" },
  { question: "Trong CSDL, việc triển khai intrusion detection system (IDS) dựa trên cơ chế nào?", answer: "Phân tích mẫu tấn công đã biết" },
  { question: "Một biện pháp bảo vệ CSDL khói tấn công side-channel là gì?", answer: "Sử dụng phần cứng bảo mật (HSM)" },
  { question: "Trong CSDL, key rotation (luân chuyển khóa) giúp gì trong bảo mật?", answer: "Giảm nguy cơ lộ khóa dài hạn" },
  { question: "Kỹ thuật nào trong CSDL giúp ngăn chặn tấn công time-based SQL injection?", answer: "Sử dụng hàm thời gian ngẫu nhiên" },
  { question: "MongoDB là gì?", answer: "Một cơ sở dữ liệu NoSQL" },
  { question: "MongoDB lưu trữ dữ liệu dưới dạng gì?", answer: "Tài liệu JSON/BSON" },
  { question: "Đặc điểm chính của MongoDB là gì?", answer: "Không có schema cố định" },
  { question: "MongoDB thuộc loại cơ sở dữ liệu nào?", answer: "Hướng tài liệu (Document-oriented)" },
  { question: "So với SQL, MongoDB có ưu điểm gì?", answer: "Linh hoạt trong cấu trúc dữ liệu" },
  { question: "BSON trong MongoDB là viết tắt của gì?", answer: "Binary JSON" },
  { question: "MongoDB sử dụng ngôn ngữ truy vấn nào?", answer: "Ngôn ngữ truy vấn dựa trên JSON" },
  { question: "Đơn vị cơ bản của dữ liệu trong MongoDB là gì?", answer: "Tài liệu (Document)" },
  { question: "MongoDB hỗ trợ kiểu dữ liệu nào sau đây?", answer: "Objectid" },
  { question: "Trong MongoDB, một tập hợp các tài liệu được gọi là gì?", answer: "Collection" },
  { question: "MongoDB có hỗ trợ giao dịch (transaction) không?", answer: "Có, từ phiên bản 4.0" },
  { question: "So với SQL, nhược điểm của MongoDB là gì?", answer: "Khó quản lý giao dịch phức tạp" },
  { question: "MongoDB phù hợp nhất với loại ứng dụng nào?", answer: "Ứng dụng cần mở rộng ngang" },
  { question: "MongoDB sử dụng cơ chế gì để mở rộng quy mô?", answer: "Sharding" },
  { question: "Một ưu điểm của MongoDB so với SQL là gì?", answer: "Dễ dàng mở rộng dữ liệu lớn" },
  { question: "Trong MongoDB, chỉ mục (index) được sử dụng để làm gì?", answer: "Tăng tốc độ truy vẫn" },
  { question: "MongoDB có yêu cầu schema trước khi lưu trữ dữ liệu không?", answer: "Không" },
  { question: "Loại chỉ mục nào là mặc định trong MongoDB?", answer: "Chỉ mục trên_id" },
  { question: "MongoDB hỗ trợ loại dữ liệu nhúng (embedded) nào?", answer: "Tài liệu lồng nhau" },
  { question: "Phương pháp tối ưu nào sau đây được dùng trong MongoDB?", answer: "Tạo chỉ mục (Indexing)" },
  { question: "MongoDB khác với SQL ở điểm nào sau đây?", answer: "Không sử dụng bằng và cột" },
  { question: "MongoDB sử dụng cơ chế gì để đảm bảo tính sẵn sàng cao?", answer: "Replication" },
  { question: "Trong MongoDB, replica set là gì?", answer: "Tập hợp các máy chủ sao chép dữ liệu" },
  { question: "Một nhược điểm của MongoDB là gì?", answer: "Tiêu tốn bộ nhớ cao" },
  { question: "MongoDB có hỗ trợ khóa ngoại (foreign key) không?", answer: "Không" },
  { question: "Phương pháp nào sau đây giúp tối ưu hóa truy vấn trong MongoDB?", answer: "Sử dụng chỉ mục hợp lý" },
  { question: "MongoDB có thể lưu trữ dữ liệu không đồng nhất không?", answer: "Có" },
  { question: "Trong MongoDB, sharding dùng để làm gì?", answer: "Phân chia dữ liệu trên nhiều máy chủ" },
  { question: "MongoDB có hỗ trợ truy vấn không gian (geospatial query) không?", answer: "Có" },
  { question: "Một đặc trưng nổi bật của MongoDB là gì?", answer: "Hỗ trợ dữ liệu phi cấu trúc" },
  { question: "MongoDB sử dụng ngôn ngữ lập trình nào để tương tác?", answer: "JavaScript" },
  { question: "Trong MongoDB, aggregation framework dùng để làm gì?", answer: "Xử lý và phân tích dữ liệu" },
  { question: "MongoDB có thể thay thế hoàn toàn cơ sở dữ liệu SQL không?", answer: "Không, tùy thuộc vào ứng dụng" },
  { question: "MongoDB phù hợp với dữ liệu có đặc điểm gì?", answer: "Dữ liệu thay đổi thường xuyên" },
  { question: "Một lợi ích của việc không dùng schema trong MongoDB là gì?", answer: "Dễ dàng thêm trường mới" },
  { question: "MongoDB có hỗ trợ giao dịch ACID đầy đủ như SQL không?", answer: "Không hoàn toàn" },
  { question: "Trong MongoDB, capped collection là gì?", answer: "Collection có kích thước cổ định" },
  { question: "MongoDB có thể xử lý dữ liệu lớn (big data) không?", answer: "Có" },
  { question: "Một cách để tăng hiệu suất MongoDB là gì?", answer: "Sử dụng sharding" },
  { question: "MongoDB hỗ trợ loại truy vấn nào sau đây?", answer: "Truy vẫn dựa trên vị trí" },
  { question: "Trong MongoDB, lệnh nào dùng để thêm tài liệu?", answer: "insert" },
  { question: "MongoDB có hỗ trợ truy vấn full-text không?", answer: "Có" },
  { question: "Một nhược điểm của MongoDB so với SQL là gì?", answer: "Không mạnh về tính toàn vẹn dữ liệu" },
  { question: "MongoDB sử dụng cơ chế gì để lưu trữ dữ liệu hiệu quả?", answer: "BSON" },
  { question: "Trong MongoDB, lệnh nào dùng để xóa tài liệu?", answer: "remove()" },
  { question: "MongoDB có thể xử lý dữ liệu thời gian thực không?", answer: "Có" },
  { question: "Một lợi ích của replication trong MongoDB là gì?", answer: "Tăng tính sẵn sàng" },
  { question: "MongoDB có hỗ trợ chuẩn hóa dữ liệu (normalization) không?", answer: "Không" },
  { question: "Trong MongoDB, lệnh nào dùng để cập nhật tài liệu?", answer: "update()" },
  { question: "MongoDB thường được sử dụng trong lĩnh vực nào?", answer: "Phân tích dữ liệu lớn" },
  { question: "MongoDB có hỗ trợ truy vấn theo thời gian thực không?", answer: "Có" },
  { question: "Trong MongoDB, write concern dùng để làm gì?", answer: "Đảm bảo độ bền của dữ liệu" },
  { question: "Một đặc điểm của MongoDB giúp tăng hiệu suất là gì?", answer: "Hỗ trợ truy vẫn song song" },
  { question: "MongoDB có thể kết hợp với công cụ nào để phân tích dữ liệu?", answer: "MongoDB Atlas" },
  { question: "Trong MongoDB, lệnh nào dùng để tìm kiếm tài liệu?", answer: "find(0)" },
  { question: "MongoDB có hỗ trợ sao lưu dữ liệu tự động không?", answer: "Có, với MongoDB Atlas" },
  { question: "Một lợi ích của sharding trong MongoDB là gì?", answer: "Phân phối tải trên nhiều máy chủ" },
  { question: "MongoDB có hỗ trợ nén dữ liệu (compression) không?", answer: "Có" },
  { question: "Trong MongoDB, TTL index dùng để làm gì?", answer: "Tự động xóa tài liệu sau thời gian" },
  { question: "MongoDB có thể tích hợp với ngôn ngữ lập trình nào?", answer: "Python" },
  { question: "Một nhược điểm của replication trong MongoDB là gì?", answer: "Tăng độ trễ trong ghi dữ liệu" },
  { question: "MongoDB có hỗ trợ truy vấn theo biểu thức chính quy (regular expression) không?", answer: "Có" },
  { question: "Trong MongoDB, lệnh nào dùng để đếm số tài liệu?", answer: "count()" },
  { question: "MongoDB có hỗ trợ quản lý phiên bản dữ liệu không?", answer: "Không" },
  { question: "Một ưu điểm của MongoDB khi làm việc với dữ liệu JSON là gì?", answer: "Tích hợp tự nhiên với JSON" },
  { question: "MongoDB có thể sử dụng trong hệ thống phân tán không?", answer: "Có" },
  { question: "Trong MongoDB, lệnh nào dùng để sắp xếp tài liệu?", answer: "sort" },
  { question: "MongoDB có hỗ trợ truy vấn phân trang (pagination) không?", answer: "Có" },
  { question: "Một cách để giảm tải cho MongoDB là gì?", answer: "Sử dụng caching" },
  { question: "MongoDB có hỗ trợ tích hợp với các công cụ BI (Business Intelligence) không?", answer: "Có" },
  { question: "Trong MongoDB, lệnh nào dùng để giới hạn số lượng tài liệu trả về?", answer: "limit" },
  { question: "MongoDB có hỗ trợ tính năng mã hóa dữ liệu tại rest (encryption at rest) không?", answer: "Có" },
  { question: "Trong MongoDB, lệnh nào dùng để bỏ qua một số tài liệu trong kết quả truy vấn?", answer: "Skip" },
  { question: "MongoDB có hỗ trợ tính năng tự động tăng giá trị (auto-increment) như SQL không?", answer: "Không, dùng Objectid" },
  { question: "Một lợi ích của việc sử dụng MongoDB Atlas là gì?", answer: "Quản lý đám mây dễ dàng" },
  { question: "Trong MongoDB, lệnh nào dùng để xóa một collection?", answer: "drop()" },
  { question: "MongoDB có hỗ trợ truy vấn dựa trên điều kiện nhiều trường (multi-field) không?", answer: "Có" },
  { question: "Trong MongoDB, chỉ mục đa khóa (multikey index) dùng để làm gì?", answer: "Chỉ mục cho mång" },
  { question: "MongoDB có thể sử dụng để lưu trữ dữ liệu log không?", answer: "Có" },
  { question: "Một cách để tối ưu hóa hiệu suất MongoDB khi xử lý dữ liệu lớn là gì?", answer: "Sử dụng aggregation pipeline" },
  { question: "Trong MongoDB, lệnh nào dùng để kiểm tra sự tồn tại của một trường trong tài liệu?", answer: "Sexists" },
  { question: "MongoDB có hỗ trợ tính năng phân quyền người dùng (user roles) không?", answer: "Có" },
  { question: "Trong MongoDB, change stream dùng để làm gì?", answer: "Theo dõi thay đổi trong collection" },
  { question: "MongoDB có thể xử lý dữ liệu không có cấu trúc cố định không?", answer: "Có" },
  { question: "Một nhược điểm của MongoDB khi làm việc với dữ liệu quan hệ phức tạp là gì?", answer: "Không hỗ trợ join tốt" },
  { question: "Trong MongoDB, lệnh nào dùng để thêm một trường mới vào tài liệu?", answer: "$set" },
  { question: "MongoDB có hỗ trợ tính năng sao lưu theo thời gian thực không?", answer: "Có, với oplog" },
  { question: "Trong MongoDB, chỉ mục duy nhất (unique index) dùng để làm gì?", answer: "Đảm bảo giá trị không trùng lặp" },
  { question: "MongoDB có thể tích hợp với công cụ tìm kiếm nào để cải thiện tìm kiếm full-text?", answer: "Elasticsearch" },
  { question: "Một lợi ích của việc sử dụng capped collection trong MongoDB là gì?", answer: "Giới hạn dung lượng tự động" },
  { question: "Dịch vụ cơ sở dữ liệu nào của AWS được quản lý hoàn toàn và hỗ trợ truy vấn SQL?", answer: "Amazon RDS" },
  { question: "Dịch vụ AWS nào phù hợp nhất cho truy cập dữ liệu nhanh theo cặp khóa-giá trị?", answer: "Amazon DynamoDB" },
  { question: "Dịch vụ AWS nào được thiết kế cho kho dữ liệu và phân tích?", answer: "Amazon Redshift" },
  { question: "Amazon Aurora tương thích với hai hệ quản trị cơ sở dữ liệu nào?", answer: "MySQL và PostgreSQL" },
  { question: "Loại cơ sở dữ liệu NoSQL nào là Amazon DynamoDB?", answer: "Key-value và wide-column store" },
  { question: "Dịch vụ nào của AWS cung cấp sao lưu tự động và khôi phục theo thời gian cho RDS?", answer: "Amazon RDS Snapshots" },
  { question: "Dịch vụ AWS nào phù hợp nhất cho ứng dụng dựa trên đồ thị như mạng xã hội?", answer: "Amazon Neptune" },
  { question: "Kích thước tối đa của một item trong Amazon DynamoDB, bao gồm các thuộc tính là bao nhiêu?", answer: "400 KB" },
  { question: "Dịch vụ AWS nào cung cấp sao chép đa vùng với chế độ multi-master?", answer: "Amazon Aurora Global Database" },
  { question: "Dịch vụ nào giúp cải thiện hiệu suất cơ sở dữ liệu bằng cách lưu vào bộ nhớ đệm?", answer: "Amazon ElastiCache" },
  { question: "Amazon RDS hỗ trợ chế độ Multi-AZ để đảm bảo độ sẵn sàng cao?", answer: "Đúng" },
  { question: "Amazon DynamoDB hỗ trợ TTL (Time-to-Live) để tự động xóa dữ liệu hết hạn?", answer: "Đúng" },
  { question: "Amazon Redshift sử dụng kiến trúc lưu trữ theo hàng thay vì theo cột?", answer: "Sai" },
  { question: "Dịch vụ AWS nào phù hợp nhất để lưu trữ dữ liệu có cấu trúc JSON?", answer: "Không, AWS Glue chỉ dùng để xử lý dữ liệu từ S3, không hỗ trợ RDS." },
  { question: "Cơ sở dữ liệu AWS nào có thể mở rộng tự động mà không cần quản lý máy chủ?", answer: "Amazon Aurora Serverless" },
  { question: "Amazon ElastiCache hỗ trợ hai engine caching phổ biến nào?", answer: "Redis và Memcached" },
  { question: "Amazon Timestream được tối ưu hóa cho loại dữ liệu nào?", answer: "Chuỗi thời gian" },
  { question: "Amazon Neptune hỗ trợ những ngôn ngữ truy vấn đồ thị nào?", answer: "Gremlin và SPARQL" },
  { question: "Cách nào giúp tăng tốc truy vấn trong Amazon RDS?", answer: "Sử dụng chỉ mục (Indexes)" },
  { question: "Dịch vụ AWS nào có thể đồng bộ dữ liệu giữa RDS và Redshift?", answer: "AWS DMS (Database Migration Service)" },
  { question: "Amazon RDS hỗ trợ tính năng tự động sao lưu hàng ngày không?", answer: "Đúng" },
  { question: "DynamoDB có hỗ trợ giao dịch ACID không?", answer: "Đúng" },
  { question: "Amazon Aurora có tốc độ nhanh hơn MySQL truyền thống không?", answer: "Đúng" },
  { question: "AWS Glue có thể sử dụng để ETL dữ liệu từ RDS sang Redshift không?", answer: "Đúng" },
  { question: "DynamoDB Streams được sử dụng để làm gì?", answer: "Ghi nhận thay đổi dữ liệu" },
  { question: "Amazon RDS cho phép người dùng thiết lập quyền truy cập bằng IAM không?", answer: "Đúng" },
  { question: "Redshift Spectrum có thể truy vấn trực tiếp dữ liệu trên 53 không?", answer: "Đúng" },
  { question: "Amazon Keyspaces hỗ trợ tương thích với cơ sở dữ liệu nào?", answer: "Apache Cassandra" },
  { question: "AWS Backup có thể sao lưu DynamoDB không?", answer: "Đúng" },
  { question: "Dịch vụ cơ sở dữ liệu quan hệ được quản lý hoàn toàn trên Azure là gì?", answer: "Azure SQL Database" },
  { question: "Azure Cosmos DB hỗ trợ mô hình dữ liệu nào?", answer: "NoSQL" },
  { question: "Azure SQL Managed Instance khác gì với Azure SQL Database?", answer: "Hỗ trợ toàn bộ SQL Server" },
  { question: "Dịch vụ Azure nào phù hợp nhất để lưu trữ dữ liệu có cấu trúc dạng JSON?", answer: "Azure Cosmos DB" },
  { question: "Azure Synapse Analytics chủ yếu được sử dụng cho mục đích nào?", answer: "Kho dữ liệu và phân tích" },
  { question: "Dịch vụ nào hỗ trợ mô hình Multi-Model Database trên Azure?", answer: "Azure Cosmos DB" },
  { question: "Azure Database for PostgreSQL. cung cấp những mô hình triển khai nào?", answer: "Single Server, Flexible Server" },
  { question: "Azure Table Storage là một loại cơ sở dữ liệu nào?", answer: "NoSQL key-value store" },
  { question: "Azure Database for MySQL có hỗ trợ tính năng nào?", answer: "High Availability" },
  { question: "Azure SQL Database hỗ trợ sao chép dữ liệu theo phương thức nào?", answer: "Geo-Replication" },
  { question: "Dịch vụ nào trong Azure giúp di chuyến cơ sở dữ liệu từ on-premises lên doud?", answer: "Azure Database Migration Service" },
  { question: "Cosmos DB hỗ trợ các API truy vấn nào?", answer: "SQL, MongoDB, Gremlin" },
  { question: "Dịch vụ nào trong Azure giúp phân tích dữ liệu lớn từ nhiều nguồn khác nhau?", answer: "Azure Synapse Analytics" },
  { question: "Azure Cosmos DB đảm bảo độ trễ đọc và ghi dữ liệu trong khoảng bao nhiêu mili-giây?", answer: "10ms" },
  { question: "Cách nào giúp tối ưu hiệu suất truy vấn trên Azure SQL Database?", answer: "Sử dụng chỉ mục" },
  { question: "Azure SQL Database có hỗ trợ giao dịch AID không?", answer: "Đúng" },
  { question: "Cosmos DB hỗ trợ bao nhiêu mô hình nhất quán dữ liệu?", answer: "5" },
  { question: "Azure SQL Database có hỗ trợ tính năng tự động sao lưu không?", answer: "Đúng" },
  { question: "Azure Synapse Analytics có thể truy vấn trực tiếp dữ liệu từ Azure Data Lake không?", answer: "Đúng" },
  { question: "Azure Database for PostgreSQL có hỗ trợ mở rộng theo chiều ngang không?", answer: "Đúng" },
  { question: "Azure Cache for Redis được sử dụng để làm gì?", answer: "Caching dữ liệu" },
  { question: "Cosmos DB có hỗ trợ replication giữa nhiều khu vực không?", answer: "Đúng" },
  { question: "Azure SQL Database hỗ trợ tính năng Always Encrypted không?", answer: "Đúng" },
  { question: "Azure Synapse Analytics có thể kết nối với Power BI để trực quan hóa dữ liệu không?", answer: "Đúng" },
  { question: "Azure Data Factory có thể trích xuất dữ liệu từ SQL Server on-premises không?", answer: "Đúng" },
  { question: "Cosmos DB hỗ trợ TTL (Time-to-Live) để tự động xóa dữ liệu không?", answer: "Đúng" },
  { question: "Azure Backup có thể sao lưu dữ liệu từ Azure SQL Database không?", answer: "Đúng" },
  { question: "Azure Database Migration Service có thể di chuyển dữ liệu từ SQL Server lên Azure SQL không?", answer: "Đúng" },
  { question: "Cosmos DB hỗ trợ tính năng tự động mở rộng dung lượng lưu trữ không?", answer: "Đúng" },
  { question: "Dịch vụ cơ sở dữ liệu quan hệ được quản lý hoàn toàn trên Google Cloud là gì?", answer: "Cloud SQL" },
  { question: "Dịch vụ NoSQL của Google Cloud phù hợp với dữ liệu key-value là gì?", answer: "Firestore" },
  { question: "Dịch vụ nào trong Google Cloud phù hợp nhất cho kho dữ liệu và phân tích?", answer: "BigQuery" },
  { question: "Cloud Spanner là loại cơ sở dữ liệu nào?", answer: "Relational, Distributed" },
  { question: "Firestore hỗ trợ mô hình dữ liệu nào?", answer: "Document-based NoSQL" },
  { question: "Cloud Bigtable phù hợp nhất cho loại dữ liệu nào?", answer: "Dữ liệu chuỗi thời gian và khối lượng lớn" },
  { question: "Cloud SQL hỗ trợ những hệ quản trị cơ sở dữ liệu nào?", answer: "MySQL, PostgreSQL, SQL Server" },
  { question: "BigQuery chủ yếu được sử dụng để làm gì?", answer: "Phân tích dữ liệu quy mô lớn" },
  { question: "Dịch vụ nào của Google Cloud cung cấp khả năng lưu vào bộ nhớ đệm?", answer: "Memorystore" },
  { question: "Firestore hỗ trợ những chế độ nào?", answer: "Native Mode, Datastore Mode" },
  { question: "Cloud Spanner đảm bảo các tính năng nào?", answer: "Scalability, Consistency, Global Transactions" },
  { question: "Cloud Spanner có thể được sử dụng như một key-value store không?", answer: "Đúng" },
  { question: "BigQuery hỗ trợ lưu trữ dữ liệu có cấu trúc JSON không?", answer: "Đúng" },
  { question: "Firestore có hỗ trợ TTL (Time-to-Live) không?", answer: "Đúng" },
  { question: "Cloud SQL có thể tự động sao lưu dữ liệu không?", answer: "Đúng" },
  { question: "Cloud Spanner có hỗ trợ giao dịch ACID không?", answer: "Đúng" },
  { question: "BigQuery có thể kết nối với Google Sheets không?", answer: "Đúng" },
  { question: "Memorystore hỗ trợ hai hệ thống caching phổ biến nào?", answer: "Redis, Memcached" },
  { question: "Cloud SQL có hỗ trợ tính năng tự động mở rộng không?", answer: "Sai" },
  { question: "BigQuery có thể truy vấn dữ liệu trực tiếp từ Google Drive không?", answer: "Đúng" },
  { question: "Dịch vụ nào phù hợp nhất để phân tích dữ liệu thời gian thực?", answer: "BigQuery" },
  { question: "Cloud Spanner có thể mở rộng theo chiều ngang không?", answer: "Đúng" },
  { question: "Cloud Bigtable phù hợp nhất cho loại ứng dụng nào?", answer: "lot, phân tích chuỗi thời gian" },
  { question: "Firestore có hỗ trợ chế độ offline không?", answer: "Đúng" },
  { question: "BigQuery có thể xử lý lượng dữ liệu bao nhiêu?", answer: "Petabytes" },
  { question: "Cloud SQL có thể chạy trên Kubernetes không?", answer: "Sai" },
  { question: "Dịch vụ nào có thể đồng bộ dữ liệu từ MySQL on-prem lên Cloud SQL?", answer: "Database Migration Service" },
  { question: "Firestore hỗ trợ mô hình nhất quán nào?", answer: "Eventual và Strong Consistency" },
  { question: "Cloud SQL có hỗ trợ Replication không?", answer: "Đúng" },
  { question: "Dịch vụ nào của AWS được tối ưu hóa cho dữ liệu chuỗi thời gian với khả năng nén tự động?", answer: "Amazon Timestream" },
  { question: "Azure Cosmos DB có thể tự động điều chỉnh hiệu suất dựa trên tải bằng tính năng nào?", answer: "Autoscale" },
  { question: "Dịch vụ nào của Google Cloud hỗ trợ truy vấn SQL trên dữ liệu phí cấu trúc từ Cloud Storage?", answer: "BigQuery" }

    // Add more question-answer pairs
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
	// Xóa biểu tượng nếu có
	const iconPrevios = document.getElementById("textScannerIcon");
	if (iconPrevios) {
		iconPrevios.remove();
	}
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
