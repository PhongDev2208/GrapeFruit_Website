// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  // Chuong1
  {
    question:
      "Để đối phó với tình trạng cạn kiệt nguồn năng lượng truyền thống, giải pháp để giải quyết vấn đề này là",
    answer: "Cả A và B đều đúng",
  },
  {
    question: "Nhiên liệu hóa thạch là",
    answer:
      "Phần còn lại của động vật và thực vật nằm dưới lòng đất hàng triệu năm",
  },
  {
    question: "Hiệu ứng nhà kính gây ra cái gì",
    answer: "Khí nhà kính",
  },
  {
    question: "Khí nhà kính là những khí nào",
    answer: "CO2",
  },
  {
    question: "Ảnh hưởng của sự tăng nhiệt trên trái đất là gì",
    answer: "Tất cả các câu trên đều đúng",
  },
  {
    question: "Phát biểu dưới đây cái nào đúng",
    answer:
      "Nếu khí nhà kính tăng lên, lượng nhiệt phản chiếu từ trái đất nhiều hơn",
  },
  {
    question:
      "Chúng ta có thể làm gì để chống lại sự thay đổi nhiệt độ trên trái đất",
    answer: "Giảm lượng khí gây hiệu ứng nhà kính",
  },
  {
    question:
      "Yếu tố nào làm ảnh hưởng lên lượng CO2 mà quốc gia buộc phải giảm",
    answer: "Khí thải hiện tại",
  },
  {
    question: "Thuận lợi của xe điện là gì",
    answer: "Tất cả các câu trên đều đúng",
  },
  {
    question: "Xe điện có thân thiện với môi trường không",
    answer: "Có nếu xe dùng ác quy sử dụng năng lượng xanh",
  },
  {
    question: "Đối với xe lai, khi bắt đầu di chuyển, động năng được lấy từ",
    answer: "Từ động cơ điện",
  },
  {
    question:
      "Chất ô nhiễm HC sinh ra ít nhất trên động cơ đốt trong sử dụng nhiên liệu xăng khi",
    answer: "λ ≈ 1",
  },
  {
    question:
      "Theo thống kê, nguồn năng lượng được sử dụng nhiều nhất trên thế giới",
    answer: "Dầu mỏ",
  },
  {
    question:
      "Ngành nghề tiêu thụ năng lượng nhiều nhất trong những năm gần đây ở Việt Nam là",
    answer: "Công nghiệp",
  },
  {
    question: "Mật độ ô tô tăng quá nhiều sẽ ảnh hưởng đến",
    answer: "Các câu trên đều đúng",
  },
  {
    question: "Khi mật độ ô tô tăng quá nhiều sẽ có vấn đề cần giải quyết là",
    answer: "Các câu trên đều đúng",
  },
  {
    question: "Nhiên liệu Biogas là",
    answer: "Là một khí sinh học",
  },
  {
    question:
      "Pin nhiên liệu là một thiết bị tạo ra điện bằng một quá trình điện hóa giữa",
    answer: "Oxy và Hydro",
  },
  {
    question: "Nhiên liệu BioDiesel là",
    answer: "Là Diesel được sản xuất từ dầu thực vật",
  },
  {
    question:
      "Trong quá trình cháy, chất ô nhiễm phát sinh nhiều nhất trên động cơ đốt trong là",
    answer: "NOx",
  },
  // Chuong 2
  {
    question:
      "Trong quá trình cháy, chất ô nhiễm phát sinh nhiều nhất trên động cơ đốt trong là",
    answer: "CO",
  },
  {
    question: "Thông thường, các vỉa dầu nằm sâu trong lòng đất khoảng",
    answer: "Từ 2000 m trở lên",
  },
  {
    question: "Nguyên tố chiếm nhiều nhất trong thành phần của dầu mỏ là",
    answer: "Carbon",
  },
  {
    question: "Thành phần hóa học chủ yếu của xăng là",
    answer: "Heptan và Octan",
  },
  {
    question:
      "Chất ô nhiễm làm huỷ hoại tầng ôzôn do động cơ đốt trong sinh ra chủ yếu là",
    answer: "NOx",
  },
  {
    question:
      "Chất ô nhiễm có thể gây ra mưa axít do động cơ đốt trong sinh ra là",
    answer: "SO2",
  },
  {
    question:
      "Chất ô nhiễm HC sinh ra nhiều nhất trên động cơ đốt trong sử dụng nhiên liệu xăng khi:",
    answer: "Giàu xăng",
  },
  {
    question:
      "Chất ô nhiễm NOx sinh ra ít nhất trên động cơ đốt trong sử dụng nhiên liệu xăng khi",
    answer: "Nghèo xăng",
  },
  {
    question: "Thông thường khi xảy ra hiện tượng kích nổ, ECU sẽ điều khiển",
    answer: "Giảm góc đánh lửa sớm",
  },
  {
    question: "Trị số octan của xăng là trị số thể hiện",
    answer: "Khả năng chống kích nổ của xăng",
  },
  {
    question:
      "Trị số octan của xăng được xác định bằng cách pha chế 2 hợp phần của HydroCarbon là",
    answer: "n-Heptan và izo-Octan",
  },
  {
    question: "Trị số octan của HydroCarbon n-Heptan có giá trị là",
    answer: "TSOT = 0",
  },
  {
    question: "Trị số octan của HydroCarbon izo-Octan có giá trị là",
    answer: "TSOT = 100",
  },
  {
    question:
      "Công thức hóa học của n-Heptan trong thành phần hỗn hợp của xăng là",
    answer: "C7H16",
  },
  {
    question:
      "Công thức hóa học của izo-Octan trong thành phần hỗn hợp của xăng là",
    answer: "C8H18",
  },
  {
    question:
      "Tùy theo phương pháp xác định, người ta phân biệt các loại trị số Octan của Xăng",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trên thị trường thế giới, xăng ôtô và xe gắn máy thường được phân làm các loại",
    answer: "Xăng thường, Xăng cao cấp",
  },
  {
    question:
      "Trên thị trường Việt Nam, theo TCVN – 1998, dựa trên trị số Octan, xăng ôtô và xe gắn máy thường được phân làm các loại:",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Thông thường ở động cơ Diesel, hiện tượng cháy không bình thường là do:",
    answer: "Thời gian cháy trễ kéo dài",
  },
  {
    question: "Trị số Xetan của Diesel là trị số thể hiện",
    answer: "Khả năng tự bốc cháy của Diesel",
  },
  {
    question:
      "Trị số Xetan của Diesel được xác định bằng cách pha chế 2 hợp phần của HydroCarbon là",
    answer: "n-Xetan và α-metyl naphtalen",
  },
  {
    question: "Trị số Xetan của HydroCarbon n-Xetan có giá trị là",
    answer: "TSXT = 100",
  },
  {
    question: "Trị số Xetan của HydroCarbon α-metyl naphtalen có giá trị là:",
    answer: "TSXT = 0",
  },
  {
    question: "Phát biểu nào sau đây đúng",
    answer:
      "Trong cùng một dãy đồng đẳng hydrocacbon, mạch cacbon càng dài TSXT càng cao",
  },
  {
    question:
      "Khi có cùng số nguyên tử cacbon trong mạch thì nhóm hydrocacbon có tỉ số Xetan cao nhất là",
    answer: "Hydrocacbon n-parafin",
  },
  {
    question:
      "Khi có cùng số nguyên tử cacbon trong mạch thì nhóm hydrocacbon có tỉ số Xetan thấp nhất là",
    answer: "Hydrocacbon thơm",
  },
  {
    question: "Trị số Xetan của HydroCarbon n-Decan có giá trị là",
    answer: "TSXT = 76,9",
  },
  {
    question: "Chỉ số Xetan của nhiên liệu Diesel được xác định bằng",
    answer: "Bằng phương pháp thực nghiệm",
  },
  {
    question:
      "Ta phân loại nhiên liệu Diesel dựa theo số vòng quay động cơ và trị số Xetan của nhiên liệu có",
    answer: "2 nhóm",
  },
  {
    question:
      "Để động cơ Diesel hoạt động ổn định, đòi hỏi nhiên liệu Diesel phải đảm bảo các chi tiêu chất lượng như sau",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Khi nói về độ nhớt của nhiên liệu Diesel, phát biểu nào sau đây đúng",
    answer: "Nhiệt độ càng tăng độ nhớt càng giảm",
  },
  {
    question: "Trị số MON thể hiện đặc tính của xăng dùng cho động cơ",
    answer: "Hoạt động trên xa lộ, tốc độ cao",
  },
  {
    question: "Trị số RON thể hiện đặc tính của xăng dùng cho động cơ",
    answer: "Hoạt động trong thành phố, tốc độ thấp",
  },
  {
    question: "Tính bay hơi của xăng được đánh giá qua chỉ tiêu là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Công thức hóa học của n-Xetan trong thành phần hỗn hợp của Diesel là",
    answer: "C16H34",
  },
  {
    question:
      "Sản phẩm xe lai hành khách đầu tiên trên thế giới vào năm 1997 là",
    answer: "Toyota Hybrid System",
  },
  {
    question: "Hoạt động của hệ thống xe lai THS, khi ở chế độ khởi động là",
    answer: "Chỉ chạy động cơ điện",
  },
  {
    question: "Hoạt động của hệ thống xe lai THS, khi ở chế độ tăng tốc là",
    answer: "Động cơ xăng và động cơ điện cùng hoạt động",
  },
  {
    question:
      "Hoạt động của hệ thống xe lai THS, khi ở chế độ chạy bình thường thì:",
    answer: "Động cơ xăng và động cơ điện cùng hoạt động",
  },
  {
    question: "Đặc trưng trong hệ thống lai THS là",
    answer: "Các câu trên đều đúng",
  },
  // Chuong 3
  {
    question:
      "Ở hệ thống xe lai THS, sự liên kết của hai động cơ xăng và điện gồm có",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Ở hệ thống xe lai THS, động cơ điện điều khiển những bánh xe, công việc duy nhất của động cơ xăng là sẽ kéo máy phát điện để phát sinh ra điện năng là ở hệ thống lai",
    answer: "Hệ thống lai nối tiếp",
  },
  {
    question:
      "Ở hệ thống xe lai THS, động cơ xăng điều khiển chính những bánh xe, động cơ điện giúp đỡ hỗ trợ gia tốc là ở hệ thống lai",
    answer: "Hệ thống lai song song",
  },
  {
    question:
      "Ở hệ thống xe lai THS, hệ thống chuyển giao một tỉ lệ biến đổi liên tục công suất của động cơ xăng và động cơ điện đến các bánh xe chủ động là ở hệ thống lai",
    answer: "Hệ thống lai hỗn hợp",
  },
  {
    question: "Hệ thống lai nối tiếp và hỗn hợp",
    answer: "3 kiểu cơ bản",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu SOFC sử dụng chất điện phân là dung dịch",
    answer: "Oxit kim loại rắn",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu PAFC sử dụng chất điện phân là dung dịch",
    answer: "Axit phosphoric",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu PEMFC sử dụng vật liệu điện cực là",
    answer: "Carbon",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu hoạt động ở nhiệt độ cao nhất là",
    answer: "SOFC",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu hoạt động ở nhiệt độ thấp nhất là",
    answer: "PEMFC",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu MCFC hoạt động ở nhiệt độ khoảng",
    answer: "6500C",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu PEMFC hoạt động ở nhiệt độ khoảng",
    answer: "700C",
  },
  {
    question:
      "Trong hoạt động của ô tô sử dụng pin nhiên liệu(fuel cell), vận hành ở chế độ kéo lai được hiểu là",
    answer: "FC và ắc quy cung cấp công suất để kéo ô tô",
  },
  {
    question: "Nhiệt độ tự bốc cháy của nhiên liệu LPG khoảng",
    answer: "4570C",
  },
  {
    question:
      "Khi nói về tính chất vật lý của nhiên liệu LPG, phát biểu nào sau đây sai",
    answer: "Có tỉ trọng lớn hơn nước",
  },
  {
    question:
      "Trên thực tế, các phương pháp tạo hỗn hợp LPG/không khí cho động cơ ô tô gồm có",
    answer: "3 phương pháp",
  },
  {
    question:
      "Trong các phương pháp tạo hỗn hợp LPG/không khí cho động cơ ô tô, phương pháp có tính chống kích nổ tốt nhất là",
    answer: "Phun LPG lỏng",
  },
  {
    question:
      "Trong các phương pháp tạo hỗn hợp LPG/không khí cho động cơ ô tô, phương pháp có mức độ nạp đầy hỗn hợp kém nhất là",
    answer: "Theo kiểu khuếch tán",
  },
  {
    question:
      "Trong các phương pháp tạo hỗn hợp LPG/không khí cho động cơ ô tô, phương pháp có chất lượng hòa trộn hỗn hợp tốt nhất là",
    answer: "Phun hơi LPG kiểu điện tử",
  },
  {
    question:
      "Hiện nay trên thế giới, động cơ sử dụng lưỡng nhiên liệu LPG và xăng được kết hợp theo các giải pháp sau",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu lưỡng LPG và xăng kiểu họng venturi, chi tiết điều khiển chính lượng nhiên liệu LPG vào động cơ là",
    answer: "Van tiết lưu",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu lưỡng LPG và xăng kiểu họng venturi, áp suất trong bình chứa LPG ở nhiệt độ khí trời khoảng",
    answer: "7 - 8 bar",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, van an toàn được gắn trên bình chứa LPG với mục đích để",
    answer: "An toàn cho bình chứa khi áp suất tăng cao",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, van an toàn hoạt động ở áp suất khoảng",
    answer: "26 kg/cm2",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, cụm van chân không gồm có 2 van chân không làm việc độc lập đó là",
    answer: "Van không tải và van chính",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, van quá dòng ở trên bình chứa hoạt động như thế nào",
    answer:
      "Khi áp suất sau van quá dòng giảm mạnh do sự cố, van quá dòng sẽ đóng lại",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, van tiết lưu hoạt động ở",
    answer: "4 chế độ",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, van tiết lưu hoạt động ở các chế độ là",
    answer: "Không tải, bình thường, làm đậm, tăng tốc",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu LPG, van tiết lưu hoạt động ở chế độ làm đậm hỗn hợp khi",
    answer: "Khi động cơ làm việc ở khoảng 80% tải",
  },
  {
    question:
      "Sau khi lên men tạo khí sinh học, hỗn hợp khí Biogas gồm các chất sau:",
    answer: "CH4, H2S, CO2",
  },
  {
    question:
      "Ở hệ thống lai THS, bộ kết hợp truyền công suất giữa động cơ xăng và điện gồm có",
    answer: "Kiểu truyền động nối cứng tốc độ và kiểu biến đổi mômen",
  },
  {
    question:
      "Trong cấu tạo của pin nhiên liệu, khi xảy ra phản ứng hóa học, các ion hydro mang điện tích dương sẽ được sinh ra ở",
    answer: "Điện cực Anode của pin nhiên liệu",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, thông thường lượng điện thu được từ một pin nhiên liệu đơn khoảng",
    answer: "0,5 V",
  },
  {
    question: "Trên ô tô sử dụng pin nhiên liệu, phát biểu nào sau đây sai",
    answer: "Chi phí đầu tư ban đầu cho ô tô pin nhiên liệu thấp",
  },
  {
    question:
      "Trên ô tô sử dụng pin nhiên liệu, loại pin nhiên liệu AFC sử dụng chất điện phân là dung dịch",
    answer: "Dung dịch kiềm (KOH)",
  },
  {
    question:
      "Trong hệ thống lưỡng nhiên liệu Biogas-Diesel, van tiết lưu có công dụng",
    answer: "Điều khiển lượng khí Biogas vào bộ hòa trộn",
  },
  {
    question:
      "Trong hỗn hợp khí Biogas, thành phần phần trăm khí CH4 chiếm khoảng",
    answer: "80 %",
  },
  {
    question:
      "Trong hệ thống lưỡng nhiên liệu Biogas-Diesel, phát biểu nào sau đây đúng",
    answer:
      "Việc đốt cháy khí Biogas bằng sự mồi cháy của một lượng nhỏ nhiên liệu Diesel",
  },
  {
    question:
      "Trong hệ thống lưỡng nhiên liệu Biogas - Xăng, phát biểu nào sau đây đúng",
    answer: "Việc đốt cháy khí Biogas bằng cách bugi bật tia lửa điện",
  },
  {
    question:
      "Trong hệ thống nhiên liệu Biogas, van cung cấp Biogas hoạt động dựa trên:",
    answer: "Tác dụng của độ chân không tại họng khuyếch tán",
  },
  {
    question: "Ưu điểm của ô tô sử dụng năng lượng mặt trời là",
    answer: "Hoạt động rất êm, hiệu suất cao",
  },
  {
    question: "Nhược điểm của ô tô sử dụng năng lượng mặt trời là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trong các phương pháp sản xuất Hydro, phương pháp hơi nước qua than nóng đỏ có ưu điểm là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trong các phương pháp sản xuất Hydro, phương pháp điện phân nước có ưu điểm là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trong hệ thống lưỡng nhiên liệu Hydro-Xăng cho động cơ tĩnh tại, van không tải cấp hydro hoạt động (mở ra) dựa trên:",
    answer: "Độ chân không sau bướm ga",
  },
  {
    question:
      "Trong hệ thống lưỡng nhiên liệu Hydro-Xăng cho động cơ tĩnh tại, van cấp chính khí hydro hoạt động (mở ra) dựa trên:",
    answer: "Độ chân không tại họng cửa nạp tăng lên cho đến khi đủ lớn",
  },
  {
    question:
      "Trên xe ô tô sử dụng khí Hydro, các phương pháp đốt cháy Hydro là:",
    answer:
      "Phương pháp dùng tia lửa đốt cháy trực tiếp và phương pháp đốt cháy gián tiếp",
  },
  {
    question:
      "Trên xe ô tô sử dụng khí Hydro, thông thường phương pháp bố trí bình chứa trên xe ô tô là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trong hệ thống cung cấp nhiên liệu khí Hydro, van điều áp có công dụng",
    answer: "Giảm áp suất và ổn định áp suất đầu ra từ bình chứa khí Hydro",
  },
  {
    question:
      "Hai loại Cồn chính thường dùng làm nhiên liệu cho động cơ đốt trong là",
    answer: "CH3OH và C2H5OH",
  },
  {
    question: "Ưu điểm của nhiên liệu Cồn sử dụng trên động cơ đốt trong là:",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Trong hệ thống lai THS, chế độ khôi phục và sử dụng lại năng lượng trong trường hợp",
    answer: "Giảm tốc",
  },
  {
    question:
      "Ở hệ thống lai THS, bộ kết hợp truyền công suất giữa động cơ điện và động cơ xăng gồm có",
    answer: "Kiểu truyền động nối cứng tốc độ và kiểu vi sai tốc độ",
  },
  {
    question: "Công thức hóa học của Methanol là",
    answer: "CH3OH",
  },
  {
    question: "Công thức hóa học của Etanol là",
    answer: "C2H5OH",
  },
  {
    question: "Bio diezel là sản phẩm của",
    answer: "Là quá trình este hóa các axit hữu cơ có nhiều trong dầu mỏ",
  },
  {
    question: "Ưu điểm khi sử dụng nhiên liệu Biodiezel cho động cơ đốt trong",
    answer: "Tất cả các ưu điểm trên",
  },
  {
    question:
      "Khó khăn khi sử dụng nhiên liệu Biodiesel trong động cơ đốt trong",
    answer: "Tất các đáp án nêu trên",
  },
  {
    question: "Các ưu điểm của nhiên liệu cồn khi dùng cho động cơ đốt trong",
    answer: "Tất cả các ưu điểm trên",
  },
  {
    question: "Khuyết điểm của nhiên liệu cồn",
    answer: "Tất cả các nhược điểm trên",
  },
  {
    question: "Hệ thống van EGR (Exhaust gas Recirculation System) là hệ thống",
    answer: "Là hệ thống đưa khí xả trở lại động cơ",
  },
  {
    question:
      "Hệ thống van (Exhaust gas Recirculation System) là hệ thống có chức năng",
    answer: "Tất cả các chức năng nêu trên.",
  },
  {
    question:
      "Hệ thống thông khí PVC (Positive Crankcase Ventiation System) có chức năng",
    answer: "Tất cả các chức năng nêu trên",
  },
  {
    question: "Thiết bị xúc tác (Catalytic Converter) có công dụng",
    answer: "Giảm khí gây ô nhiễm môi trường",
  },
  {
    question:
      "Thiết bị xúc tác (Catalytic Converter) có tác dụng làm giảm các khí ô nhiễm thải ra môi trường bằng cách",
    answer:
      "Tạo điều kiện để phản ứng ôxi hóa khử diễn ra dễ dàng hơn, làm biến đổi các chất gây ô nhiễm thành các chất ít ô nhiễm hơn.",
  },
  {
    question: "Hệ thống sưởi khí nạp (HAI) có tác dụng",
    answer: "Làm ấm khí nạp, làm xăng bốc hơi tốt hơn",
  },
  {
    question: "Hệ thống thu hồi hơi xăng trên động cơ có tác dụng",
    answer:
      "Hấp thụ hơi xăng trong thùng chứa xăng để đưa vào buồng đốt trong động cơ",
  },
  {
    question: "Hệ thống phun khí(AI) có tác dụng gì",
    answer:
      "Đưa khí chưa đốt cháy tới đường xả của động cơ để ôxi hóa và làm giảm các chất khí ô nhiễm",
  },
  {
    question:
      "Các chất ô nhiễm sinh ra trên động cơ đốt trong sử dụng nhiên liệu xăng",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Khí NOx khi đi vào phổi sẽ gây ra hiện tượng gì",
    answer: "Tất cả các triệu chứng trên",
  },
  {
    question:
      "Khí HC (hydrocacban) khi đi vào cơ thể có thể gây ra các tác hại gì",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Tia cực tím có thể gây ra các tác hại gì",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Hiện tượng cháy kích nổ trong động cơ xăng diễn ra như thế nào",
    answer:
      "Xăng tự bốc cháy khi chịu áp suất cao trong kỳ nổ trong khi, lửa sinh ra từ bugi chưa lan tỏa tới",
  },
  {
    question:
      "Trị số xe tan của nhiên liệu diezel được hiểu như thế nào là đúng",
    answer: "Khả năng tự cháy khi có áp suất cao",
  },
  // Chuong 4
  {
    question: "Bộ phận nào có thể giảm khí thải động cơ diezel",
    answer: "Tất cả các câu trên đều đúng",
  },
  {
    question: "Bộ phận nào có thể giảm khí thải động cơ xăng",
    answer: "Tất cả các câu trên đều đúng",
  },
  {
    question: "Thành phần nào được giảm trong quá trình cháy của động cơ",
    answer: "Khí CO, HC, NOx",
  },
  {
    question:
      "Phản ứng hóa học nào sau đây thể hiện quá trình cháy lý tưởng của động cơ",
    answer: "O2+HC → CO2+ H2O",
  },
  {
    question: "Tên hóa học của nhiên liệu dùng cho động cơ đốt trong là gì",
    answer: "Hydrocac bon",
  },
  {
    question: "Nếu quá trình cháy lý tưởng, chất khí tạo ra sẽ là",
    answer: "CO2, H2O",
  },
  {
    question: "Bộ xúc tác SCR giảm được nồng độ khí nào sau đây",
    answer: "NOx",
  },
  {
    question: "Bộ lọc bụi giảm được khí nào",
    answer: "HC",
  },
  {
    question: "Bộ luân hồi khí thải giảm được khí nào trong các khí sau đây",
    answer: "NOx",
  },
  {
    question: "Trong các chế độ vận hành của ô tô sử dụng pin nhiên liệu gồm",
    answer: "5 chế độ",
  },
  {
    question:
      "Tiêu chuẩn Châu Âu đang giới hạn giá trị phát thải những chất độc hại nhằm mục đích gì",
    answer: "Để giảm sự phát thải những chất độc hại của xe.",
  },
  {
    question: "Những xe nào áp dụng bảng tiêu chuẩn khí thải Euro",
    answer: "Các xe sử dụng nhiên liệu Xăng, dầu Diezel",
  },
  {
    question: "Tiêu chuẩn Euro 1 về khí thải được áp dụng vào tháng năm nào",
    answer: "1-1-1996",
  },
  {
    question: "Tiêu chuẩn Euro 2 về khí thải được áp dụng vào tháng năm nào",
    answer: "1-7-1992",
  },
  {
    question: "Tiêu chuẩn Euro 3 về khí thải được áp dụng vào tháng năm nào",
    answer: "1-3-2000",
  },
  {
    question: "Tiêu chuẩn Euro 4 về khí thải được áp dụng vào tháng năm nào",
    answer: "1-1-2005",
  },
  {
    question:
      "Khi nói về chất ô nhiễm NO trên động cơ đốt trong phụ thuộc vào hệ số khí sót, phát biểu nào sau đây đúng",
    answer: "Nồng độ NO càng giảm khi nồng độ khí sót càng tăng",
  },
  {
    question:
      "Trong các chất độ hại NOX, chất sinh ra trên động cơ đốt trong chiếm tỉ lệ thấp nhất là",
    answer: "Nồng độ NO càng tăng khi góc đánh lửa sớm φ càng tăng",
  },
  {
    question:
      "Khi nói về chất ô nhiễm NOx trên động cơ đốt trong phụ thuộc vào nhiệt độ buồng cháy, phát biểu nào sau đây đúng",
    answer: "Nồng độ NOX càng tăng khi nhiệt độ buồng cháy càng tăng",
  },
  {
    question:
      "Khi nói về chất ô nhiễm CO sinh ra trên động cơ đốt trong, phát biểu nào sau đây đúng",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Khi nói về chất ô nhiễm CO trên động cơ đốt trong phụ thuộc vào áp suất nạp, phát biểu nào sau đây đúng",
    answer:
      "Ở cùng số vòng quay động cơ, góc đánh lửa sớm và hệ số khí sót. Nếu áp suất nạp giảm thì sẽ làm tăng nồng độ CO",
  },
  {
    question:
      "Khi nói về chất ô nhiễm NO trên động cơ đốt trong phụ thuộc vào góc đánh lửa sớm φ, phát biểu nào sau đây đúng",
    answer: "Nồng độ CO tăng khi mức độ đậm đặc θ của hỗn hợp tăng",
  },
  {
    question: "Những không gian chết trong buồng đốt động cơ là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Cơ chế hình thành HC chưa cháy do sự trùng điệp của xupáp vào thời điểm là",
    answer: "Cuối hút – Đầu nén",
  },
  {
    question:
      "Cơ chế hình thành HC chưa cháy do tỉ lệ hỗn hợp không thích hợp là",
    answer: "2 câu trên đều đúng",
  },
  {
    question: "Lượng chì (Pb) tồn tại trong xăng có ảnh hưởng là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Khi một động cơ làm việc với hỗn hợp nghèo hơn bình thường, phát biểu nào sau đây đúng",
    answer: "Nồng độ các chất ô nhiễm chính CO, HC, NOX đều sẽ giảm xuống",
  },
  {
    question:
      "Khi động cơ sử dụng nhiên liệu có tính bay hơi kém hơn, nồng độ HC sẽ thay đổi như thế nào",
    answer: "Nồng độ HC chưa cháy sẽ tăng lên",
  },
  {
    question:
      "Khi động cơ sử dụng nhiên liệu có chỉ số Octan thấp (dễ bị kích nổ), nồng độ NOX sẽ thay đổi như thế nào",
    answer: "Nồng độ NOX sẽ tăng lên",
  },
  {
    question:
      "Khi tăng tỉ số giữa diện tích bề mặt buồng đốt và thể tích của nó (F/V), phát biểu nào sau đây đúng",
    answer: "Các câu trên đều đúng",
  },
  {
    question: "Khi tăng tỉ số nén động cơ, phát biểu nào sau đây đúng",
    answer: "Tăng nồng độ NOX do nhiệt độ cuối quá trình cháy tăng",
  },
  {
    question: "Phát biểu nào sau đây sai",
    answer: "Khi tăng tỉ số nén, động cơ có thể làm việc với hỗn hợp đậm hơn",
  },
  {
    question:
      "Khi giảm tỉ lệ giữa khoảng chạy piston và đường kính xy lanh (S/D), phát biểu nào sau đây đúng",
    answer: "Lượng HC trong khí thải tăng",
  },
  {
    question:
      "Khi giảm tỉ lệ giữa khoảng chạy piston và đường kính xy lanh (S/D), phát biểu nào sau đây đúng",
    answer: "Lượng HC trong khí thải tăng",
  },
  {
    question:
      "Khi tăng tỉ lệ giữa khoảng chạy piston và đường kính xy lanh (S/D), phát biểu nào sau đây sai",
    answer: "Các câu trên đều sai",
  },
  {
    question: "Phát biểu nào sau đây đúng",
    answer: "Khi nhiệt độ buồng đốt càng cao, NOX sinh ra càng nhiều",
  },
  {
    question: "Lượng HC sinh ra nhiều trên động cơ đốt trong khi",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Khi nói về ảnh hưởng của tỷ lệ HC thơm trong nhiên liệu, phát biểu nào sau đây đúng",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Khi động cơ sử dụng nhiên liệu có tính bay hơi kém, phát biểu nào sau đây đúng",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Khi tăng tỉ số giữa diện tích bề mặt buồng đốt và thể tích của nó (F/V), sẽ xảy ra",
    answer: "Lượng HC trong khí thải tăng",
  },
  {
    question: "Phát biểu nào sau đây đúng",
    answer: "Khi tăng tỉ số nén, làm tăng nguy cơ kích nổ, tăng NOX",
  },
  {
    question: "Các tính chất của nguyên liệu khí hóa lỏng LPG",
    answer: "Tất cả các tính chất trên",
  },
  {
    question: "Phương pháp tạo hỗn hợp LPG/không khí cho động cơ ô tô là",
    answer: "Bao gồm các phương pháp nêu trên",
  },
  {
    question: "Dầu Bio điezel có thể được sản xuất từ",
    answer: "Tất cả các nguồn nêu trên",
  },
  {
    question: "Các tính chất của nguyên liệu khí hóa lỏng LPG",
    answer: "Tất cả các tính chất trên",
  },
  {
    question: "Phương pháp tạo hỗn hợp LPG/không khí cho động cơ ô tô là",
    answer: "Bao gồm các phương pháp nêu trên",
  },
  {
    question: "Dầu Bio điezel có thể được sản xuất từ",
    answer: "Tất cả các nguồn nêu trên",
  },
  {
    question: "Lý do của việc vẽ ra nghị định thư Kyoto là gì",
    answer: "Nhằm chống lại sự biến đổi khí hậu",
  },
  {
    question: "Những việc cần làm để chống lại biến đổi khí hậu?",
    answer: "Giảm lượng khí gây hiệu ứng nhà kính.",
  },
  {
    question: "Phát biểu nào dưới đây đúng?",
    answer: "Nếu khí nhà kính tăng lên, nó làm tăng hiệu ứng nhà kính",
  },
  {
    question: "Một trong những nguồn gây ô nhiễm lớn nhất là gì?",
    answer: "Vận chuyển Giao thông đường bộ.",
  },
  {
    question: "Nguồn phát thải gây hiệu ứng nhiều nhất ở Hà lan là",
    answer: "Xe ô tô",
  },
  {
    question: "Các chỉ tiêu chất lượng của dầu diezel là",
    answer: "Tất cả các đáp án trên",
  },
  {
    question:
      "Xăng sử dụng chỉ số nào để đánh giá tính chống kích nổ trong các chỉ số sau đây.",
    answer: "Trị số octan",
  },
  {
    question:
      "Dầu diezel sử dụng chỉ số nào trong các chỉ số sau đây để làm chỉ số tính tự cháy.",
    answer: "Trị số xetan",
  },
  {
    question:
      "Do dầu thực vật có độ nhớt cao nên cần thiết kế động cơ theo phương án sau",
    answer: "Tất cả các ý trên đều đúng",
  },
  {
    question:
      "Động cơ xăng sau khi lắp thêm bộ chuyển đổi có thể sử dụng được các nguyên liệu nào trong các nguyên liệu sau",
    answer: "Tất cả các nguyên liệu trên",
  },
  {
    question: "Hydro có thể được sản xuất bằng cách nào trong các cách sau đây",
    answer: "Điện phân nước",
  },
  {
    question: "Động cơ Stirling là động cơ nào trong các động cơ sau đây",
    answer: "Là dạng động cơ sử dụng nguồn nhiệt bên ngoài động cơ",
  },
  {
    question: "Hydro có thể được sản xuất bằng cách nào trong các cách sau",
    answer: "Phun hơi nước qua than nóng đỏ",
  },
  // Chuong 5
  {
    question:
      "Lượng khí xả được đưa trở về lại buồng đốt dựa vào 2 thông số cơ bản là",
    answer: "Tốc độ động cơ và tải động cơ",
  },
  {
    question: "Tải động cơ và tốc độ cháy hỗn hợp",
    answer: "Nhiệt độ nước làm mát",
  },
  {
    question: "Cấu tạo van chân không TVSV của hệ thống tuần hoàn EGR làm",
    answer: "Sáp giãn nở bằng nhiệt",
  },
  {
    question: "Van một chiều trong hệ thống tuần hoàn EGR mở khi",
    answer: "Động cơ lạnh",
  },
  {
    question: "Van EGR trong hệ thống tuần hoàn EGR có công dụng là",
    answer: "Mở cho dòng khí thải đi vào đường ống nạp",
  },
  {
    question: "Van EGR trong hệ thống tuần hoàn EGR đóng khi",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Bộ điều biến chân không EGR trong hệ thống tuần hoàn EGR có công dụng là",
    answer: "Điều khiển độ đóng mở của van EGR",
  },
  {
    question: "Hệ thống thông khí PCV là hệ thống",
    answer: "Thông khí hộp trục khuỷu",
  },
  {
    question: "Phát biểu nào sau đây đúng",
    answer: "Khi giảm tỉ số nén, làm tăng nguy cơ kích nổ, tăng NOX",
  },
  {
    question: "Hệ thống EGR là hệ thống",
    answer: "Đưa khí thải trở về lại buồng đốt động cơ",
  },
  {
    question: "Hệ thống EGR sử dụng cho động cơ",
    answer: "Động cơ Diesel và Diezel",
  },
  {
    question: "Cách tốt nhất để giảm lượng NOX là",
    answer: "Giảm nhiệt độ động cơ",
  },
  {
    question: "Khi đưa khí thải trở về lại buồng đốt động cơ, lúc này",
    answer: "Các câu trên đều đúng",
  },
  {
    question: "Tác hại của khí cháy bị lọt xuống hộp trục khuỷu là",
    answer: "Các câu trên đều đúng",
  },
  {
    question: "Công dụng của hệ thống thông khí PCV là",
    answer: "Đưa khí ở hộp trục khuỷu trở về lại đường ống nạp",
  },
  {
    question: "Công dụng của van PCV trong hệ thống thông khí PCV là",
    answer: "Điều hoà lượng khí ở hộp trục khuỷu trở về lại đường ống nạp",
  },
  {
    question: "Van PCV trong hệ thống thông khí PCV hoạt động dựa vào",
    answer: "Độ chân không đường ống nạp",
  },
  {
    question: "Van PCV trong hệ thống thông khí PCV mở nhỏ nhất khi",
    answer: "Chạy cầm chừng",
  },
  {
    question: "Van PCV trong hệ thống thông khí PCV mở lớn nhất",
    answer: "Tải lớn",
  },
  {
    question: "Van PCV trong hệ thống thông khí PCV đóng khi",
    answer: "Động cơ không hoạt động",
  },
  {
    question: "Thiết bị xúc tác thường lắp trên",
    answer: "Trên đường ống thải của động cơ",
  },
  {
    question: "Trong hệ thống xúc tác oxy hoá, chất xúc tác thường là",
    answer: "Platin (Pt)",
  },
  {
    question: "Trong hệ thống xúc tác ba thành phần, chất xúc tác thường là",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Thông thường bộ xúc tác chỉ phát huy tác dụng khi nhiệt độ làm việc lớn hơn",
    answer: "2500C",
  },
  {
    question: "Công dụng của hệ thống điều khiển bướm ga là",
    answer:
      "Giúp mở bướm ga lúc giảm ga lớn hơn một chút so với khi chạy không tải, để tránh hỗn hợp hoà khí đậm",
  },
  {
    question: "Công dụng của hệ thống tự động sưởi khi nạp là",
    answer: "Duy trì nhiệt độ của khí nạp ở một nhiệt độ nhất định",
  },
  {
    question: "Công dụng của van ITC trong hệ thống tự động sưởi khi nạp là",
    answer: "Bù nhiệt độ cho khí nạp khi nhiệt độ khí nạp thấp",
  },
  {
    question:
      "Khi nhiệt độ không khí lạnh thì van ITC trong hệ thống tự động sưởi khi nạp lúc này sẽ",
    answer:
      "Đóng lại để cho màng HAI được hút lên và cho đường không khí nóng đi vào động cơ",
  },
  {
    question:
      "Khi động cơ đã nóng lên, van ITC trong hệ thống tự động sưởi khi nạp lúc này sẽ mở hoàn toàn làm cho",
    answer: "Van điều khiển sẽ đóng kín và chỉ cho khí lạnh đi vào động cơ",
  },
  {
    question:
      "Độ đóng mở của van ITC trong hệ thống tự động sưởi khi nạp phụ thuộc vào",
    answer: "Nhiệt độ của khí nạp",
  },
  {
    question:
      "Màng HAI trong hệ thống tự động sưởi khi nạp hoạt động lên xuống phụ thuộc vào",
    answer: "Độ đóng mở của bướm ga",
  },
  {
    question: "Hệ thống thâu hồi hơi xăng có công dụng",
    answer: "Thu hồi hơi xăng thoát ra từ thùng xăng",
  },
  {
    question:
      "Trên bộ lọc than hoạt tính của hệ thống thâu hồi hơi xăng không có ECU điều khiển có",
    answer: "3 van một chiều",
  },
  {
    question:
      "Trên bộ lọc than hoạt tính của hệ thống thâu hồi hơi xăng có ECU điều khiển có",
    answer: "2 van một chiều",
  },
  {
    question:
      "Van điều khiển cửa ngoài của hệ thống thâu hồi hơi xăng mở ở chế độ",
    answer: "Động cơ không hoạt động",
  },
  {
    question:
      "Van điều khiển cửa ngoài của hệ thống thâu hồi hơi xăng đóng ở chế độ",
    answer: "Các câu trên đều đúng",
  },
  {
    question:
      "Hệ thống hút không khí (AS) nhằm giảm ô nhiễm môi trường trên ô tô được hiểu là",
    answer:
      "Dùng sự thay đổi đột ngột của áp suất khí xả để đóng mở van lưỡi gà, cho phép khí được hút vào ống xả chớp nhoáng",
  },
  {
    question:
      "Hệ thống phun không khí (AI) nhằm giảm ô nhiễm môi trường trên ô tô được hiểu là",
    answer:
      "Dùng sự thay đổi đột ngột của áp suất khí xả để phun thêm khí nóng vào ống xả",
  },
  {
    question: "Trong hệ thống phun không khí (AI), van VSV được điều khiển bởi",
    answer: "ECU",
  },
  {
    question:
      "Ở hệ thống Limpet khi thủy triều xuống thấp thì hệ thống thực hiện chu trình",
    answer: "Nạp",
  },
  {
    question:
      "Khí xả động cơ đốt trong luôn có chứa một hàm lượng đáng kể các chất độc hại",
    answer: "Bao gồm các chất độc hại kể trên",
  },
  {
    question: "Tính chất của khí độc CO sinh ra trong khí thải động cơ là",
    answer: "Các tính chất kể trên",
  },
  {
    question: "Chì được pha vào xăng nhằm mục đích",
    answer: "Để chống kích nổ",
  },
  {
    question: "Hiệu ứng nhà kính được hiểu là",
    answer:
      "Hình thành 1 lớp khí ngăn cản sự bức xạ từ trái đất ra ngoài không gian khi trái đất bị bức xạ mặt trời chiếu xuống",
  },
  {
    question: "Dầu khí là sản phẩm của",
    answer:
      "Quá trình phân hủy xác động, thực vật trong các lớp trầm tích ở dưới đáy biển, dưới tác dụng của các vi khuẩn hiếm khí",
  },
  {
    question:
      "Những biểu hiện nào sau đây biểu thị động cơ xăng đang xảy ra hiện tượng bị cháy kích nổ",
    answer:
      "Có tiếng gõ trong động cơ, động cơ giảm công suất, khói có màu đen, tăng tiêu hao nhiên liệu, động cơ nóng hơn",
  },
  {
    question: "Trị số Octan của xăng càng cao thì khả năng chống kích nổ",
    answer: "Càng Cao",
  },
  {
    question: "Trị số AKI trong xăng là trị số tương đương với trị số",
    answer: "PON",
  },
  {
    question: "Trong cùng một mẫu xăng thì trị số RON so với trị số MON",
    answer: "Bao giờ cũng cao hơn",
  },
  {
    question: "Tính bay hơi của xăng được đánh giá bằng các chỉ tiêu phẩm chất",
    answer: "Tất cả các đáp án trên",
  },
  {
    question:
      "Để xác định thành phần điểm sôi của xăng người ta cần phải xác định các thành phần điểm sôi sau",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Điểm sôi 10% của nhiên liệu xăng đặc trưng cho tính",
    answer: "Khởi động của động cơ",
  },
  {
    question: "Điểm sôi 50% của nhiên liệu xăng biểu thị khả năng",
    answer: "Thay đổi tốc độ của máy",
  },
  {
    question: '"Nước chì" được pha vào xăng nhằm mục đích',
    answer: "Ngăn chặn sự hình thành các hợp chất peoxyt",
  },
  {
    question:
      "Những chất nào trong những chất sau đây có tác dụng tăng TSOT của xăng",
    answer: "Các chất nêu trên",
  },
  {
    question:
      "Phương pháp nào trong các phương pháp sau đây nhằm xác định tính ăn mòn kim loại của xăng",
    answer: "Tất cả các phương pháp nêu trên",
  },
  {
    question:
      "Theo tiêu chuẩn việt nam (TCVN - 5690-1998) xăng ôtô bao gồm những loại nào",
    answer: "Các loại nêu trên",
  },
  {
    question:
      "Nhiên liệu điêzel có trị số xetan từ 30-40 thì phù hợp với động cơ có số vòng quay",
    answer: "Dưới 500 vòng /phút",
  },
  {
    question:
      "Nhiên liệu điêzel có trị số xetan từ 40-50 thì phù hợp với động cơ có số vòng quay",
    answer: "Từ 500 - 1000 vòng / phút",
  },
  {
    question:
      "Nhiên liệu điêzel có trị số xetan trên 50 thì phù hợp với động cơ có số vòng quay",
    answer: "Trên 1000 vòng/ phút",
  },
  {
    question:
      "Chất lượng dầu diezel được đánh giá dựa vào các chỉ tiêu nào trong các chỉ tiêu sau đây",
    answer: "Các chỉ tiêu nêu trên",
  },
  {
    question:
      "Chất lượng dầu diezel được đánh giá dựa vào các chỉ tiêu nào trong các chỉ tiêu sau đây",
    answer: "Các chỉ tiêu nêu trên",
  },
  {
    question: "Độ nhớt động học của nhiên liệu diezel thể hiện",
    answer: "Khả năng lưu chuyển của nhiên liệu trong hệ thống",
  },
  {
    question:
      "Độ nhớt động học (Kine mactic viscosity) được tính theo công thức v= C*t trong đó",
    answer:
      "v - Độ nhớt động học;  C- Hằng số của độ nhớt; t - thời gian thể lỏng chảy qua mao quản",
  },
  {
    question:
      "Để xác định tính ăn mòn của nhiên liệu diezel người ta dựa vào việc",
    answer: "Tất cả các công việc nêu trên",
  },
  {
    question: "Xe ôtô Hybrid là loại xe ôtô được hiểu là",
    answer: "Xe sử dụng động lực từ hệ thống lai mô tơ điện",
  },
  {
    question:
      "Trong hệ thống hybrid THS trên xe ôtô của toyota, điện được nạp vào trong bình trữ điện trong các trường hơp nào trong các trường hợp sau",
    answer: "Trong các trường hợp nêu trên",
  },
  {
    question:
      "Những nguyên nhân nào trong các nguyên nhân sau khiến xe ôtô sử dụng hệ thống lai (hybrid) có thể tiết kiệm được năng lượng so với các xe không trang bị hệ thống này",
    answer: "Các nguyên nhân nêu trên",
  },
  {
    question:
      "Chu trình Atkinson được hiểu như thế nào trong các cách hiểu sau đây",
    answer:
      "Chu trình bao gồm các quá trình hút, nén, nổ, xả, trong đó hành trình piston được tăng thêm trong kỳ nổ và xả",
  },
  {
    question:
      "Chu trình Atkinson dùng cho động cơ đốt trong khác với các chu trình nhiệt động khác là",
    answer: "Tăng được hành trình của piston trong 2 kỳ nổ và xả",
  },
  {
    question:
      "Trong hệ thống điều khiển THS , ECU nhận tín hiệu từ các tín hiệu",
    answer: "Các nguồn nêu trên",
  },
  {
    question: "Bộ phân chia công suất trong hệ thống hybrid là",
    answer: "Bộ truyền động cơ khí dùng cơ cấu bánh răng hành tinh",
  },
  {
    question: "Bộ phân chia công suất trong hệ thống hybrid là",
    answer: "Bộ truyền động cơ khí dùng cơ cấu bánh răng hành tinh",
  },
  {
    question:
      "Trong hệ thống lai THS của toyota, động cơ điện AC đạt hiệu xuất cao do các nam châm vĩnh cửu được đặt theo",
    answer: "Kiểu chữ V",
  },
  {
    question: "Hệ thống lai sử dụng sử dụng nguồn ắc quy kim loại",
    answer: "Nickel- Hydrua",
  },
  {
    question:
      "Xe hybrid và xe điện khác nhau ở điểm cơ bản nào trong các điểm sau đây",
    answer: "Xe hybrid có thể tự sạc điện khi bình hết điện, xe điện thì không",
  },
  {
    question:
      "Đối với hệ thống FCHV trên xe hybrid, Nguồn nguyên liệu được nạp vào trong Fuel cell là",
    answer: "Hydro hoặc methanol",
  },
  {
    question:
      "Những ưu điểm khi sử dụng Fuel cell so với việc dùng động cơ đốt trong trên ôtô là",
    answer: "Tất cả các ưu điểm trên",
  },
  {
    question: "Những khó khăn gặp phải khi ứng dụng Fuel cell vào thực tế là",
    answer: "Tất cả các khó khăn nêu trên",
  },
  {
    question: "Sản phẩm sau cùng của quá trình ion hóa trong Fuel cell là",
    answer: "Điện và H2O",
  },
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
    // Xóa biểu tượng nếu có
    const iconPrevios = document.getElementById("textScannerIcon");
    if (iconPrevios) {
      iconPrevios.remove();
    }
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
