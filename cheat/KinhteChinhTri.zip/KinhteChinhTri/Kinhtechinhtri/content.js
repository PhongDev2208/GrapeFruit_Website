// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  // Chuong 1
    { question: "Tiền đề lý luận cho sự ra đời của chủ nghĩa Mác là: ", answer: "Triết học cổ điển Đức, Kinh tế chính trị Anh, Chủ nghĩa xã hội không tưởng Pháp" },
{ question: "Để nghiên cứu kinh tế chính trị Mác - Lênin có thể sử dụng nhiều phương pháp, phương pháp nào quan trọng nhất? ", answer: "Trừu tượng hóa khoa học" },
{ question: "Đối tượng nghiên cứu của kinh tế- chính trị Mác-Lênin là: ", answer: "Quan hệ xã hội của sản xuất và trao đổi được đặt trong mối quan hệ biện chứng với lực lượng sản xuất và kiến trúc thượng tầng tương ứng" },
{ question: "Ai là người đặt nền móng đầu tiên cho trường phái Kinh tế chính trị cổ điển Anh? ", answer: "W. Petty" },
{ question: "Kinh tế chính trị Mác - Lênin được hình thành, xây dựng bởi? Chọn câu trả lời đúng nhất? ", answer: "C. Mác, Ph. Ăngghen và V.I. Lênin" },
{ question: "C. Mác và Ph. Ăngghen xác định đối tượng nghiên cứu của kinh tế chính trị là? ", answer: "Các quan hệ của sản xuất và trao đổi" },
{ question: "Kinh tế chính trị Mác - Lênin có mấy chức năng? ", answer: "4" },
{ question: " Các chức năng cơ bản của Kinh tế chính trị Mác – Lênin đó là:", answer: "Thực tiễn, tư tưởng, phương pháp luận, nhận thức" },
{ question: "Chọn nhận định đúng nhất? ", answer: "Kinh tế chính trị Mác - Lênin do C. Mác - Ph. Ăngghen sáng lập, được Lênin bổ sung và phát triển. " },
{ question: "Quá trình phát triển của khoa học kinh tế chính trị được khái quát qua 2 giai đoạn lịch sử nào? ", answer: "Từ thời cổ đại đến thế kỷ XVIII và từ sau thế kỷ thứ XVIII đến nay." },
{ question: "Trường phái nào được ghi nhận là hệ thống lý luận kinh tế chính trị đầu tiên nghiên cứu về nền sản xuất tư bản chủ nghĩa? ", answer: "Chủ nghĩa trọng thương" },
{ question: "Trường phái nào được ghi nhận là hệ thống lý luận kinh tế chính trị đầu tiên nghiên cứu về tái sản xuất? ", answer: "Chủ nghĩa trọng nông" },
{ question: "C. Mác đã kế thừa một cách có phê phán lý luận kinh tế chính trị cổ điển Anh, trong đó trực tiếp là của ai? ", answer: "D. Ricardo" },
{ question: "Chọn cụm từ còn thiếu điền vào khoảng trống dưới đây? ", answer: "Các quan hệ của sản xuất và trao đổi" },
{ question: "Mục đích nghiên cứu của kinh tế chính trị Mác – Lênin là gì? ", answer: "Phát hiện ra các quy luật kinh tế chi phối các quan hệ giữa người với người trong sản xuất và trao đổi" },
{ question: "C. Mác có những đóng góp nổi bật nào trong việc nghiên cứu phương thức sản xuất tư bản chủ nghĩa? ", answer: "Học thuyết giá trị; Học thuyết giá trị thặng dư; Học thuyết tích luỹ; Học thuyết về địa tô; Học thuyết về lợi nhuận" },
{ question: " Thuật ngữ khoa học “Kinh tế chính trị” xuất hiện lần đầu tiên vào năm:", answer: "1615" },
{ question: "Chủ nghĩa trọng thương đặc biệt coi trọng vai trò hoạt động trong: ", answer: "Công nghiệp" },
{ question: "Trừu tượng hoá khoa học là: ", answer: "Quá trình đi từ cụ thể đến trừu tượng và ngược lại. Gạt bỏ các hiện tượng ngẫu nhiên, bề ngoài, chỉ giữ lại những mối liên hệ phổ biến mang tính bản chất." },
{ question: "Lý luận kinh tế chính trị của C. Mác và Ph. Ăngghen được thể hiện tập trung và cô đọng nhất trong tác phẩm nào sau đây? ", answer: "Bộ “Tư bản”" },
{ question: "Nhận định nào sau đây là đúng? ", answer: "Đối tượng nghiên cứu của kinh tế chính trị Mác - Lênin là các quan hệ xã hội của sản xuất và trao đổi, được đặt trong sự liên hệ biện chứng với trình độ phát triển của lực lượng sản xuất và kiế trúc thượng tầng tương ứng của PTSX" },
//Chương 2
{ question: "Giá cả hàng hóa là gì? ", answer: "b.	Biểu hiện bằng tiền của giá trị hàng hóa" },
{ question: "Việc sản xuất và trao đổi hàng hóa phải được tiến hành dựa trên cơ sở: ", answer: "Hao phí thời gian lao động xã hội cần thiết" },
{ question: "Điều kiện ra đời và tồn tại của sản xuất hàng hóa là gì? ", answer: "Phân công lao động xã hội và sự tách biệt tương đối về kinh tế của những người sản xuất hàng hóa" },
{ question: "Hàng hóa là gì? ", answer: "Sản phẩm của lao động, có thể thỏa mãn nhu cầu nào đó của con người thông qua trao đổi mua bán" },
{ question: "Giá trị sử dụng của hàng hóa là gì? ", answer: "Là công dụng của hàng hóa" },
{ question: "Hai thuộc tính của hàng hóa gồm: ", answer: "giá trị và giá trị sử dụng" },
{ question: "Theo quy luật giá trị, lưu thông hàng hoá phải dựa trên nguyên tắc ngang giá nghĩa là gì? ", answer: "Giá cả độc lập với giá trị nhưng luôn vận động xoay quanh giá trị" },
{ question: "Giá trị của hàng hóa được quyết định bởi: ", answer: "Lao động trừu tượng của người sản xuất hàng hóa kết tinh trong hàng hóa." },
{ question: "Lao động cụ thể là gì? ", answer: "Là lao động thuộc các ngành nghề cụ thể, tạo ra giá trị sử dụng hàng hóa" },
{ question: "Lao động trừu tượng là gì? ", answer: "Lao động hao phí đồng chất của con người mà nó tạo ra giá trị hàng hóa" },
{ question: "Giá trị sử dụng của hàng hóa do cái gì tạo ra? ", answer: "Lao động cụ thể của người sản xuất " },
{ question: "Quy luật cung – cầu có tác dụng gì? ", answer: "Xác định giá cả thị trường trong ngắn hạn" },
{ question: "Lượng giá trị hàng hóa là gì? ", answer: "Thời gian lao động xã hội cần thiết để sản xuất ra hàng hóa đó " },
{ question: "Lượng giá trị hàng hóa được tính bằng gì? ", answer: "Thời gian lao động xã hội cần thiết để sản xuất ra hàng hóa đó" },
{ question: "Thời gian lao động xã hội cần thiết là gì? ", answer: "Thời gian lao động xã hội cần thiết để sản xuất ra hàng hóa trong điều kiện bình thường của xã hội" },
{ question: "Thời gian lao động xã hội cần thiết được tính trong điều kiện nào? ", answer: "Mức độ trung bình của xã hội về trình độ kỹ thuật, tay nghề và cường độ lao động" },
{ question: "Những nhân tố nào ảnh hưởng đến lượng giá trị hàng hóa? ", answer: "Năng suất lao động và mức độ phức tạp của lao động" },
{ question: "Quan hệ giữa lượng giá trị và năng suất lao động xã hội như thế nào? ", answer: "Lượng giá trị tỉ lệ nghịch với năng suất lao động xã hội" },
{ question: "Quan hệ giữa lượng giá trị hàng hóa và mức độ phức tạp của lao động?     ", answer: "Lương giá trị hàng hóa tỉ lệ thuận vơi mức độ phức tạp của lao động" },
{ question: "Lượng giá trị hàng hóa cấu thành từ cái gì? ", answer: "Từ giá trị cũ tái hiện và giá trị mới" },
{ question: "Lao động nào tạo ra giá trị của hàng hóa? ", answer: "Lao động trừu tương" },
{ question: "Lao động nào bảo tồn và di chuyển giá trị cũ vào sản phẩm? ", answer: "Lao động cụ thể" },
{ question: "Giá trị hàng hóa có các hình thái nào? ", answer: "Hình thái giản đơn, mở rộng, chung và hình thái tiền tệ" },
{ question: "Tiền tệ có những chức năng gì? ", answer: "Thước đo giá trị, phương tiện lưu thông, phương tiện cất trữ, phương tiện thanh toán và tiển tệ thế giới" },
{ question: "Yêu cầu của quy luật giá trị là gì? ", answer: "Sản xuất và trao đổi phải dựa trên cơ sở hao phí lao động xã hội cần thiết" },
{ question: "Mục đích của lưu thông hàng hóa giản đơn là gì? ", answer: "Trao đổi giá sử dụng để thỏa mãn nhu cầu" },
{ question: "Giá cả hàng hóa chịu ảnh hưởng của các nhận tố nào? ", answer: "Cả ba phương án trên " },
{ question: "Nội dung của quy luật giá trị là gì? ", answer: "Giá cả xoay quanh giá trị nhưng tổng giá cả bằng tổng giá trị" },
{ question: "Cơ chế hoạt động của quy luật giá trị là gì? ", answer: "Giá cả phải xoay quanh giá trị" },
{ question: "Quy luật giá trị có những tác động nào trong nền sản xuất xã hội? ", answer: "Cả ba phương án trên" },
{ question: "Yếu tố nào làm giảm giá trị của hàng hoá: ", answer: "Tăng năng suất lao động. " },
{ question: "Lao động trừu tượng: ", answer: "Tạo ra giá trị của hàng hoá." },
{ question: "Tiền là hàng hoá đặc biệt: ", answer: "Giữ vai trò là vật ngang giá chung, là thước đo giá trị của tất cả các loại hàng hoá khác" },
{ question: " Giá trị của hàng hoá là:", answer: "Lao động xã hội kết tinh trong hàng hóa." },
{ question: "Chức năng cơ bản của tiền: ", answer: "Thước đo giá trị." },
{ question: "Sản xuất hàng hoá giản đơn ra đời do: ", answer: "Có sự phân công lao động xã hội và chế độ tư hữu về tư liệu sản xuất." },
{ question: "Giá trị của hàng hoá: ", answer: "Do lao động trừu tượng tạo ra." },
{ question: "Hai hàng hoá trao đổi ngang giá với nhau được vì: ", answer: "Có lượng thời gian lao động xã hội cần thiết để sản xuất ra chúng bằng nhau.???" },
{ question: "Một người lao động trong một ngày sản xuất được 30 sản phẩm, có tổng giá trị là 60USD. Hỏi: tổng sản lượng làm ra trong ngày và giá trị của một sản phẩm là bao nhiêu nếu năng suất lao động tăng lên 2 lần? ", answer: "60 sản phẩm – 2USD" },
{ question: "Kinh tế hàng hóa phát triển qua các giai đoạn: ", answer: "Kinh tế hàng hóa giản đơn, kinh tế thị trường" },
{ question: "Lao động sản xuất hàng hóa có tính 2 mặt, đó là: ", answer: "Lao động cụ thể và lao động trừu tượng" },
{ question: "Chọn đáp án sai: ", answer: "trị của sản phẩm mới: v + m" },
{ question: "Tăng năng suất lao động là do: ", answer: "Thay đổi cách thức lao động" },
{ question: "Khi năng suất lao động tăng, số lượng sản phẩm sản xuất trong một đơn vị thời gian sẽ: ", answer: "Tăng" },
{ question: "Cường độ lao động là: ", answer: "Mức độ khẩn trương, nặng nhọc trong lao động" },
{ question: "Xác định đúng các khâu của quá trình tái sản xuất: ", answer: "Sản xuất – phân phối – trao đổi – tiêu dùng" },
{ question: "Giá cả thị trường của hàng hóa được xác dịnh bởi: ", answer: "Tất cả đều đúng" },
{ question: "Yêu cầu của quy luật giá trị trong sản xuất và trao đổi hàng hóa? ", answer: "Phải dựa trên hao phí lao động xã hội cần thiết" },
{ question: "Yêu cầu của quy luật giá trị trong quá trình trao đổi hàng hóa?", answer: "Phải dựa trên nguyên tắc ngang giá" },
{ question: "Lạm phát là hiện tượng xảy ra khi nào? ", answer: "Giá cả của thị trường tăng đột biến trong một thời gian nhất định" },
{ question: "Trong những sản phẩm dưới đây sản phẩm nào không phải là hàng hóa? ", answer: "Gà nuôi để giết thịt phục vụ gia đình" },
{ question: "Yếu tố quyết định giá cả hàng hóa là: ", answer: "Giá trị của hàng hóa" },
{ question: "Sự tách biệt tương đối về mặt kinh tế giữa các nhà sản xuất nghĩa là:", answer: "Làm cho những người sản xuất độc lập với nhau và có sự tách biệt về sở hữu tư liệu sản xuất" },
{ question: "Trong lịch sử, sự tách biệt tương đối về mặt kinh tế giữa các chủ thể sản xuất, xuất hiện khách quan khi nào? ", answer: "Khi có sự tách biệt về sở hữu tư liệu sản xuất" },
{ question: "Nội dung nào dưới đây không thể hiện mặt trái của sản xuất hàng hóa?", answer: "Các chủ thể sản xuất cạnh tranh với nhau" },
{ question: "Hình thái đo lường giá trị dựa trên việc cộng đồng đã chọn một hànghóa làm vật ngang giá chung cho mọi hàng hóa khác là:", answer: "Hình thái chung của giá trị" },
{ question: "Ví dụ nào dưới đây thể hiện hình thái đầy đủ (hay mở rộng) của giá trị:", answer: "1 con gà = 10 kg thóc; hoặc 1 con gà = 2 cái rìu; hoặc 1 con gà = 5 mét vải, ..." },
{ question: "Chọn ý sai khi nói về sản phẩm và hàng hóa: ", answer: "Không phải mọi sản phẩm đều là hàng hóa" },
{ question: "Tiền nhất thiết phải có đủ giá trị khi thực hiện chức năng: ", answer: "Tất cả các chức năng của tiền" },
{ question: "Tiền dùng để đo lường và biểu hiện giá trị của hàng hóa khác là tiền thực hiện chức năng:", answer: "Thước đo giá trị" },
{ question: "Khối lượng tiền cần thiết cho lưu thông như thế nào so với tốc độ lưuthông của tiền tệ? ", answer: "Tỷ lệ nghịch" },
{ question: "Vì sao hàng hóa có hai thuộc tính là giá trị và giá trị sử dụng? ", answer: "Ví có hai loại lao động là lao động trừu tượng và lao động cụ thể" },
{ question: "Lưu thông hàng hóa dựa trên nguyên tắc ngang giá. Điều này được hiểu như thế nào là đúng? ", answer: "Giá cả có thể tách rời giá trị và xoay quanh giá trị của nó" },
{ question: "ý nào sau đây là ý không đúng về lao động phức tạp: ", answer: "Lao động phức tạp là lao động trí tuệ của người lao động có trình độ cao" },
{ question: "Chọn các ý đúng trong các ý sau đây: ", answer: "Lao động của người sản xuất hàng hoá đều có lao động cụ thể và lao động trừu tượng" },
{ question: "Tiền có 5 chức năng. Chức năng nào không đòi hỏi có tiền vàng? ", answer: "Chức năng phương tiện lưu thông và phương tiện thanh toán" },
{ question: "Thị trường có vai trò gì? ", answer: "Tất cả các đáp án đều đúng" },
{ question: " Có bao nhiêu căn cứ để phân loại thị trường?", answer: " 3" },
{ question: "Ai là người phát hiện ra tính chất hai mặt của lao động sản xuất hàng hoá?", answer: "C.Mác" },
{ question: "Quy luật giá trị tồn tại ở riêng: ", answer: "Trong nền kinh tế hàng hoá" },
{ question: "Xét về lôgíc và lịch sử thì sản xuất hàng hoá xuất hiện từ khi nào? ", answer: "Cuối xã hội nguyên thuỷ, đầu xã hội nô lệ" },
{ question: "Thế nào là cung hàng hoá? ", answer: "Toàn bộ hàng hoá đem bán trên thị trường và có thể đưa nhanh đến thị trường ở một mức giá nhất định." },
{ question: "Thế nào là cầu hàng hóa? ", answer: "Là nhu cầu của thị trường về hàng hoá." },
{ question: "Trong các phạm trù kinh tế dưới đây, phạm trù nào được coi là tín hiệu của cơ chế thị trường? ", answer: "Giá cả thị trường" },
{ question: "Trong các mệnh đề dưới đây, mệnh đề nào không đúng? ", answer: "Quy luật kinh tế hoạt động giống các quy luật tự nhiên" },
//Chuongw 3
{ question: "Căn cứ nào phân chia tư bản thành tư bản bất biến và tư bản khả biến?", answer: "Việc xác định nguồn gốc của gía trị thặng dư " },
{ question: "Vai trò của máy móc trong quá trình sản xuất giá trị thặng dư: ", answer: "Máy móc chỉ là tiền đề vật chất cho việc tạo ra thặng dư" },
{ question: "Tiền tệ là: ", answer: "Hàng hóa đặc biệt đóng vai trò là vật ngang giá chung " },
{ question: "Nền kinh tế tri thức được xem là ", answer: "Một nấc thang phát triển của lực lượng sản xuất" },
{ question: "Tư bản là: ", answer: "Giá trị mang lại giá trị thặng dư bằng cách bóc lột lao động làm thuê." },
{ question: "Lợi nhuận: ", answer: "Hình thức biến tướng của giá trị thặng dư" },
{ question: "Tăng trưởng kinh tế, phát triển kinh tế và tiến bộ xã hội là: ", answer: "d.	Có liên hệ với nhau và làm điều kiện cho nhau" },
{ question: "Nguồn gốc của giá trị thặng dư do đâu mà có? ", answer: "Do lao động thặng dư của người công nhân tư bản." },
{ question: "Mục đích của lưu thông hàng hóa tư bản là gì? ", answer: "Giá trị thặng dư" },
{ question: "Giá trị thặng dư được sáng tạo ra trong giai đoạn nào? ", answer: "Sản xuất" },
{ question: "Những điều kiện nào để sức lao động trở thành hàng hóa?", answer: "Người lao động được tự do thân thể, mất hết tư liệu sản xuất và không còn gì để sống phải bán sức lao động để tồn tại" },
{ question: "Giá trị sức lao động được đo bằng gì? ", answer: "Giá trị tư liệu sinh hoạt cần thiết để tái sản xuất sức lao động của người công nhân và cho con cái người công nhân cộng với phí tổn đào tạo" },
{ question: "Trong xã hội tư bản cần phải làm gì để đảm bảo sự công bằng và tiến bộ xã hội? ", answer: "Cần đấu tranh trong phân chia công bằng hợp lý giá trị thặng dư" },
{ question: "Giá trị thặng dư là gì? ", answer: "Giá trị mới dôi ra ngoài giá trị sức lao động" },
{ question: "Tư bản là gì?", answer: "Giá trị mang lại giá trị thặng dư." },
{ question: "Mặt lượng của tư bản bất biến trong quá trình sản xuất sẽ như thế nào? ", answer: "Không thay đổi" },
{ question: "Phương pháp bóc lột giá trị thặng dư tương đối là gì? ", answer: "Rút ngắn thời gian lao động tất yếu" },
{ question: "Thực chất của tích lũy tư bản là gì? ", answer: "Chuyển một phần giá trị thặng dư thành tư bản" },
{ question: "Tập trung tư bản là gì? ", answer: "Sự gia tăng quy mô của tư bản thông qua hợp nhất các tư bản cá biệt" },
{ question: "Tiền lương danh nghĩa trong chủ nghĩa tư bản là gì? ", answer: "Số tiền mà nhà tư bản trả cho công nhân làm thuê" },
{ question: "Mặt lượng của tư bản khả biến trong quá trình sản xuất sẽ như thế nào? ", answer: "" },
{ question: "Khối lượng giá trị thặng dư biểu hiện cái gì? ", answer: "Quy mô của bóc lột tư bản" },
{ question: "Phương pháp bóc lột thặng dư tuyệt đối là gì? ", answer: "Kéo dài thời gian lao động và tăng cường độ lao động" },
{ question: "Thực chất tích tụ tư bản là gì? ", answer: "Tăng thêm quy mô của tư bản cá biệt qua tích lũy tư bản" },
{ question: "Điều kiện để có thới gian lao động thặng dư là gì? ", answer: "Sản xuất ra nhiều hơn mức cần thiếtđể tái tạo sức lao động" },
{ question: "Tác dụng chủ yếu của quy luật giá trị thặng dư là gì? ", answer: "Là động lực phát triển chủ ngĩa tư bản" },
{ question: "Mâu thuẫn kinh tế cơ bản của chủ nghĩa tư bản là gì? ", answer: "Mâu thuẫn giữa tính xã hội hóa cao của lực lượng sản xuất với chế độ chiếm hữu tư nhân về tư liệu sản xuất" },
{ question: "Tỉ suất giá trị thặng dư biểu hiện cái gì?", answer: "Trình độ bóc lột" },
{ question: "Tiền lương trong chủ nghĩa tư bản là gì? ", answer: "Sự biểu hiện bằng tiền của giá trị sức lao động" },
{ question: "Giá trị thặng dư và lợi nhuận giống nhau ở điểm gì? ", answer: "Đều bặt nguồn từ lao động thặng dư" },
{ question: "Cấu tạo hữu cơ của tư bản là gì? ", answer: "Cấu tạo giá trị " },
{ question: "Chi phí sản xuất tư bản là gì? ", answer: "Chi phí mà nhà tư bản bỏ ra để sản xuất hàng hóa" },
{ question: "Cấu tạo kỹ thuật phản ánh cái gì? ", answer: "Trình độ phát triển của lực lượng sản xuất" },
{ question: "Căn cứ nào phân chia tư bản thành tư bản cố định và tư bản lưu động?", answer: "Phương thức chu chuyển của giá trị vào sản phẩm" },
{ question: " Lợi nhuận bình quân là gì?", answer: "Lợi nhuận mà mỗi nhà tư bản thu được??" },
{ question: "Nguồn gốc của giá trị thặng dư do đâu mà có? ", answer: "Do lao động thặng dư của người công nhân tư bản." },
{ question: "Điều kiện để sức lao động trở thành hàng hoá: ", answer: "Người lao động được tự do về thân thể và bị mất hết về tư liệu sản xuất." },
{ question: "Mặt lượng của tư bản khả biến trong quá trình sản xuất sẽ thay đổi như thế nào? ", answer: "Chuyển dần giá trị vào sản phẩm." },
{ question: "Giá trị của hàng hoá sức lao động phụ thuộc vào: ", answer: "Năng suất lao động xã hội, nhất là những ngành sản xuất tư liệu sinh hoạt." },
{ question: "Phương pháp bóc lột giá trị thặng dư tương đối: ", answer: "Rút ngắn thời gian lao động tất yếu trong điều kiện giữ nguyên độ dài ngày lao động như cũ." },
{ question: "Mặt lượng của tư bản bất biến trong quá trình sản xuất sẽ thay đổi như thế nào? ", answer: "b.	Không tăng về lượng." },
{ question: "Muốn tăng cường bóc lột giá trị thặng dư tương đối phải: ", answer: "Tăng năng suất lao động trong các ngành sản xuất ra tư liệu sinh hoạt." },
{ question: "Tốc độ chu chuyển của tư bản tăng thì: ", answer: "Khối lượng tư bản hoạt động trong năm tăng, làm cho khối lượng giá trị thặng dư tăng, do đó tỷ suất lợi nhuận tăng." },
{ question: "Mối quan hệ giữa lợi nhuận và giá trị thặng dư: ", answer: "Lợi nhuận là hinh thức biến tướng của giá trị thặng dư nhưng thường khác nhau về lượng. " },
{ question: "Tư bản cho vay là: ", answer: "Là tư bản tiền tệ mà người chủ sở hữu đưa nó cho nhà tư bản khác sử dụng để được nhận một số lợi tức nhất định." },
{ question: "Nguyên nhân dẫn đến sự bình quân hóa lợi nhuận là do: ", answer: "Cạnh tranh giữa các ngành." },
{ question: "Tư bản cho vay huy động từ: ", answer: "Tiền nhàn rỗi của các nhà tư bản sản xuất và các tầng lớp dân cư." },
{ question: "Tiền lương thực tế: ", answer: "Là số lượng và chất lượng tư liệu sinh hoạt mà người công nhân mua được bằng tiền lương danh nghĩa của mình." },
{ question: "Nguồn gốc của lợi tức: ", answer: "Là một phần của giá trị thặng dư tạo ra trong sản xuất." },
{ question: "Điều kiện để chuyển mô hình tái sản xuất giản đơn tư bản chủ nghĩa sang mô hình tái sản xuất mở rộng tư bản chủ nghĩa là ở chỗ: ", answer: "b.	Phải có tích luỹ tư bản để tăng quy mô tư bản ứng trước." },
{ question: "Quá trình tập trung tư bản sẽ đưa đến: ", answer: "Làm tăng quy mô của tư bản cá biệt." },
{ question: "Điều kiện để tư bản tuần hoàn một cách bình thường là: ", answer: "Vừa có sự kế tiếp liên tục giữa ba giai đoạn, vừa tồn tại cùng một lúc ba hình thức tư bản." },
{ question: " Tích luỹ tư bản là quá trình:", answer: "Biến một phần giá trị thặng dư thành tư bản." },
{ question: "Giá trị thặng dư là: ", answer: "Là giá trị mới dôi ra ngoài giá trị sức lao động bị nhà tư bản chiếm không." },
{ question: "Nhân tố chủ yếu ảnh hưởng đến tốc độ chu chuyển của tư bản: ", answer: "Thời gian sản xuất và thời gian lưu thông để tư bản thực hiện một vòng tuần hoàn." },
{ question: "Việc phân chia tư bản thành tư bản cố định và tư bản lưu động là căn cứ vào:  ", answer: "Phương thức (đặc điểm) chu chuyển về mặt giá trị vào sản phẩm của mỗi loại tư bản." },
{ question: "Tốc độ chu chuyển chung của tư bản ứng trước sẽ: ", answer: "Ảnh hưởng theo tỉ lệ thuận tới tỉ suất giá trị thặng dư hàng năm." },
{ question: "Tuần hoàn của chu chuyển tư bản là: ", answer: "Sự vận động liên tục của tư bản từ hình thức tư bản tiền tệ sang hình thức khác rồi trở về hình thức ban đầu với lượng giá trị lớn hơn." },
{ question: "Tỉ suất giá trị thặng dư hàng năm phụ thuộc vào: ", answer: "Tốc độ chu chuyển chung của tư bản ứng trước." },
{ question: "Để chống hao mòn vô hình giải pháp là tốt nhất: ", answer: "Sử dụng hết công suất của máy bằng cách làm ba ca trong một ngày, do đó phải thuê thêm lao động." },
{ question: "Lợi nhuận mà nhà tư bản thương nghiệp thu được là do: ", answer: "Nhà tư bản công nghiệp nhường một phần giá trị thặng dư cho nhà tư bản thương nghiệp để thực hiện hàng hoá cho họ." },
{ question: "Sự tồn tại của hoạt động thương nghiệp:", answer: "Có lợi cho nền kinh tế xã hội." },
{ question: "Xét trong quan hệ sản xuất tư bản chủ nghĩa giai cấp công nhân là? ", answer: "Giai cấp không có tư liệu sản xuất, làm thuê cho nhà tư bản, bị nhà tư bản bóc lột giá trị thặng dư." },
{ question: "Quá trình sản xuất TBCN là:  ", answer: "Sự thống nhất giữa quá trình sản xuất ra giá trị sử dụng và quá trình sản xuất ra giá trị thặng dư" },
{ question: "Giá trị sử dụng của hàng hóa sức lao động: ", answer: "Thỏa mãn nhu cầu của người mua nó" },
{ question: "Điểm đặc biệt của hàng hóa sức lao động là:  ", answer: "Tạo ra giá trị mới lớn hơn giá trị bản thân nó" },
{ question: "Điểm đặc biệt của giá trị hàng hóa sức lao động là:  ", answer: "Khi tiêu dùng nó tạo ra giá trị mới lớn hơn giá trị bản thân nó" },
{ question: "Thời gian sản xuất không bao gồm: ", answer: "Thời gian tiêu thụ hàng hóa" },
{ question: "Giá trị thặng dư siêu ngạch là: ", answer: "a.	Do tăng năng suất lao động cá biệt." },
{ question: "Một công nhân làm việc 8h/ngày, m’ = 300%. Sau đó nhà tư bản kéo dài thời gian lao động lên 10h; trong điều kiện giá trị sức lao động không đổi Xác định sự thay đổi của m’ trong xí nghiệp? Nhà tư bản đã tăng thêm giá trị thặng dư bằng phương pháp nào?", answer: "m’ = 375%, phương pháp sản xuất giá trị thặng dư tuyệt đối" },
{ question: "Tỷ suất lợi nhuận bình quân hình thành do:", answer: "b.	Cạnh tranh giữa các ngành " },
{ question: "Trong lịch sử nhân loại thì hình thức quan hệ sản xuất nào sinh ra chế độ bóc lột sức lao động thặng dư đối với GCCN? ", answer: "c.	Tư bản chủ nghĩa" },
{ question: "Khi nghiên cứu PTSX TBCN, C. Mác bắt đầu từ: ", answer: "Sản xuất hàng hóa giản đơn và hàng hóa" },
{ question: "Nhân tố nào là cơ bản thúc đẩy CNTB ra đời nhanh chóng? ", answer: "Tích lũy nguyên thủy" },
{ question: "Những lựa chọn nào được coi là tư bản?  ", answer: "Nhà để cho thuê" },
{ question: "Sức lao động trở thành hàng hóa một cách phổ biến khi nào? ", answer: "Trong nền sản xuất hàng hóa tư bản chủ nghĩa" },
{ question: "Kéo dài tuyệt đối ngày lao động của công nhân trong điều kiện thời gian lao động tất yếu không đổi là cách thức thực hiện của phương pháp?", answer: "Sản xuất giá trị thặng dư tuyệt đối" },
{ question: "Phương pháp sản xuất giá trị thặng dư tuyệt đối được áp dụng chủbyếu vào giai đoạn nào? ", answer: "Giai đoạn đầu của CNTB" },
{ question: "Giá trị thặng dư tương đối là kết quả của việc? ", answer: "Nâng cao năng suất lao động xã hội" },
{ question: "Địa tô tuyệt đối có ở loại ruộng đất nào? ", answer: "Tất cả các đáp án đều đúng" },
{ question: "Việc mua bán nô lệ và mua bán sức lao động được so sánh như thế nào?", answer: "Khác nhau hoàn toàn" },
{ question: "Chọn ý đúng về sức lao động và lao động: ", answer: "Sức lao động là hàng hóa, lao động không phải là hàng hóa" },
{ question: "Các luận điểm dưới đây, luận điểm nào sai? ", answer: "Bóc lột sản phẩm thặng dư chỉ có ở CNTB" },
{ question: "Khi nói về phương pháp sản xuất giá trị thặng dư tuyệt đối, nhận định nào dưới đây không đúng? ", answer: "Ngày lao động thay đổi" },
{ question: "Tiền công thực tế thay đổi thế nào? Chọn các phát biểu sai dưới đây: ", answer: "Biến đổi cùng chiều với lạm phát" },
{ question: "Khi nào lợi nhuận bằng giá trị thặng dư? ", answer: "Khi cung = cầu" },
{ question: "Địa tô chênh lệch I và chênh lệch II khác nhau ở: ", answer: "Địa tô chênh lệch I do độ màu mỡ tự nhiên của đất mang lại, địa tô chênh lệch II do độ màu mỡ nhân tạo đem lại" },
{ question: "Nguyên nhân có địa tô chênh lệch II là do: ", answer: "Do đầu tư thêm mà có" },
{ question: "Loại ruộng đất nào chỉ có địa tô tuyệt đối? ", answer: "Ruộng tốt" },
{ question: "Địa tô tuyệt đối có ở loại ruộng đất nào? ", answer: "Tất cả các đáp án đều đúng" },
//Chương 4

{ question: "Nguyên nhân ra đời của CNTB độc quyền là: ", answer: "c.	Do sự tập trung sản xuất dưới tác động của cuộc cách mạng KH – CN" },
{ question: "Mối quan hệ giữa độc quyền và cạnh tranh: ", answer: "a.	Làm cho cạnh tranh gay gắt hơn" },
{ question: "Xuất khẩu tư bản là:  ", answer: "d.	Đầu tư tư bản ra nước ngoài" },
{ question: "Xuất khẩu hàng hóa là:  ", answer: "b.	Đưa hàng hóa ra bán ở nước ngoài để thực hiện giá trị" },
{ question: "Đầu tư tư bản ra nước ngoài và xuất khẩu tư bản là: ", answer: "Một hình thức đầu tư, khác nhau về tên gọi" },
{ question: "Vì sao trong CNTB độc quyền cạnh tranh không bị thủ tiêu? ", answer: "b.	Vì các tổ chức độc quyền cạnh tranh với nhau" },
{ question: "Trong giai đoạn CNTB độc quyền có những hình thức cạnh tranh nào? ", answer: "d.	Tất cả các hình thức cạnh tranh trên" },
{ question: "Trong giai đoạn CNTB độc quyền: ", answer: "a.	Quy luật giá trị vẫn hoạt động" },
{ question: "Trong thời kỳ CNTB độc quyền: ", answer: "b.	Mâu thuẫn giữa GCVS và GCTS ngày càng sâu sắc hơn" },
{ question: "Sự xuất hiện của CNTB độc quyền nhà nước làm cho: ", answer: "c.	Làm hạn chế tác động tiêu cực của độc quyền" },
{ question: "Phương thức sản xuất TBCN gồm có 2 giai đoạn. Đó là: ", answer: "CNTB tự do cạnh tranh và CNTB độc quyền" },
{ question: "Nhà kinh điển nào sau đây nghiên cứu sâu về CNTB độc quyền? ", answer: "V.I. Lenin" },
{ question: "CNTB độc quyền xuất hiện vào thời kỳ lịch sử nào? ", answer: "Cuối thế kỷ 19 đầu thế kỷ 20" },
{ question: "Các thành viên tham gia vào Cácten sẽ thống nhất với nhau về: ", answer: "Tất cả các đáp án đều đúng" },
{ question: "Các thành viên tham gia vào Xanhđica thống nhất với nhau về: ", answer: "Tiêu thụ hàng hóa" },
{ question: "Ý nào dưới đây thể hiện đặc điểm của xuất khẩu tư bản là: ", answer: "Mang hàng hóa ra bán ở nước ngoài để thực hiện giá trị" },
{ question: "Hình thức tổ chức độc quyền nào độc lập về khâu sản xuất? ", answer: "Cácten và Xanhđica" },
{ question: "Công ty Samsung của Hàn Quốc đầu tư xây dựng nhà máy tại Việt Nam. Đây là hình thức xuất khẩu tư bản nào?", answer: "Xuất khẩu tư bản nhà nước" },
{ question: "CNTB độc quyền là ? ", answer: "Một giai đoạn phát triển của PTSX TBCN" },
{ question: "Cơ chế kinh tế của CNTB độc quyền nhà nước gồm : ", answer: "Cơ chế thị trường, độc quyền tư nhân và sự can thiệp của nhà nước" },
{ question: "Trong giai đoạn CNTB tự do cạnh tranh quy luật giá trị thặng dư biểu hiện thành:", answer: "Qui luật tỷ suất lợi nhuận bình quân" },
{ question: "Chọn các ý đúng dưới đây khi nói về CNTB độc quyền: ", answer: "Cạnh tranh có những hình thức mới." },
{ question: "Chủ thể xuất khẩu tư bản của CNTB ngày nay chủ yếu là: ", answer: "Các tổ chức độc quyền xuyên quốc gia" },
{ question: "Trong CNTB ngày nay, xuất khẩu tư bản chủ yếu theo hướng: ", answer: "Các nước tư bản phát triển xuất khẩu lẫn nhau" },
{ question: "Trong CNTB ngày nay, các trùm tài chính thống trị nền kinh tế thông qua: ", answer: "Kết hợp chế độ tham dự với chế độ uỷ nhiệm" },
{ question: "Hình thức tổ chức và cơ chế thống trị của tư bản tài chính trong CNTB ngày nay thay đổi là do: ", answer: "Lực lượng sản xuất phát triển, nhiều ngành mới xuất hiện" },
{ question: "Cơ chế kinh tế của CNTB độc quyền nhà nước gồm: ", answer: "Cơ chế thị trường, độc quyền tư nhân và sự can thiệp của nhà nước" },
{ question: "Sở hữu độc quyền nhà nước là sự kết hợp của: ", answer: "Sở hữu nhà nước và sở hữu độc quyền tư nhân" },
{ question: "CNTB độc quyền nhà nước là: ", answer: "Một quan hệ kinh tế, chính trị, xã hội" },
{ question: "Trong cơ chế của CNTB độc quyền nhà nước thì: ", answer: "Nhà nước phụ thuộc vào tổ chức độc quyền" },
{ question: "Sự ra đời của CNTB độc quyền nhà nước nhằm mục đích: ", answer: "Phục vụ lợi ích của tổ chức độc quyền tư nhân" },
{ question: "Bản chất của CNTB độc quyền nhà nước là: ", answer: "Sự kết hợp tổ chức độc quyền tư nhân và nhà nước tư sản" },
{ question: "Nguyên nhân hình thành lợi nhuận độc quyền là: ", answer: "Do địa vị độc quyền đem lại" },
{ question: "Các tổ chức độc quyền sử dụng giá cả độc quyền để: ", answer: "Chiếm đoạt giá trị thặng dư của người khác" },
{ question: "Khi CNTB độc quyền ra đời sẽ: ", answer: "Làm cho các quy luật kinh tế của sản xuất hàng hoá và của CNTB có hình thức biểu hiện mới" },
{ question: "Kết quả cạnh tranh giữa các tổ chức độc quyền trong cùng một ngành là: ", answer: "Một sự thoả hiệp hoặc một bên phá sản" },
{ question: "Chọn nhận định đúng trong các nhận định dưới đây? ", answer: "Độc quyền là con đẻ của cạnh tranh, đối lập với cạnh tranh nhưng không thủ tiêu cạnh tranh." },
{ question: "Các cuộc xâm chiếm thuộc địa của các nước đế quốc diễn ra mạnh mẽ vào thời kỳ nào? ", answer: "Cuối thế kỷ 19 - đầu thế kỷ 20" },
{ question: "Các cường quốc đế quốc xâm chiếm thuộc địa nhằm: ", answer: "Tất cả các đáp án đều đúng" },
{ question: "Vì sao trong CNTB độc quyền cạnh tranh không bị thủ tiêu? ", answer: "Vì cạnh tranh là quy luật khách quan của kinh tế hàng hoá" },
{ question: "Các tổ chức độc quyền của các quốc gia cạnh tranh trên thị trường quốc tế dẫn đến: ", answer: "Luôn Thoả hiệp với nhau để hình thành các tổ chức độc quyền quốc tế" },
{ question: "Mục đích của xuất khẩu tư bản là: ", answer: "Chiếm đoạt giá trị thặng dư và các nguồn lợi khác ở nước nhập khẩu tư bản" },
{ question: "Hế độ tham dự của tư bản tài chính được thiết lập do: ", answer: "Số cổ phiếu khống chế nắm công ty mẹ, con, cháu." },
{ question: "Vai trò mới của ngân hàng trong giai đoạn CNTB độc quyền là: ", answer: "Khống chế hoạt động của nền kinh tế TBCN" },
{ question: "Sự ra đời của tư bản tài chính là kết quả của sự phát triển: ", answer: "Quá trình xâm nhập liên kết độc quyền ngân hàng với độc quyền công nghiệp" },
{ question: "Kết luận sau đây là của ai? Tự do cạnh tranh đẻ ra tập trung sản xuất và sự tập trung sản xuất này khi phát triển đến mức độ nhất định, lại dẫn tới độc quyền question: ", answer: "Lênin" },
//Chương 5

{ question: "Nước ta đang ở giai đoạn nào của quá trình xây dựng và phát triển CNXH? ", answer: "Thời kỳ quá độ lên CNXH" },
{ question: "Hãy kể tên các loại hình sở hữu cơ bản ở nước ta? ", answer: "Sở hữu toàn dân, sở hữu tập thể, sở hữu tư nhân, sở hữu hỗn hợp" },
{ question: "Vai trò chủ yếu của nhà nước khi tham gia thị trường? ", answer: "Điều tiết nền kinh tế vĩ mô thông qua luật pháp và chính sách" },
{ question: "Điểm khác biệt căn bản nhất về cơ sở hạ tầng của nền kinh tế thị trường định hướng XHCN so với nền kinh tế thị trường TBCN là gì ?", answer: "Thành phần kinh tế Nhà nước giữ vai trò chủ đạo" },
{ question: "Hệ thống chính trị do Đảng Cộng sản lãnh đạo là đặc trưng về lĩnh vực gì của nền kinh tế thị trường tại Việt Nam ?", answer: "Kiến trúc thượng tầng" },
{ question: "Trong các nguyên nhân hình thành nền kinh tế thị trường định hướng XHCN tại Việt Nam, nguyên nhân nào là đặc thù riêng của Việt Nam?", answer: "Lịch sử Việt Nam có Đảng cộng sản lãnh đạo cuộc cách mạng Dân tộc dân chủ" },
{ question: "Hãy chọn đáp án sai khi nói về vai trò của Đảng đối với hoàn thiện thể chế kinh tế thị trường định hướng XHCN: ", answer: "Điều hành nền kinh tế xã hội" },
{ question: "Điểm khác biệt căn bản về kiến trúc thượng tầng thể chế kinh tế thị trường định hưỡng XHCN với thể chế kinh tế thị trường TBCN là gì?", answer: "Đảng cộng sản lãnh đạo" },
{ question: "Chọn đáp án đúng điền vào … “Lợi ích kinh tế là lợi ích …, lợi ích thu được khi thực hiện các hoạt động kinh tế của con người.”.", answer: "Vật chất" },
{ question: "Đâu là lợi ích kinh tế của chủ doanh nghiệp? ", answer: "Lợi nhuận" },
{ question: "Có mấy vai trò chính của lợi ích kinh tế đối với các chủ thể kinh tế - xã hội? ", answer: "2" },
{ question: "Chọn phát biểu không đúng về sự mâu thuẫn trong các quan hệ lợi ích kinh tế: ", answer: "Lợi ích của chủ thể này được thực hiện thì lợi ích của chủ thể khác cũng trực tiếp hoặc gián tiếp thực hiện. " },
{ question: "Có bao nhiêu nhân tố ảnh hưởng đến lợi ích kinh tế? ", answer: "4" },
{ question: "Xác định các câu trả lời đúng về sự điều tiết vĩ mô của nhà nước là nhằm:", answer: "Tất cả các đáp án đều đúng" },
{ question: " Yếu tố nào là chủ yếu nhất trong tổng thu của ngân sách nhà nước?", answer: "Các khoản thu từ thuế" },
{ question: "Cơ cấu lợi ích trong thành phần kinh tế có vốn đầu tư nước ngoài là:", answer: "Lợi ích của chủ đầu tư nước ngoài, lợi ích nhà nước, lợi ích người lao động" },
{ question: "Trong thời kỳ quá độ ở nước ta tồn tại nhiều nguyên tắc phân phối. Vì trong thời kỳ quá độ còn:", answer: "Tất cả các đáp án đều đúng" },
{ question: "Mô hình kinh tế tổng quát trong thời kỳ quá độ ở nước ta là: ", answer: "Kinh tế thị trường định hướng XHCN" },
{ question: "Phân phối theo lao động là nguyên tắc cơ bản, áp dụng thích hợp nhất cho: ", answer: "Thành phần kinh tế dựa trên sở hữu công về TLSX" },
{ question: "Kinh tế thị trường định hướng xã hội chủ nghĩa ở VN là: ", answer: "Nền kinh tế có nhiều hình thức sở hữu, nhiều thành phần kinh tế, kinh tế nhà nước giữ vai trò chủ đạo" },
{ question: "Đâu không phải là đặc trưng chung của kinh tế thị trường? ", answer: "Kết hợp phát triển kinh tế thị trường và giải quyết các vấn đề xã hội." },
{ question: "Tìm câu trả lời chính xác nhất cho câu hỏi dưới đây về cơ chế thị trường. Cơ chế thị trường là: ", answer: "Cơ chế điều tiết nền kinh tế theo các quy luật của kinh tế thị trường" },
{ question: "Lợi ích kinh tế là gì: ", answer: "Là lợi ích vật chất, lợi ích thu được khi thực hiện các hoạt động kinh tế của con người." },
{ question: "Mâu thuẫn về lợi ích kinh tế là? ", answer: "Cội nguồn của các xung đột xã hội" },
{ question: "Kinh tế thị trường nói chung và kinh tế thị trường định hướng XHCN quan hệ với nhau thế nào? ", answer: "Vừa có đặc điểm chung vừa có đặc điểm riêng" },
{ question: "Phân phối theo vốn kết hợp với phân phối theo lao động được áp dụng ở thành phần kinh tế nào? ", answer: "Cho kinh tế tập thể." },
{ question: "Kinh tế tư nhân, kinh tế cá thể và kinh tế tư bản tư nhân giống nhau ở điểm cơ bản nào?", answer: "Tư hữu TLSX, tuy mức độ khác nhau" },
{ question: "Thành phần kinh tế tư bản nhà nước ở Việt Nam hiện nay thể hiện ở: ", answer: "Các liên doanh giữa kinh tế nhà nước với kinh tế tư bản tư nhân" },
{ question: "Nền tảng của nền kinh tế quốc dân theo định hướng XHCN là", answer: "Kinh tế nhà nước" },
{ question: "Dựa vào tiêu chí nào để đánh giá hiệu quả xây dựng QHSX mới ở nước ta? ", answer: "LLSX phát triển, cải thiện đời sống, thực hiện công bằng xã hội" },
{ question: "Quan hệ phân phối có tính lịch sử. Yếu tố nào quy định tính lịch sử đó? ", answer: "Quan hệ sản xuất" },
{ question: "Tính chất của quan hệ phân phối do nhân tố nào quyết định? ", answer: "Quan hệ sản xuất" },
{ question: "Quan hệ nào có vai trò quyết định đến phân phối? ", answer: "Quan hệ sở hữu TLSX" },
{ question: " Cơ cấu lợi ích trong thành phần kinh tế tư bản tư nhân là:", answer: "Lợi ích chủ doanh nghiệp, lợi ích cá nhân, lợi ích xã hội" },
{ question: "Cơ cấu lợi ích trong thành phần kinh tế cá thể, tiểu chủ: ", answer: "Lợi ích cá nhân, lợi ích xã hội." },
{ question: "Cơ cấu lợi ích trong thành phần kinh tế tư bản nhà nước là ", answer: "Lợi ích doanh nghiệp, lợi ích xã hội, lợi ích cá nhân" },
{ question: "Cơ cấu lợi ích trong thành phần kinh tế tập thể là gì? ", answer: "Lợi ích tập thể, lợi ích xã hội, lợi ích cá nhân." },
{ question: "Cơ cấu lợi ích trong thành phần kinh tế nhà nước là:  ", answer: "Lợi ích nhà nước, lợi ích tập thể, lợi ích cá nhân" },
{ question: "Câu nói: ở đâu không có lợi ích chung, ở đó không có sự thống nhất về mục đích là của ai? ", answer: "Ph.Ăng ghen" },
{ question: "Nhân tố nào quyết định lợi ích kinh tế? ", answer: "Quan hệ sở hữu" },
{ question: "Động lực quan trọng nhất của sự phát triển kinh tế là: ", answer: "Lợi ích kinh tế" },
{ question: " Hiện nay trong nền kinh tế thị trường ở nước ta, nhà nước có chức năng kinh tế gì?", answer: "Tất cả các đáp án đều đúng" },
{ question: "Sự quản lý của nhà nước trong kinh tế thị trường định hướng XHCN và kinh tế thị trường TBCN khác nhau. Sự khác nhau đó chủ yếu do: ", answer: "Mục tiêu phát triển kinh tế - xã hội" },
{ question: "Trong các nguyên tắc phân phối dưới đây, nguyên tắc nào là chủ yếu nhất ở nước ta hiện nay? ", answer: "Phân phối theo lao động" },
{ question: "Sự khác biệt cơ bản giữa kinh tế thị trường định hướng XHCN với kinh tế thị trường TBCN là: ", answer: "Vai trò chủ đạo của kinh tế nhà nước" },
{ question: " Các thành phần kinh tế cùng hoạt động trong TKQĐ. Chúng quan hệ với nhau thế nào?", answer: "Tự nguyện hợp tác với nhau, cạnh tranh với nhau, đấu tranh loại trừ nhau" },
{ question: "Kinh tế nhà nước giữ vai trò chủ đạo. Biểu hiện nào dưới đây không đúng về vai trò chủ đạo: ", answer: "Chiếm tỷ trọng lớn" },
{ question: "Chọn các ý đúng về sở hữu và thành phần kinh tế:", answer: "Một hình thức sở hữu có thể hình thành nhiều thành phần kinh tế" },
{ question: "Trong TKQĐ ở nước ta sở hữu tư nhân: ", answer: "Tồn tại đan xen với các hình thức sở hữu khác." },
{ question: "Trong TKQĐ ở nước ta, sở hữu nhà nước giữ vai trò gì? ", answer: "Chủ đạo trong cơ cấu sở hữu ở nước ta" },
{ question: "Mô hình kinh tế thị trường định hướng XHCN ở nước ta được chính thức nêu ra ở Đại hội nào của Đảng CSVN? ", answer: "Đại hội IX" },
{ question: "Thời kỳ quá độ lên CNXH ở nước ta bắt đầu từ khi nào? ", answer: "Sau đại thắng mùa xuân 1975" },
{ question: " Nhà nước can thiệp vào các khâu nào của quá trình sản xuất?", answer: "Sản xuất - phân phối - trao đổi - tiêu" },
{ question: "Nhà nước tư sản đảm nhận đầu tư vào ngành nào? ", answer: "Đầu tư lớn, thu hồi vốn chậm, lợi nhuận ít" },
//Chương 6

{ question: " Đặc trưng cơ bản của cuộc cách mạng công nghiệp lần thứ 3", answer: "Sử dụng công nghệ thông tin để tự động hóa sản xuất" },
{ question: " Nội dung cơ bản của cuộc cách mạng công nghiệp lần thứ 4 được xác định là:", answer: "Tất cả các đáp án đều đúng" },
{ question: "Nội dung cơ bản của cuộc cách mạng công nghiệp lần thứ 4 được xác định là:", answer: "Tất cả các đáp án đều đúng" },
{ question: "Đặc trưng của cuộc cách mạng công nghiệp lần thứ 2 là: ", answer: "Sử dụng năng lượng điện và động cơ điện để tạo ra dây truyền sản xuất hàng loạt." },
{ question: "Thực chất công nghiệp hóa ở nước ta là gì? ", answer: "Thay lao động thủ công lạc hậu bằng lao động sử dụng máy móc có NSLĐ xã hội cao." },
{ question: "Đâu là động lực của công nghiệp hóa, hiện đại hóa? ", answer: "Khoa học-công nghệ" },
{ question: "Sự phát triển đại công nghiệp cơ khí ở Anh bắt đầu từ: ", answer: "Các ngành công nghiệp nhẹ" },
{ question: "Quá trình công nghiệp hoá, hiện đại hoá làm cho cơ cấu lao động chuyển dịch, ý nào dưới đây không đúng? ", answer: "Lao động nông nghiệp chỉ giảm tuyệt đối, lao động công nghiệp chỉ tăng tương đối." },
{ question: "Trong quan hệ kinh tế đối ngoại, việc đảm bảo ổn định về môi trường chính trị, kinh tế xã hội là:", answer: "Giải pháp chủ yếu nhằm mở rộng, nâng cao hiệu quả kinh tế đối ngoại." },
{ question: "Chủ trương trong quan hệ quốc tế của Việt Nam là: ", answer: "Việt Nam sẵn sàng là bạn, là đối tác tin cậy của các nước trong cộng đồng quốc tế" },
{ question: "Trong quan hệ kinh tế đối ngoại phải dựa trên nguyên tắc bình đẳng. Hiểu thế nào là đúng về nguyên tắc bình đẳng? ", answer: "Tất cả các đáp án đều đúng" },
{ question: "Đâu là tiêu chuẩn cơ bản để xác định phương án phát triển, lựa chọn dự án đầu tư và công nghệ trong quá trình công nghiệp hoá, hiện đại hoá?", answer: "Hiệu quả kinh tế - xã hội" },
{ question: " Nước nào tiến hành CNH đầu tiên trên thế giới?", answer: "Anh" },
{ question: "Trong các luận điểm dưới đây, luận điểm nào không đúng? ", answer: "CNH chỉ tất yếu đối với những nước đi lên CNXH." },
{ question: "Chủ trương đẩy mạnh CNH, HĐH đất nước được đề ra ở Đại hội nào của Đảng?", answer: "Đại hội VIII" },
{ question: "Đường lối CNH ở nước ta lần đầu tiên được đề ra ở Đại hội nào của Đảng? ", answer: "Đại hội III" },
{ question: "Về mặt lịch sử, cho đến nay loài người đã và đang trải qua mấy cuộc cách mạng công nghiệp? ", answer: "4" },
{ question: "Cách mạng công nghiệp lần thứ nhất diễn ra trong khoảng thời gian nào? ", answer: "Từ giữa thế kỷ XVIII đến giữa thế kỷ XIX" },
{ question: "Cách mạng công nghiệp lần thứ hai diễn ra trong khoảng thời gian nào? ", answer: "Từ nửa cuối thế kỷ XIX đến đầu thế kỷ XX" },
{ question: "Cách mạng công nghiệp lần thứ ba diễn ra trong khoảng thời gian nào? ", answer: "Từ khoảng những năm đầu thập niên 60 của thế kỷ XX đến cuối thế kỷ XX" },
{ question: "Cách mạng công nghiệp lần thứ tư được đề cập đến lần đầu vào năm nào và ở đâu? ", answer: "Năm 2011, tại Đức" },
{ question: "Đặc trưng của cuộc cách mạng công nghiệp lần thứ nhất là: ", answer: "Sử dụng năng lượng nước và hơi nước để cơ khí hóa sản xuất." },
{ question: "Trong hệ thống cơ cấu kinh tế, cơ cấu nào là quan trọng nhất?", answer: "Cơ cấu ngành kinh tế" },
{ question: "Chuyển dịch cơ cấu ngành kinh tế theo hướng hiện đại, hiệu quả chính là: ", answer: "Tăng tỷ trọng của ngành công nghiệp và dịch vụ, giảm tỷ trọng của ngành nông nghiệp trong GDP" },
{ question: "Khi nói về hội nhập kinh tế quốc tế, nhận định nào sau đây là không đúng? ", answer: "Hội nhập kinh tế quốc tế là con đường có thể giúp cho các nước đang và kém phát triển tận dụng thời cơ phát triển, rút ngắn, thu hẹp khoảng cách với các nước tiên tiến, tuyệt nhiên không có gì bất lợi và rủi ro thách thức" },
{ question: " ", answer: "" },
    // Add more question-answer pairs
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
	// Xóa biểu tượng nếu có
	const iconPrevios = document.getElementById("textScannerIcon");
	if (iconPrevios) {
		iconPrevios.remove();
	}
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
