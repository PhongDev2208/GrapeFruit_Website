// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  {
    question: "Chế độ khởi động động cơ khi xe đang chạy cụm nào sẽ phát ra công suất:",
    answer: "D. Cụm MG1 và cụm MG2"
  },
  {
    question: "Tăng tốc nhẹ với động cơ cụm nào sẽ phát ra công suất:",
    answer: "C. Động cơ và MG2"
  },
  {
    question: "Tốc độ thấp ổ định cụm nào sẽ phát ra công suất:",
    answer: "A. Động cơ và MG2"
  },
  {
    question: "Tăng tốc tối đa cụm nào sẽ phát ra công suất:",
    answer: "D. Động cơ và MG2"
  },
  {
    question: "Tốc độ cao ổn định cụm nào sẽ phát ra công suất:",
    answer: "A. Động cơ và MG2 hoạt động, MG1 hoạt động ở chế độ phanh"
  },
  {
    question: "Tốc độ tối đa cụm nào sẽ phát ra công suất:",
    answer: "C. Tất cả đều đúng"
  },
  {
    question: "Hình ảnh này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "B. Chế độ khởi động động cơ khi xe đang chạy"
  },
  {
    question: "Đồ thị công suất này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "B. Chế độ khởi động động cơ khi xe đang chạy"
  },
  {
    question: "Đồ thị công suất này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "A. Tăng tốc nhẹ với động cơ"
  },
  {
    question: "Hình ảnh này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "D. Tốc độ cao ổn định"
  },
  {
    question: "Đồ thị công suất này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "D. Tốc độ thấp ổn định"
  },
  {
    question: "Hình ảnh này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "C. Tốc độ tối đa"
  },
  {
    question: "Đồ thị công suất này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "B. Tăng tốc tối đa"
  },
  {
    question: "Đồ thị công suất này thể hiện chế độ làm việc nào của xe Hybrid:",
    answer: "D. Tốc độ cao ổn định"
  },
  {
    question: "Tại sao phải làm mát Pin trên xe điện:",
    answer: "A. Duy trì nhiệt độ làm việc lý tưởng trong khoảng từ 20 – 40 độ C"
  },
  {
    question: "Ảnh hưởng của nhiệt độ cao tới PIN",
    answer: "D. Pin càng tiêu hao càng nhiều năng lượng điện, động cơ càng dễ rơi vào tình trạng quá nhiệt"
  },
  {
    question: "Hệ thống làm mát PIN xe điện có những loại nào",
    answer: "D. Tất cả đều đúng"
  },
  {
    question: "Làm mát pin xe điện bằng chất lỏng – dung dịch làm mát chuyên dụng là:",
    answer: "B. Chất làm mát dạng lỏng được luân chuyển tuần hoàn giữa bộ pin và bộ tản nhiệt thông qua bơm"
  },
  {
    question: "Làm mát pin xe điện bằng cánh tản nhiệt là:",
    answer: "C. Nhiệt được truyền từ bộ pin đến cánh tản nhiệt thông qua quá trình dẫn nhiệt"
  },
  {
    question: "Làm mát pin xe điện bằng không khí là:",
    answer: "A. Quạt hoặc máy thổi sẽ thổi không khí qua bề mặt pin nóng, giúp nhiệt lượng được truyền ra bên ngoài"
  },
  {
    question: "Chi tiết số 1 trong hệ thống truyền công suất trên hình là:",
    answer: "B. Máy phát MG2"
  },
  {
    question: "Chi tiết số 2 trong hệ thống truyền công suất trên hình là:",
    answer: "A. Bánh răng mặt trời"
  },
  {
    question: "Chi tiết số 3 trong hệ thống truyền công suất trên hình là:",
    answer: "D. Cần dẫn"
  },
  {
    question: "Chi tiết số 4 trong hệ thống truyền công suất trên hình là:",
    answer: "C. Bánh răng bao"
  },
  {
    question: "Chi tiết số 5 trong hệ thống truyền công suất trên hình là:",
    answer: "B. Bánh răng dẫn động xích"
  },
  {
    question: "Chi tiết số 6 trong hệ thống truyền công suất trên hình là:",
    answer: "A. Máy phát MG1"
  },
  {
    question: "Chi tiết số 7 trong hệ thống truyền công suất trên hình là:",
    answer: "D. Bộ giảm chấn cụm truyền động"
  },
  {
    question: "Chi tiết số 8 trong hệ thống truyền công suất trên hình là:",
    answer: "C. Động cơ"
  },
  {
    question: "Chi tiết số 9 trong hệ thống truyền công suất trên hình là:",
    answer: "B. Xích êm"
  },
  {
    question: "Chi tiết số 10 trong hệ thống truyền công suất trên hình là:",
    answer: "A. Bánh răng dẫn động trung gian"
  },
  {
    question: "Chi tiết số 11 trong hệ thống truyền công suất trên hình là:",
    answer: "D. Bánh răng quả dứa chủ động bộ truyền cuối cùng"
  },
  {
    question: "Chi tiết số 12 trong hệ thống truyền công suất trên hình là:",
    answer: "C. Bánh răng bị động trung gian"
  },
  {
    question: "Chi tiết số 13 trong hệ thống truyền công suất trên hình là:",
    answer: "B. Bánh răng truyền động cuối cùng"
  },
  {
    question: "Chi tiết số 14 trong hệ thống truyền công suất trên hình là:",
    answer: "A. Bộ truyền vi sai"
  },
  {
    question: "Chi tiết số 15 trong hệ thống truyền công suất trên hình là:",
    answer: "D. Bơm dầu"
  },
  {
    question: "Trong công thức dưới đây thì Mc chỉ đại lượng:",
    answer: "A. Moment xoắn của cần dẫn"
  },
  {
    question: "Trong công thức dưới đây thì Ms chỉ đại lượng:",
    answer: "B. Moment xoắn của bánh răng mặt trời"
  },
  {
    question: "Trong công thức dưới đây thì MR chỉ đại lượng:",
    answer: "C. Moment xoắn của bánh răng bao"
  },
  {
    question: "Trong công thức dưới đây thì Nc chỉ đại lượng:",
    answer: "D. Công suất của cần dẫn"
  },
  {
    question: "Trong công thức dưới đây thì NS chỉ đại lượng:",
    answer: "A. Công suất của bánh răng mặt trời"
  },
  {
    question: "Trong công thức dưới đây thì NR chỉ đại lượng:",
    answer: "B. Công suất của bánh răng bao"
  },
  {
    question: "Trong công thức dưới đây thì c chỉ đại lượng:",
    answer: "C. Vận tốc góc của cần dẫn"
  },
  {
    question: "Trong công thức dưới đây thì s chỉ đại lượng:",
    answer: "A. Vận tốc góc của bánh răng mặt trời"
  },
  {
    question: "Trong công thức dưới đây thì R chỉ đại lượng:",
    answer: "B. Vận tốc góc của bánh răng bao"
  },
  {
    question: "Trong công thức dưới đây thì rc chỉ đại lượng:",
    answer: "B. Bán kính của cần dẫn"
  },
  {
    question: "Trong công thức dưới đây thì rS chỉ đại lượng:",
    answer: "A. Bán kính của bánh răng mặt trời"
  },
  {
    question: "Trong công thức dưới đây thì rR chỉ đại lượng:",
    answer: "C. Bán kính của bánh răng bao"
  },
  {
    question: "Trong công thức dưới đây thì Fk chỉ đại lượng:",
    answer: "A. Lực kéo tiếp tuyến tại bánh xe chủ động"
  },
  {
    question: "Trong công thức dưới đây thì Mt chỉ đại lượng:",
    answer: "D. Moment tổng sau khi phối hợp hai nguồn công suất"
  },
  {
    question: "Trong công thức dưới đây thì itl chỉ đại lượng:",
    answer: "C. Tỷ số truyền của hệ thống truyền lực"
  },
  {
    question: "Trong công thức dưới đây thì r chỉ đại lượng:",
    answer: "B. Bán kính bánh xe chủ động"
  },
  {
    question: "Trong công thức dưới đây thì tl chỉ đại lượng:",
    answer: "B. Hiệu suất của hệ thống truyền lực"
  },
  {
    question: "Trong công thức dưới đây thì Pk chỉ đại lượng:",
    answer: "A. Công suất kéo tại bánh xe chủ động"
  },
  {
    question: "Công suất kéo tại bánh xe chủ động Pk được xác định bằng:",
    answer: "D. Tất cả đều đúng"
  },
  {
    question: "Trong công thức dưới đây thì *v* chỉ đại lượng:",
    answer: "D. Vận tốc của ôtô"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "C. Lực cản lăn"
  },
  {
    question: "Trong công thức dưới đây thì m chỉ đại lượng:",
    answer: "C. Khối lượng ôtô"
  },
  {
    question: "Trong công thức dưới đây thì f chỉ đại lượng:",
    answer: "C. Hệ số cản lăn"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "B. Lực cản gió"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "B. Hệ số cản gió"
  },
  {
    question: "Trong công thức dưới đây thì S chỉ đại lượng:",
    answer: "C. Diện tích cản gió"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "A. Lực cản quán tính"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "A. Hệ số khối lượng cầu trước"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "D. Lực cản leo dốc"
  },
  {
    question: "Trong công thức dưới đây thì chỉ đại lượng:",
    answer: "D. Góc dốc của mặt đường"
  },
  {
    question: "Phương trình sau thể hiện:",
    answer: "C. Phương trình cân bằng lực kéo"
  },
  {
    question: "Ô tô đạt vận tốc cực đại khi:",
    answer: "C. Bao gồm ;  và"
  },
  {
    question: "Điều kiện để Ôtô đạt vận tốc cực đại:",
    answer: "B."
  },
  {
    question: "Ô tô đạt được độ leo dốc cực đại khi:",
    answer: "A. Tất cả các yếu tố trên"
  },
  {
    question: "Ô tô đạt gia tốc cực đại khi:",
    answer: "D. Tất cả đều đúng"
  },
  {
    question: "Đồ thị ở hình bên thể hiện:",
    answer: "C. Đồ thị cân bằng lực kéo"
  },
  {
    question: "Đồ thị ở hình bên thể hiện:",
    answer: "B. Đồ thị mô tả lực kéo tiếp tiếp tại bánh xe chủ động"
  },
  {
    question: "Khi chạy lùi, động cơ trên xe Hybrid sẽ hoạt động như thế nào?",
    answer: "B. Sử dụng mô tơ MG2"
  },
  {
    question: "Vị trí số “B” trên xe Hybrid được sử dụng nhằm mục đích nào?",
    answer: "A. Giúp xe đạt hiệu quả giảm tốc tốt hơn."
  },
  {
    question: "Khi dừng xe Hybrid lâu dài người lái nên để cần số ở vị trí nào?",
    answer: "D. Nên để cần số ở vị trí P"
  },
  {
    question: "Khi xe Hybrid đang chạy bởi động cơ điện, điều kiện nào sau đây sẽ khiến động cơ xăng hoạt động:",
    answer: "C. Khi đạp mạnh bàn đạp ga & khi pin Hybrid có trạng thái nạp thấp"
  },
  {
    question: "Phương pháp để lái xe Hybrid tiết kiệm nhiên liệu là gì?",
    answer: "B. Tăng tốc và giảm tốc từ từ."
  },
  {
    question: "Khi khởi hành, xe Hybrid sử dụng loại động cơ nào:",
    answer: "A. Động cơ điện."
  },
  {
    question: "Khác biệt giữa hoạt động của xe Hybrid khi tăng tốc (toàn tải) và khi chạy duy trì tốc độ:",
    answer: "D. Điện bổ sung từ ắc quy Hybrid giúp tăng công suất của động cơ điện."
  },
  {
    question: "Cách để nhận biết Pin HV đang xuống cấp :",
    answer: "A. Khi pin Hybrid đã thực sự xuống cấp thì sẽ xuất hiện DTC (mã chẩn đoán hư hỏng)"
  },
  {
    question: "Công thức này dùng để tính:",
    answer: "B. Độ leo dốc cực đại"
  },
  {
    question: "Công thức này dùng để tính:",
    answer: "A. Gia tốc cực đại"
  },
  {
    question: "Phương trình này dùng để tính:",
    answer: "A. Vận tốc cực đại của ôtô"
  },
  {
    question: "Công thức này dùng để tính:",
    answer: "A. Tỷ số truyền của bộ truyền hành tinh ở tốc độ tối đa"
  },
  {
    question: "Công thức này dùng để tính:",
    answer: "A. Tỷ số truyền của bộ truyền hành tinh ở tốc độ cao ổn định"
  },
  {
    question: "Trên đồ thị này thì thể hiện lực cản gì:",
    answer: "A. Lực cản tổng cộng của mặt đường"
  },
  {
    question: "Trên đồ thị này thì Of  thể hiện lực cản gì:",
    answer: "A. Đồ thị lực cản lăn"
  },
  {
    question: "Trên đồ thị này thì  thể hiện lực cản gì:",
    answer: "A. Đồ thị lực cản gió"
  },
  {
    question: "Sơ đồ này thể hiện:",
    answer: "A. Khi phối hợp hai nguồn công suất"
  },
  {
    question: "Sơ đồ này thể hiện:",
    answer: "A. Sơ đồ truyền công suất của trục E"
  },
  {
    question: "Sơ đồ này thể hiện:",
    answer: "A. Sơ đồ truyền công suất của trục M"
  },
  {
    question: "Mô hình này thể hiện:",
    answer: "A. Mô hình phối hợp công suất từ hai động cơ"
  },
  {
    question: "Đồ thị này thể hiện:",
    answer: "A. Đường đặc tính ngoài động cơ điện"
  },
  {
    question: "Trên mô hình này trục E thể hiện:",
    answer: "A. Trục E là trục nhận công suất từ động cơ đốt trong"
  },
  {
    question: "Trên mô hình này trục M thể hiện:",
    answer: "A. Trục M là trục phát công suất từ động cơ điện"
  },
  {
    question: "Pin nhiên liệu tạo ra điện áp thấp có thể sử dụng qua bao nhiêu bộ chuyển đổi DC/DC?",
    answer: "B. Hai bộ"
  },
  {
    question: "Trong hệ thống pin nhiên liệu, bộ chuyển đổi nào truyền điện cho các tải phụ?",
    answer: "B. Bộ chuyển đổi DC/DC"
  },
  {
    question: "Tại sao cần sử dụng pin hoặc siêu tụ điện như ESS trong FCHEV?",
    answer: "C. Để sạc và xả điện năng theo nhu cầu"
  },
  {
    question: "Một trong những nhược điểm của việc sử dụng pin nhiên liệu là gì?",
    answer: "A. Đáp ứng điện năng chậm"
  },
  {
    question: "Hệ thống truyền lực lai hybrid pin nhiên liệu cần có gì để hoạt động hiệu quả?",
    answer: "B. Một chiến lược kiểm soát tổng thể mới"
  },
  {
    question: "Đặc điểm nào không phải là một yếu tố quan trọng trong hiệu suất của FCHEV?",
    answer: "C. Độ bền của vật liệu thân xe"
  },
  {
    question: "Điều nào dưới đây là vai trò chính của RESS trong hệ thống FCEV?",
    answer: "C. Lưu trữ năng lượng tạm thời và hỗ trợ phanh tái sinh"
  },
  {
    question: "Thời gian khởi động lâu của pin nhiên liệu chủ yếu là do yếu tố nào?",
    answer: "B. Mật độ công suất thấp của hệ thống"
  },
  {
    question: "Việc lai ghép hệ thống pin nhiên liệu với nguồn năng lượng khác nhằm mục đích gì?",
    answer: "A. Tối ưu hóa hiệu suất và khắc phục hạn chế"
  },
  {
    question: "Các nguồn năng lượng cho FCEV và FCHEV thường được lựa chọn dựa trên yếu tố nào?",
    answer: "B. Kiến trúc công suất chính của xe điện"
  },
  {
    question: "Mục đích chính của việc sử dụng siêu tụ điện trong FCHEV là gì?",
    answer: "C. Hỗ trợ năng lượng tạm thời và sạc lại nhanh"
  },
  {
    question: "Khi pin nhiên liệu hoạt động, khi nào nguồn pin sẽ được tắt?",
    answer: "C. Khi pin nhiên liệu đạt nhiệt độ tối ưu"
  },
  {
    question: "Các cấu hình chuyển đổi công suất trong hệ thống pin nhiên liệu có thể được phân loại thành bao nhiêu loại chính?",
    answer: "B. Hai loại"
  },
  {
    question: "Một trong những lợi ích của việc sử dụng pin nhiên liệu trong xe điện là gì?",
    answer: "C. Phát thải gần như bằng không"
  },
  {
    question: "Đặc điểm nào không phải là một yếu tố cần thiết để tối ưu hóa hiệu suất của FCHEV?",
    answer: "C. Kích thước của hệ thống phanh"
  },
  {
    question: "Nguồn năng lượng nào sau đây là không bền vững nhất do quy trình sản xuất và tiêu thụ của nó?",
    answer: "C. Nhiệt điện từ than đá"
  },
  {
    question: "Việc sử dụng pin nhiên liệu hydro trong xe FCEV gặp phải thách thức lớn nhất nào trong quá trình phát triển?",
    answer: "C. Cần có cơ sở hạ tầng tiếp nhiên liệu hydro"
  },
  {
    question: "Để duy trì hiệu suất tối ưu của hệ thống pin nhiên liệu, điều gì là điều kiện tiên quyết nhất?",
    answer: "B. Thiết kế bộ chuyển đổi hiệu quả"
  },
  {
    question: "Dựa vào các phương thức truyền năng lượng cho xe điện, phương thức nào ít được sử dụng nhất hiện nay?",
    answer: "B. Sạc không dây"
  },
  {
    question: "Đâu là yếu tố kỹ thuật chính cần được cải thiện để tăng hiệu quả của hệ thống truyền động điện trong xe FCEV?",
    answer: "B. Kích thước và trọng lượng của bộ chuyển đổi điện"
  },
  {
    question: "Đâu không phải là một nhược điểm của việc sử dụng năng lượng từ pin mặt trời trong sản xuất điện?",
    answer: "D. Độ tin cậy thấp trong điều kiện thời tiết xấu"
  },
  {
    question: "Trong các hệ thống truyền động điện, tại sao BEV không phải là lựa chọn tối ưu cho quãng đường dài?",
    answer: "D. Tất cả các lý do trên"
  },
  {
    question: "Trong quá trình cung cấp năng lượng cho xe điện, vai trò nào không thuộc về RESS?",
    answer: "C. Cung cấp điện liên tục cho động cơ điện"
  },
  {
    question: "Tại sao việc phát triển cơ sở hạ tầng tiếp nhiên liệu hydro cho xe FCEV lại quan trọng?",
    answer: "C. Để đảm bảo khả năng tiếp nhiên liệu nhanh chóng cho xe"
  },
  {
    question: "Trong số các nguồn năng lượng, nguồn nào có khả năng gây ô nhiễm nước và đất nhiều nhất?",
    answer: "C. Nhiệt điện từ dầu mỏ"
  },
  {
    question: "Pin Lithium-ion được thiết kế đặc biệt cho khả năng gì?",
    answer: "B. Tích điện cao và khả năng chu kỳ sạc cao"
  },
  {
    question: "Tỷ lệ công suất thụ của pin xe điện thường được biểu thị bằng đơn vị nào?",
    answer: "B. Ampe giờ (Ah)"
  },
  {
    question: "Sự khác biệt chính giữa pin xe điện và ắc quy ô tô thông thường là gì?",
    answer: "A. Pin xe điện được thiết kế cho khả năng sạc lại hàng ngày"
  },
  {
    question: "Thị trường nào đã thu lợi từ sự tiến bộ trong công nghệ pin Lithium-ion từ cuối những năm 1990?",
    answer: "B. Thị trường ô tô điện và xe lai"
  },
  {
    question: "Khi dòng điện trong pin bằng 0, điện áp đầu cuối được gọi là gì?",
    answer: "A. Điện áp mạch hở"
  },
  {
    question: "Đặc điểm nào sau đây không phải là một nhược điểm của pin Lithium-ion?",
    answer: "D. Có thể sạc lại hàng ngày"
  },
  {
    question: "Điều gì xảy ra với điện áp khi pin đang được sạc?",
    answer: "B. Tăng lên"
  },
  {
    question: "Một trong những mục tiêu chính trong thiết kế hệ thống nguồn năng lượng cho ô tô điện là gì?",
    answer: "B. Tăng khả năng lưu trữ năng lượng và giảm trọng lượng"
  },
  {
    question: "Chi phí pin xe điện đã giảm bao nhiêu phần trăm kể từ năm 2010 đến tháng 12 năm 2021?",
    answer: "C. 95%"
  },
  {
    question: "Pin cho xe điện thường sử dụng điện áp danh định nào?",
    answer: "B. 6 V hoặc 12 V"
  },
  {
    question: "Nội điện trở trong pin xe điện ảnh hưởng đến điều gì?",
    answer: "C. Hiệu suất phóng điện và sạc"
  },
  {
    question: "Các cell pin trong xe điện thường được mắc như thế nào để tăng điện áp?",
    answer: "B. Nối tiếp"
  },
  {
    question: "Lượng điện tích lưu trữ trong pin được đo bằng đơn vị nào?",
    answer: "B. Ampe giờ (Ah) hoặc coulomb"
  },
  {
    question: "Cực nào trong pin xe điện được gọi là cực dương khi pin đang xả?",
    answer: "A. Cực cathode"
  },
  {
    question: "Đặc điểm nào sau đây là mục tiêu của nghiên cứu và phát triển trong ngành ô tô điện hiện nay?",
    answer: "B. Tăng cường khả năng lưu trữ năng lượng và linh hoạt trong quản lý"
  }
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
    // Xóa biểu tượng nếu có
    const iconPrevios = document.getElementById("textScannerIcon");
    if (iconPrevios) {
      iconPrevios.remove();
    }
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
