// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  // Chuong 1
  {
    question: "Chi bộ Cộng sản đầu tiên ở  Việt Nam thành lập ở ?  ",
    answer: "Nhà số 5D, phố Hàm Long - Hà Nội ",
  },
  {
    question: "Đảng cộng sản Việt Nam do Chủ tịch Hồ Chí Minh sáng lập: ",
    answer: "3/2/1930 ",
  },
  {
    question: "Đảng cộng sản Việt Nam là đội tiên phong của? ",
    answer: "Giai cấp công nhân; nhân dân lao động; của dân tộc Việt Nam ",
  },
  {
    question: "Nền tảng tư tưởng, kim chỉ nam của Đảng ta? ",
    answer: "Chủ nghĩa Mác – Lênin, Tư tưởng Hồ Chí Minh ",
  },
  {
    question:
      "Lịch sử Đảng cộng sản Việt Nam là một chuyên ngành, một bộ phận của: ",
    answer: "Khoa học lịch sử ",
  },
  {
    question: "Đối tượng nghiên cứu của khoa học lịch sử là: ",
    answer:
      "Sự ra đời, phát triển và hoạt động lãnh đạo của Đảng qua các thời kỳ lịch sử ",
  },
  {
    question: "Nghiên cứu lịch sử Đảng là: ",
    answer:
      " Làm rõ hệ thống tổ chức Đảng, công tác xây dựng Đảng qua các thời kỳ lịch sử",
  },
  {
    question: "Chức năng của khoa học lịch sử Đảng? ",
    answer: "Tất cả đều đúng ",
  },
  {
    question: "Một trong những nhiệm vụ của khoa học Lịch sử Đảng là: ",
    answer: "Trình bày có hệ thống Cương lĩnh, đường lối của Đảng ",
  },
  {
    question: "Phương pháp nghiên cứu, học tập môn lịch sử Đảng? ",
    answer: " Các phương pháp khác",
  },
  {
    question:
      "Nghiên cứu, giảng dạy, học tập lịch sử Đảng Cộng sản Việt Nam cần chú trọng phương pháp",
    answer: "Vận dụng lý luận vào thực tiễn ",
  },
  {
    question:
      "Những giai cấp bị trị ở Việt Nam dưới chế độ thuộc địa của đế quốc Pháp là: ",
    answer:
      "Công nhân, nông dân, tiểu tư sản, tư sản dân tộc, địa chủ vừa và nhỏ.",
  },
  {
    question: "Thực dân Pháp nổ súng tấn công xâm lược Việt Nam khi nào?  ",
    answer: " 31/8/1858",
  },
  {
    question:
      "Dưới chế độ cai trị của chủ nghĩa thực dân, nhân dân Việt Nam có yêu cầu bức thiết nhất là gì? ",
    answer: " Độc lập dân tộc ",
  },
  {
    question:
      "Nguyễn Ái Quốc lựa chọn con đường giải phóng dân tộc theo khuynh hướng chính trị vô sản vào thời gian nào? ",
    answer: "1920 ",
  },
  {
    question: "Tên của tổ chức này được thành lập Tháng 6 năm 1925 ? ",
    answer: "Hội Việt Nam Cách mạng Thanh niên",
  },
  {
    question: "Tổ chức cộng sản nào ra đời đầu tiên ở Việt Nam? ",
    answer: " Đông Dương cộng sản Đảng ",
  },
  {
    question:
      "Do đâu Nguyễn Ái Quốc đã triệu tập và chủ trì Hội nghị thành lập Đảng đầu năm 1930? ",
    answer: " Sự chủ động của Nguyễn Ái Quốc",
  },
  {
    question:
      "Đại biểu các tổ chức cộng sản nào đã tham dự Hội nghị thành lập Đảng đầu năm 1930? ",
    answer: "Đông Dương cộng sản Đảng và An Nam cộng sản Đảng ",
  },
  {
    question:
      "Hội nghị Hợp nhất thành lập Đảng Cộng sản Việt Nam (3/2/1930) thông qua các văn kiện nào sau đây: ",
    answer:
      "Chánh cương vắn tắt, Sách lược vắn tắt, Điều lệ vắn tắt và Chương trình vắn tắt ",
  },
  {
    question: "Nội dung nào sau đây nằm trong Cương lĩnh đầu tiên của Đảng? ",
    answer:
      "Đánh đổ đế quốc chủ nghĩa Pháp và bọn phong kiến, làm cho nước Nam hoàn toàn độc lập. ",
  },
  {
    question:
      "Nguyễn Ái Quốc đọc tác phẩm của V.I. Lênin: Sơ thảo lần thứ nhất những luận cương về vấn đề dân tộc và vấn đề thuộc địa, đăng trên báo Nhân đạo vào thời gian nào? ",
    answer: "7/1920 ",
  },
  {
    question: "Đảng Cộng sản Việt Nam ra đời là sự kết hợp của: ",
    answer:
      "Chủ nghĩa Mác - Lênin với phong trào yêu nước và phong trào công nhân. ",
  },
  {
    question: "Văn kiện nào của Đảng đặt nhiệm vụ chống đế quốc lên hàng đầu? ",
    answer:
      " Chính cương vắn tắt, Sách lược vắn tắt do Hội nghị thành lập Đảng thông qua",
  },
  {
    question:
      "Hồ Chí Minh chủ trì trực tiếp Hội nghị nào sau khi Người về nước? ",
    answer: "Hội nghị trung ương 8 vào năm 1941 ",
  },
  {
    question:
      "Nguyên nhân chủ yếu và có ý nghĩa quyết định sự bùng nổ và phát triển của cao trào cách mạng Việt Nam năm 1930? ",
    answer: "Sự lãnh đạo của Đảng Cộng sản Việt Nam ",
  },
  {
    question: "Chính sách văn hóa thực dân Pháp thi hành ở nước ta là?  ",
    answer: "Ngu dân ",
  },
  {
    question:
      "Chủ nghĩa Mác chỉ rõ, muốn giành được thắng lợi trong cuộc đấu tranh thực hiện sứ mệnh lịch sử của mình, giai cấp công nhân cần làm gì? ",
    answer: "Lập ra Đảng Cộng sản ",
  },
  {
    question:
      "Đối với các dân tộc thuộc địa, Cách mạng tháng Mười Nga đã nêu lên tấm gương sáng gì? ",
    answer: "Giải phóng dân tộc bị áp bức ",
  },
  {
    question:
      "Giai cấp nông dân dưới bộ máy thống trị của thực dân Pháp tại Việt Nam phải chịu bao nhiêu tầng áp bức, bóc lột? ",
    answer: "2 ",
  },
  {
    question:
      "Trước chiến tranh thế giới thứ nhất xã hội Việt Nam có những giai cấp nào? ",
    answer: "Địa chủ phong kiến, nông dân và công nhân ",
  },
  {
    question:
      "Vì sao các phong trào dân tộc theo khuynh hướng chính trị tư sản và tiểu tư sản thành thị trước ngày Đảng Cộng sản Việt Nam ra đời bị thất bại? ",
    answer:
      "Hệ tư tưởng lỗi thời của giai cấp lãnh đạo; Không có đường lối chính trị rõ ràng; Không có hệ thống tổ chức chặt chẽ; không có khả năng tập hợp quần chúng ",
  },
  {
    question: "Vai trò của Quốc tế cộng sản đối với cách mạng Việt Nam? ",
    answer:
      "Quốc tế Cộng sản có vai trò quan trọng trong việc truyền bá chủ nghĩa Mác - Lênin và thành lập Đảng Cộng sản Việt Nam ",
  },
  {
    question:
      "Tư tưởng cốt lõi của Cương lĩnh chính trị đầu tiên của Đảng ta? ",
    answer:
      "Độc lập dân tộc gắn liền với chủ nghĩa xã hội (giải phóng dân tộc, giải phóng giai cấp, giải phóng con người). ",
  },
  {
    question:
      "Chủ trương Tổng khởi nghĩa giành chính quyền của Đảng được nêu lên trong Hội nghị nào? ",
    answer: "Hội nghị Tân Trào từ 13 đến 15 tháng 8 năm 1945 ",
  },
  {
    question: "Cao trào cách mạng 1930 - 1931 đã khẳng định trong thực tế: ",
    answer:
      "Đường lối cách mạng do Đảng đề ra là đúng; Khẳng định quyền lãnh đạo và năng lực cách mạng của giai cấp công nhân; Xây dựng khối liên minh công nông trong thực tế. ",
  },
  {
    question:
      "Tháng 12/1927, Việt Nam Quốc dân đảng - Chính đảng của giai cấp tư sản Việt Nam  được thành lập. Lãnh tụ của Đảng là ai? ",
    answer: "Nguyễn Thái Học ",
  },
  {
    question:
      "Trong cao trào cách mạng 1930 – 1931, Đảng đã vận dụng những khẩu hiệu nào để đấu tranh? ",
    answer: "“Độc lập dân tộc” và “ruộng đất dân cày”. ",
  },
  {
    question: "Việt Nam quốc dân đảng là đảng chính trị theo xu hướng nào? ",
    answer: "Dân chủ tư sản ",
  },
  {
    question: "Nguyễn Ái Quốc tham gia Đảng xã hội Pháp vào thời gian nào? ",
    answer: "1920 ",
  },
  {
    question:
      "Các phong trào yêu nước tiêu biểu theo khuynh hướng phong kiến cuối thế kỷ XIX đầu thế kỷ XX?  ",
    answer:
      "Phong trào Cần Vương (1885 - 1896); Khởi nghĩa Yên Thế (1884 - 1913) ",
  },
  {
    question:
      "Những hoạt động chính của Nguyễn Ái Quốc ở Quảng Châu năm 1925? ",
    answer:
      "Tháng 6/1925, thành lập Hội Việt Nam cách mạng thanh niên; Mở lớp huấn luyện cán bộ và ra tờ báo Thanh niên ",
  },
  {
    question: "Đặc điểm chung của giai cấp công nhân Việt Nam? ",
    answer:
      "giai cấp đại diện cho phương thức sản xuất tiên tiến; có tinh thần cách mạng triệt để; có tính tổ chức và kỉ luật cao, mang bản chất quốc tế. ",
  },
  {
    question:
      "Từ năm 1920 đến năm 1928, Nguyễn Ái Quốc đã viết hai tác phẩm nổi tiếng. Cho biết tên của hai tác phẩm ấy? ",
    answer: "“Bản án chế độ thực dân Pháp”; “Đường kách mệnh”   ",
  },
  {
    question:
      "Tính chất và nhiệm vụ của Cách mạng Việt Nam được đề cập trong tác phẩm “Đường kách mệnh” của Nguyễn Ái Quốc? ",
    answer:
      "Cách mạng việt Nam là cách mạng giải phóng dân tộc mở đường tiến lên chủ nghĩa xã hội. Cách mạng là sự nghiệp của quần chúng, nòng cốt là liên minh công nông. ",
  },
  {
    question: "Nhiệm vụ của tổ chức Hội Việt Nam cách mạng thanh niên? ",
    answer:
      "Truyền bá chủ nghĩa Mác - Lênin và đường lối cứu nước của Nguyễn Ái Quốc vào công nhân, nông dân, các tầng lớp nhân dân ",
  },
  {
    question: "Vai trò của tổ chức Hội Việt Nam cách mạng thanh niên? ",
    answer: "Chuẩn bị tiền đề cho việc thành lập Ðảng Cộng sản. ",
  },
  {
    question:
      "Vai trò của Nguyễn Ái Quốc đối với việc thành lập Đảng Cộng sản Việt Nam?  ",
    answer:
      "Chuẩn bị về chính trị, tư tưởng và tổ chức cho việc thành lập Đảng Cộng sản Việt Nam ",
  },
  {
    question:
      "Đảng Cộng sản Việt Nam ra đời từ sự hợp nhất của những tổ chức cộng sản nào? ",
    answer:
      "Đông Dương Cộng sản đảng, An Nam Cộng sản đảng, Đông Dương Cộng sản Liên đoàn. ",
  },
  {
    question: "Tên gọi của Đảng ta qua các thời kỳ? ",
    answer:
      "Tháng 02/1930, Đảng Cộng sản Việt Nam; Tháng 10/1930, Đảng Cộng sản Đông Dương; Tháng 02/1951, Đảng Lao động Việt Nam; Tháng 12/1976, Đảng Cộng sản Việt Nam. ",
  },
  {
    question: "Quốc tế cộng sản III được thành lập khi nào? ",
    answer: "3/1919 ",
  },
  { question: "Tân Việt cách mạng Đảng ra đời năm nào? ", answer: "7/1928 " },
  {
    question: "Phong trào Cần Vương diễn ra vào thời gian nào? ",
    answer: "1885-1896 ",
  },
  {
    question:
      "Tác phẩm nào của Nguyễn Ái Quốc đã vạch rõ âm mưu và thủ đoạn của chủ nghĩa đế quốc che dấu tội ác dưới cái vỏ bọc “khai hóa văn minh”? ",
    answer: "Bản án chế độ thực dân Pháp ",
  },
  {
    question: "Luận cương tháng 10/1930 đã đề cao nhiệm vụ gì? ",
    answer: "Giải phóng giai cấp ",
  },
  {
    question: "Luận cương tháng 10/1930 đã coi nhẹ vai trò của giai cấp nào? ",
    answer: "Tư sản dân tộc, Tiểu tư sản ",
  },
  {
    question:
      "Trong đợt khai thác thuộc địa lần thứ nhất của thực dân Pháp ở nước ta có giai cấp mới nào được hình thành?  ",
    answer: "Giai cấp công nhân  ",
  },
  {
    question: "Đặc điểm ra đời của giai cấp công nhân Việt Nam như thế nào?  ",
    answer: "Cả a, b và c  ",
  },
  {
    question: "Hội Liên hiệp thuộc địa được thành lập vào năm nào?  ",
    answer: "1921  ",
  },
  {
    question:
      "Mâu thuẫn cơ bản và chủ yếu ở Việt Nam đầu thế kỷ XX là mâu thuẫn nào? ",
    answer:
      "Mâu thuẫn giữa dân tộc Việt Nam với đế quốc xâm lược và tay sai của chúng ",
  },
  {
    question:
      "Phong trào đòi trả tự do cho cụ Phan Bội Châu diễn ra sôi nổi năm nào?  ",
    answer: "1925 ",
  },
  {
    question:
      "Nguyễn Ái Quốc từ Liên Xô về Quảng Châu (Trung Quốc) vào thời gian nào?  ",
    answer: "12/1924",
  },
  {
    question:
      "Hội Việt Nam Cách mạng Thanh niên thực hiện chủ trương vô sản hoá khi nào?  ",
    answer: "Cuối năm 1928 đầu năm 1929 ",
  },
  {
    question:
      "Đông Dương Cộng sản Đảng và An nam Cộng sản Đảng được ra đời từ tổ chức tiền thân nào?  ",
    answer: "Hội Việt Nam cách mạng Thanh niên ",
  },
  {
    question:
      "Trong các điểm sau, chỉ rõ điểm khác nhau giữa Cương lĩnh chính trị đầu tiên của Đảng và Luận cương chính trị tháng 10-1930 là:  ",
    answer: "Chủ trương tập hợp lực lượng cách mạng.  ",
  },
  {
    question:
      "Tên của lực lượng vũ trang được thành lập ở Nghệ Tĩnh trong cao trào cách mạng năm 1930 là gì? ",
    answer: "Tự vệ đỏ ",
  },
  {
    question:
      "Tháng 12/1927, Việt Nam Quốc dân đảng – Chính đảng của giai cấp tư sản Việt Nam, được thành lập. Lãnh tụ của Đảng là ai? ",
    answer: "Nguyễn Thái Học ",
  },
  {
    question: "Cuối thế kỷ XIX chủ nghĩa tư bản có sự chuyển biến gì mới? ",
    answer:
      "Chủ nghĩa tư bản đã chuyển từ giai đoạn tự do cạnh tranh sang giai đoạn độc quyền (chủ nghĩa đế quốc) ",
  },
  {
    question: "Chiến tranh thế giới thứ nhất bùng nổ vào thời gian nào? ",
    answer: "1/8/1914 ",
  },
  {
    question: "Một trong những nhiệm vụ của khoa học Lịch sử Đảng là: ",
    answer: "Trình bày có hệ thống Cương lĩnh, đường lối của Đảng ",
  },
  {
    question:
      "Nghiên cứu, giảng dạy, học tập lịch sử Đảng Cộng sản Việt Nam cần chú trọng phương pháp: ",
    answer: "Vận dụng lý luận vào thực tiễn ",
  },
  {
    question:
      "Cuộc chiến tranh thế giới thứ nhất có bao nhiêu người chết và bao nhiêu người bị tàn phế? ",
    answer: "10 triệu người chết và 20 triệu người tàn phế ",
  },
  {
    question:
      "Chủ nghĩa Mác-Lênin chỉ rõ muốn giành được thắng lợi trong cuộc đấu tranh thực hiện sứ mệnh lịch sử của mình, giai cấp công nhân phải làm gì? ",
    answer: "Phải lập ra Đảng Cộng sản ",
  },
  {
    question: "Tuyên ngôn của Đảng Cộng sản viết năm nào? ",
    answer: "Năm 1848 ",
  },
  {
    question: "Tác phẩm Tuyên ngôn của Đảng Cộng sản đã xác định: ",
    answer:
      "Những người cộng sản luôn luôn đại biểu cho lợi ích của toàn bộ phong trào; là bộ phận kiên quyết nhất trong các đảng công nhân ở các nước; họ hiểu rõ những điều kiện, tiến trình và kết quả của phong trào vô sản ",
  },
  {
    question:
      "Từ khi chủ nghĩa Mác-Lênin được truyền bá vào Việt Nam phong trào yêu nước và phong trào công nhân phát triển theo khuynh hướng nào? ",
    answer: " Khuynh hướng cách mạng vô sản",
  },
  {
    question: "Thắng lợi của cách mạng Tháng Mười Nga có ý nghĩa? ",
    answer:
      "Mở ra một thời đại mới “thời đại cách mạng chống đế quốc, thời đại giải  phóng dân tộc” ",
  },
  {
    question: "Đảng cộng sản Đức ra đời vào thời gian nào? ",
    answer: "Năm 1918 ",
  },
  {
    question: "Đảng cộng sản Hunggari ra đời vào thời gian nào? ",
    answer: "Năm 1918 ",
  },
  {
    question: "Đảng cộng sản Mỹ ra đời vào thời gian nào? ",
    answer: "Năm 1919 ",
  },
  {
    question: "Đảng cộng sản Anh ra đời vào thời gian nào? ",
    answer: "Năm 1920 ",
  },
  {
    question: "Đảng cộng sản Pháp ra đời vào thời gian nào? ",
    answer: "Năm 1920 ",
  },
  {
    question: "Đảng cộng sản Trung Quốc ra đời vào thời gian nào? ",
    answer: "Năm 1921 ",
  },
  {
    question: "Đảng cộng sản Nhật Bản ra đời vào thời gian nào? ",
    answer: "Năm 1922 ",
  },
  {
    question: "Sự ra đời của Quốc tế Cộng sản có ý nghĩa gì? ",
    answer:
      "Thúc đẩy sự phát triển của phong trào Cộng sản và công nhân quốc tế ",
  },
  {
    question: "Tầng lớp tiểu tư sản ở Việt Nam bao gồm? ",
    answer: " Học sinh, trí thức, viên chức và những người làm nghề tự do",
  },
  {
    question: "Giai cấp tư sản Việt Nam bao gồm? ",
    answer: "Tư sản công nghiệp, tư sản thương nghiệp ",
  },
  {
    question: "Giai cấp công nhân tập trung nhiều ở đâu? ",
    answer: "Hà Nội, Sài Gòn, Hải Phòng, Nam Định, Vinh, Quảng Ninh ",
  },
  {
    question: "Vua Hàm Nghi xuống chiếu Cần Vương vào thời gian nào?  ",
    answer: " 13/7/1885",
  },
  {
    question: "Cuộc khởi nghĩa Yên Thế diễn ra ở đâu vào thời gian nào? ",
    answer: "Ở Bắc Giang, năm 1884 ",
  },
  { question: "Vua Hàm Nghi bị bắt vào thời gian nào? ", answer: "1888 " },
  {
    question: "Phong trào Đông Kinh nghĩa thục diễn ra vào thời gian nào? ",
    answer: "1907 ",
  },
  {
    question: "Tân Việt cách mạng đảng (1928) ra đời từ tổ chức nào? ",
    answer: "Việt Nam nghĩa đoàn (1925) ",
  },
  {
    question:
      "Vụ ám sát Ba Danh, trùm mộ phu đồn điền cao su của Pháp diễn ra khi nào? ",
    answer: "2/1929 ",
  },
  {
    question:
      "Đại hội lần thứ nhất của Hội Việt Nam cách mạng thanh niên diễn ra vào thời gian nào? ",
    answer: "1929 ",
  },
  {
    question:
      "Đại hội nào của Đảng khẳng định: Tư tưởng Hồ Chí Minh không chỉ là kết quả của sự vận dụng sáng tạo mà còn phát triển sáng tạo chủ nghĩa Mác - Lênin vào điều kiện cụ thể của nước ta?  ",
    answer: "Đại hội IX  ",
  },
  {
    question:
      "Phong trào vô sản hóa (1929) của Hội Việt Nam cách mạng thanh niên diễn ra mạnh nhất ở đâu? ",
    answer: "Bắc Kỳ",
  },
  {
    question: "Điểm tấn công đầu tiên của thực dân Pháp ở VN ? ",
    answer: "Bán đảo Sơn Trà, Đà Nẵng ",
  },
  {
    question: "Bản yêu sách 8 điểm mà Nguyễn Ái Quốc đã gửi đã ? ",
    answer: "Không được giải quyết ",
  },

  //Chương 2
  {
    question: "Sự kiện mở đầu cho sự hoà hoãn giữa Việt Nam và Pháp ",
    answer: " Ký kết hiệp định Sơ bộ 6-3-1946 giữa Việt Nam với Pháp",
  },
  {
    question:
      "Tình hình đất nước ta sau cách mạng tháng Tám năm 1945 được ví như hình ảnh: ",
    answer: " Ngàn cân treo sợi tóc",
  },
  {
    question:
      "Những khó khăn, thách thức đối với Việt Nam sau cách mạng tháng Tám năm 1945: ",
    answer:
      "Các thế lực đế quốc, phản động bao vây, chống phá, kinh tế kiệt quệ và nạn đói hoành hành, hơn 90% dân số không biết chữ ",
  },
  {
    question:
      "Những thuận lợi căn bản của đất nước sau cách mạng tháng Tám năm 1945 ",
    answer:
      "Cách mạng thế giới phát triển mạnh mẽ, hệ thống chính quyền cách mạng nhân dân được thiết lập, nhân dân có quyết tâm bảo vệ chế độ mới.  ",
  },
  {
    question:
      "Kẻ thù chính của cách mạng Việt Nam ngay sau Cách mạng 8- 1945? ",
    answer: " Thực dân Pháp xâm lược.",
  },
  {
    question:
      "Sau ngày tuyên bố độc lập Chính phủ lâm thời đã xác định các nhiệm vụ cấp bách cần giải quyết là: ",
    answer: "Diệt giặc đói, giặc dốt và giặc ngoại xâm ",
  },
  {
    question:
      "Chỉ thị Kháng chiến kiến quốc của Trung ương Đảng ngày 25/11/1945, xác định nhiệm vụ nào là trung tâm, bao trùm nhất? ",
    answer: "Củng cố, bảo vệ chính quyền cách mạng",
  },
  {
    question:
      "Chỉ thị kháng chiến, kiến quốc đã xác định khẩu hiệu cách mạng Việt Nam sau cách mạng tháng Tám năm 1945: ",
    answer: " Dân tộc trên hết, Tổ quốc trên hết",
  },
  {
    question:
      "Đường lối toàn quốc kháng chiến chống thực dân Pháp được hoàn chỉnh và thể hiện tập trung trong văn kiện nào?",
    answer: "Tất cả đều đúng ",
  },
  {
    question:
      "Phong trào mà Đảng ta đã vận động nhân dân chống nạn mù chữ diễn ra sau cách mạng tháng Tám năm 1945 ",
    answer: "Bình dân học vụ ",
  },
  {
    question:
      "Hà Nội được xác định là thủ đô của nước Việt Nam dân chủ cộng hoà vào năm nào?  ",
    answer: " Năm 1946",
  },
  {
    question:
      "Để quân Tưởng và tay sai khỏi kiếm cớ sách nhiễu, Đảng ta chủ trương ",
    answer:
      "Hoa Việt thân thiện, biến xung đột lớn thành xung đột nhỏ, biến xung đột nhỏ thành không có xung đột ",
  },
  {
    question:
      "Đảng ta đã lựa chọn giải pháp gì trong mối quan hệ với thực dân Pháp sau ngày Pháp và Tưởng ký hiệp ước Trùng Khánh (28-2-1946)? ",
    answer: "Thương lượng và hoà hoãn với Pháp ",
  },
  {
    question: "Tại sao Đảng lại lựa chọn giải pháp thương lượng với Pháp? ",
    answer:
      "Buộc quân Tưởng phải rút ngay về nước, tránh được tình trạng cùng một lúc phải đối phó với nhiều kẻ thù. ",
  },
  {
    question:
      "Nhiệm vụ hàng đầu của nhân dân ta trong quá trình kháng chiến chống thực dân Pháp: ",
    answer: " Chống đế quốc giành độc lập dân tộc ",
  },
  {
    question: "Phương châm chiến lược của cuộc kháng chiến chống Pháp là: ",
    answer: "Toàn dân, toàn diện, lâu dài và dựa vào sức mình là chính. ",
  },
  {
    question:
      "Khi bắt đầu tiến hành xâm lược Việt Nam, thực dân Pháp đã thực hiện chiến lược: ",
    answer: "Đánh nhanh, thắng nhanh ",
  },
  {
    question:
      "Ngày 15-10-1947, để đối phó với cuộc tấn công của thực dân Pháp lên căn cứ địa Việt Bắc, Ban Thường vụ Trung ương Đảng đã đề ra: ",
    answer: " Chỉ thị “Phá tan cuộc tấn công mùa Đông của giặc Pháp”",
  },
  {
    question:
      "Những thành tựu căn bản của cách mạng Việt Nam trong việc xây dựng và củng cố chính quyền cách mạng sau 1945 :  ",
    answer: " Tất cả các phương án trên đều đúng",
  },
  {
    question:
      "Tại Đại hội đại biểu toàn quốc lần thứ hai (2/1951), Đảng ta quyết định đổi tên thành: ",
    answer: "Đảng Lao động Việt Nam ",
  },
  {
    question:
      "Đại hội Đảng toàn quốc lần thứ hai của Đảng Lao động Việt Nam đã thông qua một văn kiện mang tính chất cương lĩnh. Đó là: ",
    answer: " Chính cương của Đảng Lao động Việt Nam",
  },
  {
    question:
      "Chính cương Đảng Lao động Việt Nam tháng 2-1951 đã nêu ra các tính chất của xã hội Việt Nam:",
    answer: "Dân chủ nhân dân, một phần thuộc địa và nửa phong kiến ",
  },
  {
    question:
      "Hai đối tượng của cách mạng Việt Nam được nêu ra tại Chính cương Đảng Lao động Việt Nam: ",
    answer: " Thực dân Pháp và phong kiến phản động",
  },
  {
    question:
      "Lực lượng tạo nên động lực cho cách mạng Việt Nam được nêu ra trong Chính cương Đảng Lao động Việt Nam: ",
    answer:
      " Công nhân, nông dân, tiểu tư sản, tư sản dân tộc, địa chủ yêu nước (nhân dân)",
  },
  {
    question:
      "Nhiệm vụ cách mạng được nêu ra tại Chính cương Đảng Lao động Việt Nam: ",
    answer:
      " Đánh đuổi bọn đế quốc xâm lược, giành độc lập và thống nhất thật sự cho dân tộc, xoá bỏ những di tích phong kiến và nửa phong kiến, làm cho người cày có ruộng, phát triển chế độ dân chủ nhân dân, gây cơ sở cho chủ nghĩa xã hội.",
  },
  {
    question:
      "Điều lệ mới của Đảng Lao động đã xác định Đảng đại diện cho quyền lợi của:  ",
    answer: " Giai cấp công nhân và nhân dân lao động Việt Nam ",
  },
  {
    question:
      "Nền tảng tư tưởng và kim chỉ nam được Đảng ta xác định tại Đại hội II là: ",
    answer: "Cả ba phương án trên ",
  },
  {
    question:
      "Trong cương lĩnh thứ ba (2-1951), Đảng ta đã khẳng định nhận thức của mình về con đường cách mạng Việt Nam. Đó là: ",
    answer: "Con đường cách mạng dân tộc, dân chủ, nhân dân  ",
  },
  {
    question:
      "Nhằm đẩy mạnh thực hiện khẩu hiệu “người cày có ruộng”, tháng 11-1953, Hội Nghị BCH TW lần thứ V đã thông qua: ",
    answer: "Cương lĩnh ruộng đất ",
  },
  {
    question:
      "Chiến thắng nào đã căn bản đánh bại âm mưu đánh nhanh, thắng nhanh của thực dân Pháp? ",
    answer: " Việt Bắc",
  },
  {
    question: "Đại hội nào quyết định Đảng ta ra hoạt động công khai? ",
    answer: " Đại hội II",
  },
  {
    question:
      "Đâu là nơi được coi là căn cứ địa cách mạng của cả nước trong kháng chiến chống Pháp? ",
    answer: "Việt Bắc  ",
  },
  {
    question:
      "Chiến dịch lịch sử Điện Biên Phủ diễn ra trong bao nhiêu ngày?  ",
    answer: "56  ",
  },
  {
    question:
      "Ngay sau khi chiến dịch Điện Biên Phủ kết thúc, Hội nghị quốc tế về chấm dứt chiến tranh Đông Dương đó diễn ra tại: ",
    answer: " Giơnevơ  ",
  },
  {
    question:
      "Bộ Chính trị đã ra chỉ thị về việc tổng tuyển cử trong cả nước sau giải phóng thống nhất nước nhà vào ngày nào?  ",
    answer: "25/4/1976  ",
  },
  {
    question: "Cuộc kháng chiến chống thực dân Pháp kéo dài bao nhiêu năm? ",
    answer: "	9 năm ",
  },
  {
    question:
      "Nhiệm vụ hàng đầu của nhân dân ta trong quá trình khỏng chiến chống thực dân Pháp:  ",
    answer: "Chống đế quốc giành độc lập dân tộc   ",
  },
  {
    question: "Năm 1945 đồng bào ta có bao nhiêu người không biết chữ? ",
    answer: "Hơn 90% dân số ",
  },
  {
    question:
      "Theo Nghị quyết của Hội nghị Trung ương lần thứ 8, Ðội du kích Bắc Sơn đã vinh dự được đổi tên thành  ",
    answer: "Ðội Cứu quốc quân Bắc Sơn ",
  },
  {
    question:
      "Điều lệ mới của Đảng Lao động đã xác định Đảng đại diện cho quyền lợi của:  ",
    answer: " Giai cấp công nhân và nhân dân lao động Việt Nam",
  },
  {
    question:
      "Chính cương Đảng Lao Động Việt Nam tháng 2-1951 đã nêu ra các tính chất của xã hội Việt Nam ? ",
    answer: "Dân chủ nhân dân, một phần thuộc địa và nửa phong kiến ",
  },
  {
    question:
      "Cuộc tổng khởi nghĩa đã giành được thành công trên cả nước trong vòng? ",
    answer: " 15 ngày",
  },
  {
    question:
      "Tháng 2/1951, Đảng cộng sản Đông Dương họp Đại hội đại biểu lần thứ hai ở đâu? ",
    answer: "Tuyên Quang ",
  },
  {
    question:
      "Nhiệm vụ cuộc đấu tranh miền Nam và miền Bắc trong giai đoạn 1965-1975 là gì?",
    answer: " Miền Nam là tiền tuyến lớn, miền Bắc là hậu phương lớn",
  },
  {
    question: "Nước ta chiến đấu chống Đế quốc Mỹ trong bao nhiêu năm?",
    answer: "21 năm ",
  },
  {
    question:
      "Nội dung chuyển hướng chỉ đạo chiến lược của Hội nghị Ban Chấp hành Trung ương Đảng lần 6 (11/1939), lần 7 (11/1940) và lần 8 (5/1941)?",
    answer:
      "Xác định tính chất của cách mạng Đông Dương lúc này là cách mạng giải phóng dân tộc; Khởi nghĩa vũ trang được xác định là nhiệm vụ trung tâm; Thành lập Mặt trận Việt Nam độc lập đồng minh và các Hội cứu quốc ",
  },
  {
    question:
      "“Ba mũi giáp công” trong đường lối của Đảng giai đoạn 1965-1975 là gì ",
    answer: "Quân sự, chính trị, binh vận ",
  },
  {
    question: "Tư tưởng chỉ đạo của Đảng trong cuộc đấu tranh ở miền Nam là? ",
    answer: "Giữ vững và phát triển thế tiến công ",
  },
  {
    question: "Nghị quyết hội nghị lần thứ 15 có ý nghĩa lịch sử to lớn là? ",
    answer: " Mở đường cho cách mạng miền Nam",
  },
  {
    question:
      "Quyết định tại hội nghị trung ương lần thứ 5 (11/1953) của đảng là? ",
    answer: "Giảm tô và tiến hành cải cách ruộng đất ",
  },
  {
    question:
      "Cuộc hành quân Lam Sơn 719 của Mỹ - Nguỵ bị đánh bại vào thời gian nào?  ",
    answer: "1971  ",
  },
  {
    question:
      "Hội nghị nào của Đảng đã quyết định mở cuộc Tổng tấn công và nổi dậy Mậu Thân 1968?  ",
    answer: "Hội nghị Bộ Chính trị (12-1967) ",
  },
  {
    question:
      "Chiến lược Chiến tranh đơn phương của đế quốc Mỹ ở miền Nam diễn ra trong giai đoạn nào?  ",
    answer: " 1954-1960 ",
  },
  {
    question: "Mỹ - Diệm đã ra luật 10/59 vào thời gian nào?  ",
    answer: "6/5/1959  ",
  },
  {
    question:
      "Hội nghị nào của Ban Chấp hành Trung ương Đảng (khoá II) đã thông qua Nghị quyết về Đường lối cách mạng miền Nam?  ",
    answer: "Hội nghị lần thứ 15  ",
  },
  {
    question: "Mỹ đã đưa Ngô Đình Diệm lên làm thủ tướng vào thời gian nào?  ",
    answer: " 7/7/1954 ",
  },
  {
    question:
      "Hiệp định Pari về chấm dứt chiến tranh lập lại hoà bình ở Việt Nam được ký khi nào?  ",
    answer: "27/1/1973  ",
  },
  {
    question: "Mặt trận dân tộc giải phóng miền Nam Việt Nam ra đời khi nào? ",
    answer: " 20/12/1960 ",
  },
  {
    question:
      "Tháng 2/1951, Đảng cộng sản Đông Dương họp Đại hội đại biểu lần thứ hai và quyết định? ",
    answer:
      " Quyết định tách Đảng cộng sản Đông Dương thành 3 đảng cách mạng để lãnh đạo cuộc kháng chiến của 3 dân tộc đi tới thắng lợi. Ở Việt Nam, Đảng ra hoạt động công khai lấy tên là Đảng lao động Việt Nam.",
  },
  {
    question:
      "Câu nói: Tất cả chúng ta hãy đoàn kết nhất trí triệu người như một, quyết tâm đánh thắng giặc Mỹ xâm lược... là của ai?  ",
    answer: "Hồ Chí Minh  ",
  },
  {
    question: "Trung ương cục miền Nam được thành lập vào thời gian nào?  ",
    answer: "10/1961  ",
  },
  {
    question:
      "Quân viễn chinh Pháp rút hết khỏi miền Bắc nước ta vào thời gian nào? ở đâu? ",
    answer: "16/5/1955  ",
  },
  {
    question: "Quân ta vào tiếp quản Thủ đô Hà Nội ngày nào?  ",
    answer: "10-10-1954  ",
  },
  {
    question:
      "Giải pháp ký kết hiệp định Giơnevơ, lập lại hoà bình ở Đông Dương (21-7-1954) đã thể hiện rằng: ",
    answer:
      "Việt Nam là một nước nhỏ, lại phải đương đầu với các nước đế quốc xâm lược lớn trong bối cảnh quan hệ quốc tế vô cùng phức tạp  c.Cuộc đấu tranh giành độc lập dân tộc và tự do của Việt Nam là lâu dài, gian khổ, quanh co, giành thắng lợi từng bước là vấn đề có tính chất quy luật ",
  },
  {
    question:
      "Ngày 8-5-1954, Hội nghị Giơnevơ bàn về chấm dứt cuộc chiến tranh ở Đông Dương khai mạc và kết thúc ngày:  ",
    answer: " 21-7-1954 ",
  },
  {
    question:
      "Đối với cách mạng thế giới, thắng lợi của quân và dân ta trong kháng chiến chống Pháp và can thiệp Mỹ, đặc biệt là chiến thắng Điện Biên Phủ đã: ",
    answer: "Cả ba phương án trên  ",
  },
  {
    question:
      "Để phá thế bao vây cô lập, phát triển lực lượng và giành thế chủ động, tháng 6-1950, lần đầu tiên TW Đảng đã chủ trương mở chiến dịch tiến công quy mô lớn. Đó là:  ",
    answer: "Chiến dịch Biên Giới  ",
  },
  {
    question:
      "Đảng ta đã lựa chọn giải pháp gì trong mối quan hệ với thực dân Pháp sau ngày Pháp và Tưởng ký hiệp ước Trùng Khánh (28-2-1946) ? ",
    answer: " Thương lượng và hoà hoãn với Pháp",
  },
  {
    question:
      "Chủ trương và sách lược của Trung ương Đảng trong việc đối phó với các lực lượng đế quốc sau cách mạng tháng Tám -1945:  ",
    answer: " Cả ba phương án kể trên đều đúng",
  },
  {
    question:
      "Với thế chủ động trên chiến trường, từ cuối 1950 đến đầu 1953 quân ta đã tổ chức nhiều chiến dịch tiêu diệt, tiêu hao sinh lực địch. Đó là: ",
    answer:
      "Chiến dịch Trung Du, chiến dịch Đường 18, chiến dịch Hà Nam Ninh, Chiến dịch Hoà Bình, chiến dịch Tây Bắc, chiến dịch Thượng Lào",
  },
  {
    question: "Đại hội lần thứ III của Đảng họp ở đâu? ",
    answer: "Thủ đô Hà Nội ",
  },
  {
    question:
      "Hội nghị hiệp thương chính trị giữa đoàn đại biểu miền Bắc và đoàn đại biểu miền Nam đã họp ở đâu?  ",
    answer: " Sài Gòn ",
  },
  {
    question: "Mỹ tiến hành cuộc đảo chính ở Campuchia vào thời gian nào?  ",
    answer: "3/1970   ",
  },
  {
    question:
      "Đế quốc Mỹ phải chấp nhận cuộc đàm phán với Chính phủ nước Việt Nam dân chủ cộng hoà ở Pari vào thời gian nào?  ",
    answer: "1/1969  ",
  },
  {
    question:
      "Chiến lược Chiến tranh đặc biệt của Mỹ tiến hành ở miền Nam Việt Nam gồm mấy bước?  ",
    answer: "3 bước  ",
  },
  {
    question:
      "Trong chiến tranh ở Việt Nam, Mỹ đã sử dụng mấy chiến lược chiến tranh?  ",
    answer: "4 chiến lược  ",
  },
  {
    question: "Chiến thắng Vạn Tường (Quảng Ngãi) vào thời gian nào?  ",
    answer: "8/1965  ",
  },
  {
    question:
      "Chiến thắng Điện Biên Phủ 7/5/1954 được ghi vào lịch sử như một? ",
    answer: "Như một Bạch Đằng, một Chi Lăng hay một Đống Đa trong thế kỷ XX. ",
  },
  {
    question: "Bản đề cương cách mạng miền Nam do ai chủ trì dự thảo?  ",
    answer: "Lê Duẩn  ",
  },
  {
    question:
      "Mỹ đã đưa quân viễn chinh Mỹ trực tiếp tham chiến ở Việt Nam khi nào?  ",
    answer: " 1965 ",
  },
  {
    question:
      "Quân dân miền Bắc đập tan cuộc tập kích chiến lược bằng B52 của đế quốc Mỹ trong bao nhiêu ngày đêm và từ ngày nào đến này nào? ",
    answer: "12 ngày đêm từ 18 đến 30 tháng 12 năm 1972  ",
  },
  {
    question: "Lý do quân Anh vào nước ta ? ",
    answer: "Giúp thực dân Pháp trở lại xâm lược nước ta ",
  },
  {
    question: "Âm mưu của thực dân Pháp đối với nước ta sau 1945 là ? ",
    answer: "Chuẩn bị  xâm lược Việt Nam lần 2 ",
  },
  {
    question:
      "Câu nói:  Chiến tranh có thể kéo dài năm năm, 10 năm, 20 năm hoặc lâu hơn nữa. Hà Nội, Hải phòng và một số thành phố, xí nghiệp có thể bị tàn phá, song nhân dân Việt Nam quyết không sợ! Không có gì quý hơn độc lập, tự do. đến ngày thắng lợi nhân dân ta sẽ xây dựng lại đất nước ta đàng hoàng hơn, to đẹp hơn! của Chủ tịch Hồ Chí Minh viết vào thời gian nào, trong tác phẩm nào?.  ",
    answer: " Lời kêu gọi Ngày 17- 7- 1966 ",
  },
  {
    question:
      "Câu nói: Miền Nam là máu của máu Việt Nam, là thịt của thịt Việt Nam. Sông có thể cạn, núi có thể mòn song chân lý đó không bao giờ thay đổi là của ai?  ",
    answer: "Hồ Chí Minh  ",
  },
  {
    question:
      "Dự thảo Đề cương cách mạng miền Nam được viết vào thời gian nào?  ",
    answer: "8/1956  ",
  },
  {
    question:
      "Chủ tịch Hồ Chí Minh ra lời kêu gọi đồng bào và chiến sỹ cả nước: Trung Nam Bắc đều là bờ cõi của ta, nước ta sẽ nhất định thống nhất, đồng bào cả nước nhất định được giải phóng vào thời gian nào?  ",
    answer: "22/7/1954 ",
  },
  {
    question:
      "Hiệp định Giơnevơ về chấm dứt chiến tranh, lập lại hoà bình ở Đông Dương đã quy định:  ",
    answer: "Cả hai phương án A và B đều đúng ",
  },
  {
    question:
      "Đối với cách mạng thế giới, thắng lợi của quân và dân ta trong kháng chiến chống Pháp và can thiệp Mỹ, đặc biệt là chiến thắng Điện Biên Phủ đã:  ",
    answer: " Cả ba phương án trên ",
  },
  {
    question:
      "Đối với cách mạng Việt Nam, chiến thắng Điện Biên Phủ  đã có ý nghĩa hết sức to lớn. Đó là:  ",
    answer: "Tất cả các phương án trên đều đúng ",
  },
  {
    question:
      "Kết thúc chiến dịch Điện Biên Phủ, quân và dân ta giành nhiều thắng lợi to lớn. Kết quả đã:  ",
    answer: "Cả hai phương án A và B đều đúng ",
  },
  {
    question:
      "Lá cờ Quyết chiến, quyết thắng trong chiến dịch Điện Biên Phủ được trao cho đơn vị nào?  ",
    answer: " Đại đoàn 312 ",
  },
  {
    question:
      "Chiến dịch Điện Biên Phủ đã diễn ra trong ba đợt và trong khoảng thời gian nào:  ",
    answer: " 13-3-1954 - 7-5-1954 ",
  },
  {
    question:
      "Ai đã được cử làm Tư lệnh kiêm Bí thư Đảng uỷ chiến dịch Điện Biên Phủ  ",
    answer: " Võ Nguyên Giáp ",
  },
  {
    question:
      "Bộ Chính trị đã thông qua phương án mở chiến dịch Điện Biên Phủ vào thời gian nào:  ",
    answer: "6-12-1953  ",
  },
  {
    question:
      "Nava đã đưa tổng số binh lực lên Điện Biên Phủ lúc cao nhất là 16.200 quân; bố trí thành 3 phân khu, 49 cứ điểm. Mục đích là nhằm biến Điện Biên Phủ thành  ",
    answer: "Một tập đoàn cứ điểm mạnh nhất Đông Dương  ",
  },
  {
    question:
      "Ngày 20-11-1953, giữa lúc quân ta tiến quân lên Tây Bắc, Nava vội vàng phân tán lực lượng cho quân nhảy dù, tập trung một khối chủ lực mạnh ở? ",
    answer: " Điện Biên Phủ ",
  },
  {
    question:
      "Ngày 19/10/1946, Thường vụ TW Đảng mở Hội nghị Quân sự toàn quốc lần thứ nhất do ai chủ trì? ",
    answer: " Trường Chinh",
  },
  {
    question:
      "Đại đoàn quân chủ lực đầu tiên của quân đội nhân dân Việt Nam (đại đoàn 308) được thành lập khi nào?  ",
    answer: "Năm 1949  ",
  },
  {
    question: "Đại đoàn quân tiên phong là đại đoàn nào?  ",
    answer: "Đại đoàn 308  ",
  },
  {
    question:
      "Trong Cương lĩnh thứ 3 được thông qua tại Đại Hội Đảng toàn quốc lần thứ hai (2-1951), Đảng ta đã phát triển và hoàn thiện nhận thức về lực lượng cách mạng không chỉ là công nhân và nông dân mà bao gồm nhiều lực lượng dân tộc khác. Các lực lượng đó được gọi chung là:  ",
    answer: "Nhân dân  ",
  },
  {
    question:
      "Trong cương lĩnh thứ ba (2-1951), Đảng ta đã khẳng định nhận thức của mình về con đường cách mạng Việt Nam. Đó là:  ",
    answer: "Con đường cách mạng dân tộc, dân chủ, nhân dân  ",
  },
  {
    question:
      "Đến năm 1951, Đảng ta đã tiến hành bao nhiêu kỳ Đại hội và trong khoảng thời gian nào?  ",
    answer: "2 kỳ Đại hội vào tháng 3-1935 và tháng 2-1951  ",
  },
  {
    question:
      "Nền tảng tư tưởng và kim chỉ nam được Đảng ta xác định tại Đại hội II là: ",
    answer: " Truyền thống dân tộc ",
  },
  {
    question:
      "Nền tảng của khối đại đoàn kết dân tộc được đảng Lao Động Việt Nam xác định tại Đại hội II  ",
    answer: " Công nhân, nông dân, lao động trí thức ",
  },
  {
    question:
      "Lực lượng tạo nên động lực cho cách mạng Việt Nam được nêu ra trong Chính cương Đảng Lao Động Việt Nam là: ",
    answer:
      " Công nhân, nông dân, tiểu tư sản, tư sản dân tộc, địa chủ yêu nước (nhân dân) ",
  },
  {
    question:
      "Thời gian và địa điểm diễn ra Đại hội Đảng toàn quốc lần thứ hai là: ",
    answer: "Tháng 2-1951, tại Vinh Quang, Chiêm Hoá, Tuyên Quang  ",
  },
  {
    question: "Tháng 3-1951, Đại Hội thống nhất Việt Minh và Liên Việt thành: ",
    answer: "Mặt trận Liên hiệp quốc dân Việt Nam (Liên Việt)  ",
  },
  {
    question:
      "“Hôm nay buổi sáng tháng ba Mừng ngày thắng lợi Đảng ta ra đời”Hai câu thơ trên nói đến sự kiện gì  ",
    answer: " Đại hội toàn quốc thống nhất Việt Minh và Liên Việt ",
  },
  {
    question:
      "Ban Thường vụ TƯ Đảng đã ra chỉ thị phát động phong trào thi đua ái quốc vào thời gian nào?  ",
    answer: "27/3/1948  ",
  },
  {
    question:
      "Chủ trương xây dựng và bảo vệ chính quyền cách mạng diễn ra từ? ",
    answer: "1945-1946  ",
  },
  {
    question:
      "Để thúc đẩy cuộc kháng chiến tiến lên, theo sáng kiến của Chủ tịch Hồ Chí Minh, ngày 27-3-1948, Ban Thường vụ TW Đảng ra chỉ thị:  ",
    answer: "Phát động phong trào thi đua ái quốc  ",
  },
  {
    question:
      "Một số thành quả tiêu biểu của chiến dịch Việt Bắc Thu  Đông 1947 là: ",
    answer: "Cả 3 phương án trên đều đúng ",
  },
  {
    question:
      "Quân đội của Tưởng Giới Thạch đã rút hết khỏi miền Bắc nước ta vào thời gian nào?  ",
    answer: "Cuối tháng 9/1946  ",
  },
  {
    question:
      "Cuối năm 1946, thực dân Pháp đã bội ước, liên tục tăng cường khiêu khích và lấn chiếm thêm một số địa điểm như:  ",
    answer: " Thành phố Hải phòng, thị xã Lạng Sơn, Đà Nẵng, Hà Nội ",
  },
  {
    question:
      "Sau khi ký bản Hiệp định Sơ bộ, ngày 9-3-1946, Ban thường vụ Trung ương Đảng đã ra: ",
    answer: "Chỉ thị Hoà để tiến  ",
  },
  {
    question:
      "Ý nghĩa của Chỉ thị “Nhật - Pháp bắn nhau và hành động của chúng ta” (12/3/1945) của Ban Thường vụ Trung ương Đảng? ",
    answer:
      "Thể hiện sự nhận định kiên quyết, sáng suốt và kịp thời của Đảng; Là kim chỉ nam cho mọi hành động của toàn Đảng, của Việt Minh trong cao trào kháng Nhật, cứu nước. ",
  },
  {
    question:
      "Cuộc chiến tranh thế giới thứ nhất có bao nhiêu người chết và bao nhiêu người bị tàn phế? ",
    answer: "10 triệu người chết và 20 triệu người tàn phế ",
  },
  {
    question: "Tuyên ngôn của Đảng Cộng sản viết năm nào? ",
    answer: "Năm 1848 ",
  },
  {
    question:
      "Từ khi chủ nghĩa Mác-Lênin được truyền bá vào Việt Nam phong trào yêu nước và phong trào công nhân phát triển theo khuynh hướng nào? ",
    answer: "Khuynh hướng cách mạng vô sản ",
  },
  {
    question: "Đảng cộng sản Đức ra đời vào thời gian nào? ",
    answer: "Năm 1918 ",
  },
  {
    question: "Sự ra đời của Quốc tế Cộng sản có ý nghĩa gì? ",
    answer:
      "Thúc đẩy sự phát triển của phong trào Cộng sản và công nhân quốc tế ",
  },
  {
    question: "Tân Việt cách mạng đảng (1928) ra đời từ tổ chức nào? ",
    answer: "Việt Nam nghĩa đoàn (1925) ",
  },
  {
    question: "Bản yêu sách 8 điểm mà Nguyễn Ái Quốc đã gửi đã ? ",
    answer: "Không được giải quyết ",
  },
  {
    question: "Đảng ta lấy tên Đảng Lao động Việt Nam từ đại hội nào?",
    answer: " Đại hội II",
  },
  {
    question:
      "Cuộc khởi nghĩa của Việt Nam quốc dân Đảng diễn ra trong bối cảnh như thế nào? ",
    answer: "Hoàn toàn bị động ",
  },

  //Chương 3
  {
    question:
      "Quyết định đưa nước ta vào thời kỳ đẩy mạnh công nghiệp hóa hiện đại hóa, phấn đấu đến năm 2020 cơ bản trở thành một nước công nghiệp được đưa ra tại Đại hội Đảng lần thứ mấy? ",
    answer: "Đại hội VII ",
  },
  {
    question:
      "Theo quan điểm của Đại hội Đảng toàn quốc lần thứ VIII (1996), nền tảng của công nghiệp hóa, hiện đại hóa đất nước là g ",
    answer: "Bản sắc dân tộc ",
  },
  {
    question: "Đại hội Đảng lần thứ IX (2001) là đại hội có chủ đề gì ",
    answer:
      "Phát huy sức mạnh toàn dân tộc, tiếp tục đổi mới, đẩy mạnh CNH-HĐH, xây dựng, bảo vệ Tổ quốc Việt Nam XHCN ",
  },
  {
    question:
      "Đại hội nào của Đảng đánh dấu bước ngoặt chuyển đất nước ta sang thời kỳ đẩy mạnh CNH, HĐH đất nước? ",
    answer: "Đại hội VIII (28/6-1/7/1996) ",
  },
  {
    question:
      "Đường lối công nghiệp hóa đất nước đã được hình thành từ Đại hội nào của Đảng ta? ",
    answer: "Đại hội II ",
  },
  {
    question:
      "Từ năm 1975 đến năm 1985 nước ta tiến hành công nghiệp hóa ở đâu ",
    answer: " Trên phạm vi cả nước",
  },
  {
    question:
      "Đại hội X của Đảng chỉ rõ mục tiêu đẩy mạnh công nghiệp hóa, hiện đại hóa cần phải? ",
    answer:
      "Gắn với phát triển kinh tế tri thức, coi kinh tế tri thức là yếu tố quan trọng của nền kinh tế và của công nghiệp hóa, hiện đại hóa ",
  },
  {
    question: "Công nghiệp hóa, hiện đại hóa phải bảo đảm?",
    answer: "Xây dựng nền kinh tế độc lập tự ch ",
  },
  {
    question:
      "Trước thời kỳ đổi mới, nước ta đã trải qua mấy năm tiến hành công nghiệp hóa?",
    answer: "25 năm ",
  },
  {
    question:
      "Đâu là mục tiêu cơ bản của công nghiệp hóa, hiện đại hóa đất nước",
    answer: "Đưa nước ta trở thành nước công nghiệp theo hướng hiện đại ",
  },
  {
    question:
      "Những sai lầm trong nhận thức và chủ trương công nghiệp hóa từ năm 1960 đến năm 1985 được đưa ra tại Đại hội lần thứ mấy của Đảng? ",
    answer: "VI ",
  },
  {
    question: "Quan điểm của Đảng ta về vấn đề CNH,HĐH trong thời kỳ đổi mới ",
    answer:
      "CNH,HĐH gắn với phát triển kinh tế thị trường định hướng xã hội chủ nghĩa và hội nhập kinh tế quốc t ",
  },
  {
    question:
      "Cách mạng xã hội chủ nghĩa được bắt đầu xây dựng trên phạm vi cả nước kể từ năm nào? ",
    answer: " Tháng 4/1975",
  },
  {
    question:
      "Mục tiêu cách mạng xã hội chủ nghĩa ở miền Bắc được xác định tại Đại hội đại biểu toàn quốc lần III của Đảng (9/1960)? ",
    answer:
      "Củng cố miền Bắc trở thành cơ sở vững mạnh cho cuộc đấu tranh thống nhất nước nhà. ",
  },
  {
    question:
      "Mục tiêu cơ bản của công nghiệp hóa xã hội chủ nghĩa được xác định tại Đại hội đại biểu toàn quốc lần thứ III của Đảng (9/1960)? ",
    answer:
      "Xây dựng một nền kinh tế xã hội chủ nghĩa cân đối và hiện đại; bước đầu xây dựng cơ sở vật chất và kỹ thuật của chủ nghĩa xã hội. ",
  },
  {
    question:
      "Cho biết những mốc chính trong tiến trình thực hiện công nghiệp hóa xã hội chủ nghĩa giai đoạn trước đổi mới? ",
    answer:
      "1960 - 1975: Công nghiệp hóa xã hội chủ nghĩa ở miền Bắc và 1975 - 1985: Công nghiệp hóa xã hội chủ nghĩa trên phạm vi cả nước ",
  },
  {
    question:
      "Đặc điểm lớn nhất chi phối sự hình thành đường lối công nghiệp hóa của Đảng từ năm 1960 đến năm 1975? ",
    answer:
      "Nền kinh tế nông nghiệp lạc hậu tiến thẳng lên chủ nghĩa xã hội không trải qua giai đoạn phát triển tư bản chủ nghĩa ",
  },
  {
    question:
      "Kỳ họp thứ nhất của Quốc hội nước Việt Nam thống nhất (Quốc hội khoá VI) được tổ chức trong thời gian nào? ",
    answer: "Từ 24/6 - 3/7/1976 ",
  },
  {
    question:
      "Đại hội V của Đảng (3/1982) coi nội dung chính của CNH trong chặng đường đầu tiên là ",
    answer:
      "Lấy nông nghiệp làm mặt trận hàng đầu, ra sức phát triển công nghiệp sản xuất hàng tiêu dùng ",
  },
  {
    question: "Một trong những đặc trưng của CNH thời kỳ trước đổi mới là ",
    answer:
      "CNH theo mô hình kinh tế khép kín, hướng nội và thiên về công nghiệp nặng ",
  },
  {
    question: "Đặc trưng của CNH thời kỳ trước đổi mới là ",
    answer: " Cả a, b, c đều đúng",
  },
  {
    question: "CNH thời kỳ trước đổi mới còn nhiều hạn chế là",
    answer: " Cả a, b, c đều đúng",
  },
  {
    question:
      "CNH thời kỳ trước đổi mới còn nhiều hạn chế xuất phát từ nguyên nhân khách quan là ? ",
    answer:
      "CNH từ một nền kinh tế lạc hậu, nghèo nàn, chiến tranh kéo dài vừa bị tàn phá nặng nề, vừa không thể tập trung sức người sức của cho CNH ",
  },
  { question: "CNH HĐH là ? ", answer: "Cả a, b, c đều đúng " },
  {
    question:
      "Nhìn lại đất nước ta sau 10 năm đổi mới, Đại hội VIII của Đảng (6/1996) nhận định ? ",
    answer: "Nước ta đã ra khỏi khủng hoảng kinh tế xã hội ",
  },
  {
    question:
      "Đại hội IX, X của Đảng bổ sung và nhấn mạnh một trong những điểm mới của tư duy về CNH là",
    answer:
      "Hướng CNH HĐH ở nước ta là phát triển nhanh, hiệu quả các sản phẩm, các ngành, các lĩnh vực có lợi thế, đáp ứng nhu cầu trong nước và xuất khẩ ",
  },
  {
    question:
      "Đại hội X (4/2006) của Đảng đã nhận định về CNH, HĐH trong thế kỷ XXI là ",
    answer: " Cả a, b đều đúng",
  },
  {
    question:
      "Sau 20 năm đổi m ới, bên cạnh những thành tựu to lớn đã đạt được, CNH HĐH ở nước ta vẫn còn nhiều hạn chế ",
    answer: "Cả a, b, c đều đúng ",
  },
  {
    question:
      "Sau 20 năm đổi mới, CNH HĐH ở nước ta vẫn còn nhiều hạn chế do nhiều nguyên nhân, các nguyên nhân cụ thể, trực tiếp là ? ",
    answer: "Cả a, b, c đều đúng ",
  },
  {
    question:
      "Một trong những nội dung cơ bản của quá trình CNH HĐH gắn với phát triển kinh tế tri thức mà Đại hội X chỉ rõ là ?",
    answer:
      "Phát triển mạnh các ngành và sản phẩm kinh tế có giá trị tăng cao dựa vào tri thức ",
  },
  {
    question:
      "Đại hội III của Đảng khẳng định: Muốn cải biến tình trạng kinh tế lạc hậu của nước ta, không có con đường nào khác, ngoài con đường công nghiệp hóa xã hội chủ nghĩa. Điều đó có nghĩa là gì ",
    answer:
      " Khẳng định tính tất yếu của công nghiệp hóa đối với công cuộc xây dựng chủ nghĩa xã hội ở nước ta",
  },
  {
    question:
      "Hội nghị trung ương lần thứ bảy khóa III đã nêu ra những phương hướng chỉ đạo nào để xây dựng và phát triển công nghiệp? ",
    answer:
      " Ưu tiên phát triển công nghiệp nặng một cách hợp lý; kết hợp chặt chẽ phát triển công nghiệp với phát triển nông nghiệp; ra sức phát triển công nghiệp nhẹ song song với việc ưu tiên phát triển công nghiệp nặng; ra sức phát triển công nghiệp trung ương, đồng thời đẩy mạnh phát triển công nghiệp địa phương",
  },
  {
    question: "Đại hội lần thứ V của Đảng diễn ra vào thời gian nào? ",
    answer: " 3/1982",
  },
  {
    question:
      "Đại hội IX của Đảng ta xác định nền kinh tế nước ta có mấy thành phần kinh tế?",
    answer: " 6",
  },
  {
    question:
      "Đại hội Đảng Cộng sản Việt Nam lần thứ IX xác định mô hình kinh tế khái quát trong thời kỳ quá độ ở nước ta là",
    answer:
      "Kinh tế nhiều thành phần có sự quản lý của nhà nước theo định hướng XH ",
  },
  {
    question:
      "Cương lĩnh xây dựng đất nước trong thời kỳ quá độ lên chủ nghĩa xã hội được thông qua trong Đại hội nào của Đảng? ",
    answer: " Đại hội VII",
  },
  {
    question:
      "Chủ trương xây dựng và tổ chức thực hiện ba chương trình kinh tế lớn về lương thực, thực phẩm; hàng tiêu dùng; hàng xuất khẩu được Đảng đề ra tại Đại hội nào?",
    answer: "Đại hội lần thứ VI ",
  },
  {
    question: "Yếu tố quyết định tăng trưởng kinh tế là ",
    answer: "Con người ",
  },
  {
    question:
      "Chủ trương thực hiện 3 chương trình kinh tế lớn về lương thực, thực phẩm; hàng tiêu dùng; hàng xuất khẩu được Đảng ta đề ra tại Đại hội nào ",
    answer: "Đại hội lần thứ VI ",
  },
  {
    question:
      "“Kinh tế thị trường là một nền kinh tế mà khi các …..được phân bổ bằng nguyên tắc thị trường”? ",
    answer: "Nguồn lực kinh tế ",
  },
  {
    question: "Đại hội toàn quốc lần thứ V của Đảng coi mặt trận hàng đầu là? ",
    answer: " Nông nghiệp",
  },
  {
    question: "Đại hội lần thứ VIII đã chủ trương ",
    answer:
      "Xây dựng nền kinh tế mở; đẩy nhanh quá trình hội nhập kinh tế khu vực và thế giới ",
  },
  {
    question:
      "Tư duy của Đảng về kinh tế thị trường từ Đại hội đại biểu toàn quốc lần thứ VI đến Đại hội đại biểu toàn quốc lần thứ VIII? ",
    answer:
      " Kinh tế thị trường không phải là cái riêng của chủ nghĩa tư bản mà là thành tựu phát triển chung của nhân loại; Kinh tế thị trường còn tồn tại khách quan trong thời kì quá độ lên chủ nghĩa xã hội; Có thể và cần thiết sử dụng kinh tế thị trường để xây dựng chủ nghĩa xã hội ở nước ta",
  },
  {
    question:
      "Đại hội VI xác định yếu tố có vị trí then chốt trong sự nghiệp xây dựng CNXH? ",
    answer: "Khoa học-Kỹ thuậ ",
  },
  {
    question:
      "Đại hội nào đề cập đến sự cần thiết đổi mới cơ chế quản lý kinh tế?",
    answer: " Đại hội VI",
  },
  {
    question:
      "Đại hội nào của Đảng chủ trương phải kết hợp các mục tiêu kinh tế với các mục tiêu xã hội trong phạm vi cả nước, ở từng lĩnh vực, địa phương ? ",
    answer: "Đại hội XI ",
  },
  {
    question:
      "Đại hội đại biểu toàn quốc lần thứ VII (1991) của Đảng họp ở đâu",
    answer: "Hà Nội ",
  },
  {
    question:
      "Dựa trên học thuyết chủ nghĩa Mác-Lênin về thời kỳ quá độ, đường lối và chính sách của Việt Nam trong thời kỳ 1955-1975 được xác định tại đại hội Đảng lần thứ III là: ",
    answer: "Tiến nhanh, tiến mạnh, tiến vững chắc lên chủ nghĩa xã hội ",
  },
  {
    question:
      "Việt Nam gia nhập tổ chức ASEAN trong khu vực vào ngày tháng năm nào? ",
    answer: "28/07/1995 ",
  },
  {
    question:
      "Về phương châm đối ngoại của Việt Nam, từ năm 1945 khi nhà nước dân chủ nhân dân ra đời. Trong điều kiện trực tiếp lãnh đạo chính quyền, Đảng đã hoạch định đường lối đối ngoại với nội dung nào ",
    answer: "Độc lập, tự chủ, tự lực, tự cườn ",
  },
  {
    question:
      "Mục tiêu đối ngoại của nước ta là gì? Có thêm câu tất đều đúng là chọ ",
    answer: "Nâng cao vị thế trong quan hệ ngoại giao khu vực và quốc tế. ",
  },
  {
    question:
      "Sự kiện nào đánh dấu sự hội nhập của nước ta với các nước trong khu vực Đông Nam Á?",
    answer: "Tháng 7/1995 Việt Nam gia nhập ASEAN ",
  },
  {
    question:
      "Phương châm của Đại hội Đảng lần thứ IX: “Việt Nam ….là bạn, là ……của các nước trong cộng đồng quốc tế, phấn đấu vì hòa bình, độc lập và phát triển”. ",
    answer: "Sẵn sàng - đối tác tin cậy",
  },
  {
    question:
      "Chủ trương đối ngoại của Đại hội VIII có những đặc điểm mới hơn so với đại hội lần thứ VII là gì",
    answer:
      "Mở rộng quan hệ với Đảng cầm quyền và các Đảng khác; quán triệt yêu cầu mở rộng quan hệ đối ngoại nhân dân, quan hệ với các tổ chức phi chính phủ; thử nghiệm tiến tới đầu tư ra nước ngoài. ",
  },
  {
    question:
      "Hơn 20 năm thực hiện đường lối mở rộng quan hệ đối ngoại, hội nhập quốc tế nước ta đạt được kết quả ",
    answer: "Mở rộng quan hệ đối ngoại theo hướng đa phương hóa, đa dạng hóa ",
  },
  {
    question:
      "Đại hội lần thứ III của Đảng họp tại thủ đô Hà Nội diễn ra vào thời gian nào?",
    answer: "Từ ngày 05 đến ngày 10/09/1960 ",
  },
  {
    question:
      "Cao trào kháng Nhật cứu nước đã diễn ra ở vùng rừng núi và trung du Bắc kỳ với hình thức nào là chủ yếu?",
    answer: " Khởi nghĩa từng phần",
  },
  {
    question:
      "Chiều ngày 16/8/1945, một đội quân do Võ Nguyên Giáp chỉ huy đã tiến về giải phóng ? ",
    answer: "Thái Nguyên ",
  },
  {
    question:
      "Ngày 04/6/1945, khu giải phóng Việt Bắc được thành lập và được xem là hình ảnh thu nhỏ của nước Việt Nam mới. Khu giải phóng Việt Bắc gồm một phần những tỉnh nào?",
    answer: " Cao Bằng, Bắc Cạn, Lạng Sơn, Hà Giang, Tuyên Quang, Thái Nguyên",
  },
  {
    question:
      "Lá cờ Quyết chiến, quyết thắng trong chiến dịch Điện Biên Phủ được trao cho đơn vị nào? ",
    answer: " Đại đoàn 312",
  },
  {
    question:
      "Tại Hội nghị hợp nhất các tổ chức cộng sản thành lập Đảng Cộng sản Việt Nam (3/2/1930), chỉ có đại diện của An Nam Cộng sản đảng và Đông Dương Cộng sản đảng tham dự. Đông Dương Cộng sản liên đoàn chính thức gia nhập Đảng Cộng sản Việt Nam vào ngày tháng năm nào? ",
    answer: "24/2/1930 ",
  },
  { question: "Quốc hội khóa đầu tiên có bao nhiêu đại biểu", answer: "403 " },
  {
    question:
      "Quốc tế Cộng sản gửi những người Cộng sản Đông Dương tài liệu Về việc thành lập một Đảng Cộng sản Đông Dương vào thời gian nào? ",
    answer: "Ngày 27-10-1929 ",
  },
  {
    question:
      "Tại Đại hội đại biểu của Hội VNCMTN họp tại Hương Cảng (5/1929) đã ",
    answer:
      "Xảy ra sự bất đồng quan điểm giữa các đoàn đại biểu xung quanh việc xúc tiến thành lập ĐCS ",
  },
  {
    question:
      "Quân đội của Tưởng Giới Thạch đã rút hết khỏi miền Bắc nước ta vào thời gian nào ",
    answer: " Cuối tháng 9/1946",
  },
  {
    question:
      "Để thúc đẩy cuộc kháng chiến tiến lên, theo sáng kiến của Chủ tịch Hồ Chí Minh, ngày 27-3-1948, Ban Thường vụ TW Đảng ra chỉ thị: ",
    answer: " Phát động phong trào thi đua ái quốc",
  },
  {
    question:
      "Khi nào phong trào công nhân Việt Nam hoàn toàn trở thành một phong trào tự giác? ",
    answer: "Năm 1930 (Đảng Cộng sản Việt Nam ra đời ",
  },
  {
    question:
      "Để quân Tưởng và tay sai khỏi kiếm cớ sách nhiễu, Đảng ta chủ trương ",
    answer:
      "Hoa Việt thân thiện, biến xung đột lớn thành xung đột nhỏ, biến xung đột nhỏ thành không có xung đột ",
  },
  {
    question:
      "Đại hội đại biểu toàn quốc lần thứ X của Đảng (4/2006) đã xác định vai trò của kinh tế tri thức như thế nào?",
    answer:
      "Kinh tế tri thức là yếu tố quan trọng của nền kinh tế và công nghiệp hóa, hiện đại hoá. ",
  },
  {
    question:
      "Hội nghị Ban Chấp hành Trung ương Đảng họp tháng 7-1936 chủ trương thành lập mặt trận nào? ",
    answer: " Mặt trận nhân dân phản đế Đông Dương.",
  },
  {
    question:
      "Khẩu hiệu nào sau được nêu ra trong Cao trào kháng Nhật cứu nước ",
    answer: "Đánh đuổi phát xít Nhật ",
  },
  { question: " ", answer: " " },

  // Add more question-answer pairs
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
