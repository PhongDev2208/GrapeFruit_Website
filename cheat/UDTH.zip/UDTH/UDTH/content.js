// Giả sử đây là dữ liệu chứa các câu hỏi và câu trả lời
const data = [
  // Module 1
  {
    question: "Lựa chọn nào dưới đây không phải là chức năng của hệ điều hành?",
    answer: "Quá trình kết nối hệ thống mạng LAN (LAN connection)",
  },
  {
    question: "Hãy chọn các quy đổi đơn vị đo dung lượng bộ nhớ trong đúng?",
    answer: "1 Byte=8 Bits, 1 Kilobyte = 1024 Bytes, 1Terabyte=1024 Gigabyte",
  },
  {
    question: "Khi nào cần khởi động Windows ở chế độ Safe Mode?",
    answer:
      "Phát sinh lỗi hệ thống, Windows khởi động không bình thường, Cần hiệu chỉnh lại hệ điều hành, Cần loại bỏ một số virus hoặc một số malware bằng cách quét virus hoặc malware ở chế độ Safe Mode",
  },
  {
    question:
      "Các đường mạch điện tử liên kết các thiết bị khác nhau trong máy tính với nhau được gọi là gì?",
    answer: "Bus",
  },
  {
    question:
      "Một tập hợp các chỉ thị (Lệnh) nhằm hướng dẫn cho máy tính thực hiện một (nhiều) tác vụ nào đó được gọi là ?",
    answer: "Chương trình",
  },
  {
    question:
      "Để đảm bảo tính an toàn khi tạm thời rời khỏi máy tính mà không đóng bất kỳ chương trình nào đang chạy, tùy chọn nào sau đây là đúng nhất?",
    answer: "Lock",
  },
  {
    question:
      "Đâu là thiết lập để quản lý về việc sử dụng nguồn năng lượng cho máy tính?",
    answer: "Power plan",
  },
  {
    question: "Tính năng nào dưới đây tạo ra các điểm khôi phục của hệ thống?",
    answer: "System Restore",
  },
  { question: "Đâu là thiết bị phần cứng?", answer: "Chuột, Bàn phím" },
  { question: "Đâu là phần mềm?", answer: "Google Chrome" },
  { question: "CPU là từ viết tắt của?", answer: "Central Processing Unit" },
  { question: "CPU nằm ở phần nào của máy tính?", answer: "Case máy tính" },
  { question: "RAM là từ viết tắt của?", answer: "Random Access Memory" },
  {
    question: "Các thiết lập về cấu hình phần cứng máy tính được lưu trữ tại?",
    answer: "CMOS RAM",
  },
  {
    question: "Cổng PS/2 có màu xanh lá được kết nối với thiết bị nào sau đây?",
    answer: "Chuột",
  },
  {
    question: "Cổng PS/2 có màu tím được kết nối với thiết bị nào sau đây?",
    answer: "Bàn phím",
  },
  {
    question:
      "Khi khởi động máy tính, loa tín hiệu phát ra tiếng beep dài liên tục, lỗi do thiết bị nào sau đây?",
    answer: "RAM",
  },
  {
    question: "Công nghệ Dual Channel được ứng dụng cho thiết bị nào sau đây?",
    answer: "RAM",
  },
  {
    question:
      "Vi xử lý thế hệ Core 2 Duo của Intel được tích hợp bao nhiêu nhân xử lí?",
    answer: "2",
  },
  {
    question: "Màn hình được kết nối với máy tính thông qua cổng nào sau đây?",
    answer: "VGA",
  },
  {
    question: "Tốc độ 1x chuẩn của ổ đĩa CD-ROM thường có giá trị là ?",
    answer: "150 KBps",
  },
  {
    question: "Máy in được kết nối với máy tính thông qua cổng nào sau đây ?",
    answer: "USB",
  },
  {
    question: "Máy tính nào nhỏ gọn, dễ dàng mang đi nhất?",
    answer: "Máy tính bảng",
  },
  { question: "Đâu là thiết bị ngoại vi?", answer: "Máy in" },
  { question: "Đâu là thiết bị nội vi?", answer: "RAM" },
  { question: "Đâu là thiết bị nhập của máy tính?", answer: "Máy scan" },
  { question: "Đâu là thiết bị xuất của máy tính?", answer: "Máy in" },
  {
    question: "Cổng nào có khả năng kết nối với 127 loại thiết bị khác nhau?",
    answer: "USB",
  },
  { question: "Máy in laze sử dụng loại mực nào?", answer: "Mực bột" },
  { question: "Máy in phun sử dụng loại mực nào?", answer: "Mực nước" },
  { question: "Máy in kim sử dụng loại mực nào?", answer: "Băng mực" },
  {
    question: "Các loại định dạng đĩa cứng trên Hệ điều hành Windows là?",
    answer: "NTFS, FAT",
  },
  {
    question:
      "Máy Scanner được kết nối với máy tính thông qua cổng nào sau đây?",
    answer: "USB",
  },
  { question: "Bộ nhớ đệm bên trong CPU được gọi là?", answer: "Cache" },
  {
    question: "Tốc độ truyền dữ liệu tối đa của chuẩn USB 2.0 là?",
    answer: "480 Mbps",
  },
  {
    question:
      "Khi lựa chọn cấu hình cho máy tính, thiết bị cần quan tâm đầu tiên là?",
    answer: "Mainboard",
  },
  {
    question: "DVD Combo có các chức năng nào sau đây?",
    answer: "Đọc đĩa CD, DVD và ghi đĩa CD",
  },
  {
    question: "Loại socket dùng cho vi xử lý thế hệ Core Duo của Intel là?",
    answer: "775",
  },
  {
    question: "Cổng DVI dùng để kết nối với thiết bị nào sau đây?",
    answer: "Màn hình",
  },
  { question: "Tốc độ bus của RAM PC2-5300 là bao nhiêu MHz?", answer: "667" },
  { question: "Chọn các đáp án đúng?", answer: "1 Byte = 8 bits, 1 MB=1024KB" },
  {
    question: "Ổ cứng chuẩn SATA II có tốc độ truy xuất là?",
    answer: "300 MBps",
  },
  {
    question:
      "Modem gắn ngoài được kết nối với máy tính thông qua cổng nào sau đây?",
    answer: "COM",
  },
  {
    question: "Thiết bị nào sau đây có tốc độ truy xuất dữ liệu nhanh nhất?",
    answer: "RAM",
  },
  {
    question:
      "Nguồn điện trong văn phòng không ổn định và thường xuyên xảy ra sự cố. Người kỹ thuật nên làm gì để bảo vệ máy tính?",
    answer: "Dùng bộ lưu điện (UPS)",
  },
  {
    question: "Trên thanh RAM có ghi thông số PC3200, vậy số 3200 có nghĩa là?",
    answer: "Băng thông của RAM là 3200MB/s",
  },
  {
    question:
      "Trên 1 ổ đĩa cứng có thể phân chia tối đa thành mấy primary partition?",
    answer: "4 primary hoặc 3 primary và 1 extended",
  },
  {
    question: "Nguyên nhân nào dưới đây có thể gây ra cháy RAM?",
    answer: "Tháo lắp RAM khi nguồn đang hoạt động",
  },
  { question: "Cổng dùng kết nối mạng trên máy tính là?", answer: "RJ 45" },
  {
    question: "Hệ điều hành mã nguồn mở thông dụng nhất hiện nay là?",
    answer: "Linux",
  },
  {
    question: "Lụa chọn các loại tốc độ vòng quay của ổ cứng?",
    answer: "5400 rpm, 7200 rpm, 10.000 rpm",
  },
  { question: "Ổ cứng SSD là từ viết tắt của?", answer: "Solid State Drives" },
  {
    question: "Nhóm nào dưới đây bao gồm các thiết bị được xếp vào cùng loại?",
    answer: "Máy in, Màn hình, Loa",
  },
  {
    question: "Ổ cứng là gì?",
    answer: "Thiết bị lưu trữ trong vì nó ở trong máy tính",
  },
  {
    question: "Khi khởi động máy tính, phần mềm nào sẽ được thực hiện trước?",
    answer: "Hệ điều hành",
  },
  {
    question: "Phần mềm Windows, Linux có đặc điểm gì chung?",
    answer: "Tất cả đều là hệ điều hành",
  },
  {
    question: "Loại máy tính nào thường có giá thành cao nhất?",
    answer: "Máy chủ",
  },
  { question: "Đĩa cứng là thiết bị thuộc loại?", answer: "Bộ nhớ ngoài" },
  { question: "Đâu là phần mềm xử lý văn bản?", answer: "MS Word" },
  {
    question: "Thiết bị nào ảnh hưởng lớn nhất đến tốc độ xử lý của máy tính?",
    answer: "CPU",
  },
  {
    question: "Thiết bị nào vừa là thiết bị xuất vừa là thiết bị nhập?",
    answer: "Micro HeadPhone, Màn hình cảm ứng",
  },
  { question: "Đâu là hệ điều hành đơn nhiệm?", answer: "MS-DOS" },
  {
    question:
      "Khái niệm nào cho biết hệ điều hành thực thi nhiều tiến trình khác nhau cùng lúc?",
    answer: "Đa nhiệm",
  },
  {
    question:
      "Thành phần nào được chạy trước tiến trình khởi động của một máy tính?",
    answer: "Hệ điều hành",
  },
  {
    question: "BIOS của máy tính là một …. Chứa các thủ tục ở mức thấp nhất.",
    answer: "Firmwares",
  },
  {
    question: "Thiết bị ngoại vi của máy tính để bàn là thiết bị nào?",
    answer: "Máy in, Loa",
  },
  {
    question: "Phát biểu nào sau đây là đúng?",
    answer: "Tốc độ của một bộ vi xử lý được đo bằng Hertz (Hz).",
  },
  {
    question:
      "Lựa chọn nào cho thấy máy tính xách tay có lợi thế hơn so với máy tính để bàn?",
    answer:
      "Máy tính xách tay không cần nhiều cáp bên ngoài như máy tính để bàn. Máy tính xách tay có nhiều thiết bị tích hợp, Máy tính xách tay có thể mang đi bất kỳ đâu",
  },
  {
    question:
      "Thiết bị nào cung cấp các dịch vụ mạng cho các máy trạm hoạt động trong mạng LAN?",
    answer: "Máy chủ",
  },
  {
    question: "Đâu là thiết bị lưu trữ dữ liệu?",
    answer: "Bộ nhớ USB, Ổ cứng di động",
  },
  {
    question:
      "Loại phần mềm nào cho phép người dùng tự sao chép, phân phối, nghiên cứu, sửa đổi và cải thiện sản phẩm?",
    answer: "Free Software",
  },
  {
    question:
      "Chương trình nào được thiết kế để phát hiện, ngăn chặn, loại bỏ và phòng chống virus máy tính?",
    answer: "Antivirus",
  },
  {
    question:
      "Phần mềm nào là nguyên nhân gây ra hiệu suất máy tính không mong muốn?",
    answer: "Malware",
  },
  {
    question:
      "Máy tính tắt ngay sau khi nó được bật và trở nên quá nóng. Điều gì đang diễn ra?",
    answer:
      "Chip vi xử lý quá nóng. Kiểm tra lại hệ thống thông gió và làm mát.",
  },
  {
    question:
      "Máy tính của bạn được kết nối nguồn đúng. Bạn nhấn nút nguồn, nhưng máy tính không hoạt động, các đèn tín hiệu không sáng, quạt nguồn không chạy. Có một vấn đề xảy ra với?",
    answer: "Kết nối điện của các thành phần bên trong máy tính",
  },
  {
    question:
      "Bạn đưa một đĩa CD Dữ liệu vào trong ổ đĩa CD. Bạn cố gắng truy cập đĩa, một thông báo lỗi xuất hiện. Hai nguyên nhân có thể gây ra lỗi là?",
    answer:
      "Đĩa bẩn, bị hư hỏng hoặc bị lỗi, Bạn đặt đĩa vào khay đĩa không đúng chiều",
  },
  {
    question: "Thiết bị nào được thay thế khi dùng màn hình cảm ứng?",
    answer: "Chuột",
  },
  {
    question:
      "Nguyên nhân con trỏ chuột tự nhấn khi di chuyển trên màn hình là?",
    answer: "Các phím của chuột hoạt động không chính xác",
  },
  {
    question:
      "Giấy phép phân phối phần mềm cho người sử dụng dùng thử, đánh giá sản phẩm miễn phí trong một khoảng thời gian xác định, và có những giới hạn về chức năng của sản phẩm là gì?",
    answer: "Shareware",
  },
  {
    question:
      "Hai thiết bị nào của máy tính xách tay phải có để máy tính hoạt động một cách chính xác?",
    answer: "Màn hình, Chuột",
  },
  {
    question: "Mục tiêu chính của một hệ điều hành là gì?",
    answer: "Tách người dùng khỏi sự phức tạp của phần cứng",
  },
  {
    question: "Hai nhiệm vụ của hệ điều hành là gì?",
    answer: "Quản lý tiến trình",
  },
  {
    question: "Những phát biểu nào là đúng khi nói về giấy phép phần mềm?",
    answer: "Là hợp đồng giữa các tác giả và người sử dụng",
  },
  {
    question: "Ba đặc trưng của điện thoại thông minh (SmartPhone)?",
    answer:
      "Cho phép cài đặt các chương trình của bên thứ 3, Có GPS, Hỗ trợ thư điện tử",
  },
  {
    question: "Các biểu hiện lỗi của bộ nhớ RAM?",
    answer:
      "Hệ thống không khởi động và bạn nghe thấy các tiếng bip lặp đi lặp lại, Hệ thống khởi động, nhưng thông báo cho bạn các lỗi trong địa chỉ bộ nhớ",
  },
  {
    question:
      "Đâu là chương trình được sử dụng để đo toàn bộ hiệu năng của hệ thống hoặc tiến trình, thiết bị bằng cách so sánh nó với các hệ thống khác, tiến trình hoặc thiết bị khác?",
    answer: "Benchmark",
  },
  {
    question: "Lợi ích khi khởi động máy tính ở chế độ Safe mode?",
    answer:
      "Cho phép giải quyết các vấn đề gây ra bởi các chương trình và trình điều khiển khởi động không chính xác hoặc ngăn hệ điều hành khởi động một cách chính xác",
  },
  {
    question: "Phát biểu nào là đúng khi nói đến CPU?",
    answer: "CPU là bộ vi xử lý trung tâm của máy tính",
  },
  {
    question:
      "Bạn đang xem một video hình ảnh trên máy tính của bạn. Các hình ảnh không được hiển thị một cách chính xác và màn hình bị đóng băng. Thiết bị nào bị lỗi?",
    answer: "Card đồ họa",
  },
  {
    question:
      "Bạn cần gửi 24 tệp tin có kích thước lớn bằng Email. Làm thế nào để bạn có thể gửi chúng nhanh và hiệu quả hơn?",
    answer:
      "Sử dụng chương trình nén để nén và gửi tệp tin này với dung lượng nhỏ hơn",
  },
  { question: "Đâu là hệ điều hành cho PC?", answer: "GNU/Linux, Mac OS" },
  {
    question: "Đâu là hệ điều hành cho các thiết bị di động?",
    answer: "Android, IOS",
  },
  {
    question: "Phát biểu nào là đúng khi nói về bộ nhớ RAM và ROM?",
    answer: "Bộ nhớ RAM là bộ nhớ đọc và ghi, trong khi ROM là bộ nhớ chỉ đọc",
  },
  {
    question:
      "Kiểu bộ nhớ nào nhỏ hơn, nhanh hơn, giảm thời gian chờ và lưu dữ liệu của vi xử lý cho các hoạt động tiếp theo mà không cần truy cập vào bộ nhớ RAM?",
    answer: "Bộ nhớ Cache",
  },
  {
    question: "Các loại cáp kết nối Internet là?",
    answer: "Cáp quang, Cáp thường (ISDN)",
  },
  {
    question: "Ba thiết bị nào cần thiết để máy tính có thể sử dụng được?",
    answer: "Chuột, Bàn phím, Màn hình",
  },
  {
    question:
      "Đâu là thiết bị dễ dàng sử dụng có màn hình cảm ứng thay vì sử dụng một bàn phím riêng biệt?",
    answer: "Máy tính bảng",
  },
  {
    question: "Giải pháp nào cho phép cải thiện hiệu năng của máy tính?",
    answer:
      "Thay thế card đồ họa tích hợp trên bo mạch chủ bằng card đồ họa chuyên dụng",
  },
  {
    question: "Những phát biểu nào là đúng với giấy phép sử dụng Freeware?",
    answer:
      "Giấy phép Freeware thường bao gồm một giấy phép người sử dụng, cho phép phân phối lại nhưng bị hạn chế về chức năng",
  },
  {
    question: "Các thông số kỹ thuật nào cần quan tâm khi nâng cấp RAM?",
    answer: "Dung lượng, Tốc độ",
  },
  {
    question:
      "Thành phần bên trong CPU nào thực hiện các tính toán và các phép toán logic?",
    answer: "Bộ vi xử lý",
  },
  {
    question: "Phát biểu nào về ổ đĩa thể rắn là chính xác?",
    answer: "Ổ đĩa thể rắn không có bộ phận chuyển động.",
  },
  {
    question:
      "Trước khi mã nguồn chương trình có thể chạy được trên máy tính thì nó cần được?",
    answer: "Biên dịch",
  },
  {
    question: "Trong mạng điện thoại PSTN là viết tắt của từ nào?",
    answer: "Public Switched Telephone Network",
  },
  {
    question: "ADSL là viết tắt của từ nào?",
    answer: "Asymmetric Digital Subscriber Line",
  },
  {
    question:
      "Nguồn điện trong văn phòng không ổn định và thường xuyên xảy ra sự cố. Người kỹ thuật nên làm gì để bảo vệ máy tính?",
    answer: "Dùng bộ lưu điện (UPS)",
  },
  {
    question: "Đâu không phải là các dịch vụ kết nối Internet?",
    answer: "DHCP",
  },
  {
    question:
      "Dịch vụ kết nối internet nào cho phép kết nối internet tốc độ cao?",
    answer: "FTTH",
  },
  {
    question: "Đâu là các phương thức kết nối mạng?",
    answer: "Không dây, Cáp quang",
  },
  {
    question: "Ứng dụng nào cung cấp các dịch vụ gửi thư điện tử?",
    answer: "Gmail",
  },
  { question: "Hệ điều hành là gì?", answer: "Phần mềm hệ thống" },
  {
    question:
      "Dịch vụ Internet được chính thức cung cấp tại Việt Nam vào năm nào?",
    answer: "1997",
  },
  { question: "WWW là viết tắt của?", answer: "World Wide Web" },
  {
    question: "Chương trình dùng để xem các trang Web được gọi là gì?",
    answer: "Trình duyệt web",
  },
  {
    question: "Thiết bị nào cần thiết để kết nối mạng Internet?",
    answer: "Modem",
  },
  { question: "Đâu không phải là trình duyệt Web?", answer: "Adobe Flash" },
  {
    question:
      "Tiêu đề của một thư điện tử được bắt đầu bằng 'RE:' có nghĩa là gì?",
    answer: "Thư hồi đáp",
  },
  {
    question:
      "Tiêu đề của một thư điện tử được bắt đầu bằng 'FW:' có nghĩa là gì?",
    answer: "Thư chuyển tiếp",
  },
  {
    question: "Lợi thế của việc sử dụng thư điện tử là gì?",
    answer: "Tốc độ chuyển thư nhanh",
  },
  {
    question: "Chương trình Microsoft Outlook dùng để làm gì?",
    answer: "Gửi, nhận Email",
  },
  {
    question:
      "Hệ thống thư điện tử Gmail của Google cho phép đính kèm tệp tin có dung lượng tối đa là bao nhiêu?",
    answer: "25 MB",
  },
  {
    question:
      "Trong khi soạn thảo email nếu muốn gửi kèm file chúng ta nhấn vào nút?",
    answer: "Attachment",
  },
  {
    question: "Để truy cập vào một trang Web chúng ta cần phải biết?",
    answer: "Tên miền của trang Web",
  },
  {
    question: "Đâu là phát biểu đúng về Email?",
    answer: "Là dịch vụ cho phép ta gửi và nhận thư điện tử",
  },
  {
    question: "Những chương trình nào dùng để duyệt Web?",
    answer: "Internet Explorer, Mozilla Firefox, Google Chrome",
  },
  {
    question:
      "Để bảo vệ dữ liệu quan trong trên một máy tính thì dữ liệu cần được?",
    answer: "Mã hóa dữ liệu",
  },
  {
    question: "Với thư điện tử, phát biểu nào sau đây là sai?",
    answer: "Hai người có thể có địa chỉ thư giống nhau",
  },
  {
    question:
      "Khi tìm kiếm trên Google để tìm kiếm các trang Web nói về hoa Phong Lan, người dùng nên gõ cụm từ nào?",
    answer: "“hoa phong lan”",
  },
  {
    question: "Tường lửa là gì?",
    answer:
      "Một hệ thống là phần cứng hoặc phần mềm có mục đích chống lại sự xâm nhập từ Internet",
  },
  {
    question:
      "Khi gửi một email cho một địa chỉ A và muốn bí mật gửi cho một địa chỉ B thì người dùng lựa chọn cách nào sau đây?",
    answer: "To A, Bcc B",
  },
  {
    question: "Địa chỉ nào không phải là địa chỉ trang Web?",
    answer: "phonglan@dntu.edu.vn",
  },
  { question: "Địa chỉ nào là địa chỉ Email?", answer: "phonglan@dntu.edu.vn" },
  {
    question: "Để xem được trang Web, máy tính cần phải cài đặt gì?",
    answer: "Trình duyệt Web",
  },
  { question: "URL là từ viết tắt của?", answer: "Uniform Resource Locator" },
  { question: '"Online" có nghĩa là?', answer: "Trực tuyến" },
  { question: '"Ofline" có nghĩa là?', answer: "Không trực tuyến" },
  {
    question: "Virus máy tính không thể lây qua việc?",
    answer: "Quét từ máy quét (Scaner) vào máy tính",
  },
  { question: "Trình duyệt nào được xuất bản bởi Google?", answer: "Chrome" },
  { question: "SMS là viết tắt của từ nào?", answer: "Short Message Service" },
  {
    question: "Mật khẩu nào sau đây mà Hacker khó tấn công nhất?",
    answer: "Abcd12@!.",
  },
  {
    question: "Virus có thể lây lan qua?",
    answer: "Mạng máy tính, USB, Thẻ nhớ Flash",
  },
  {
    question: "Loại file nào có thể phát tán được Virus?",
    answer: "EXE, COM, BAT",
  },
  {
    question: "Chương trình nào là chương trình diệt Virus?",
    answer: "Kaspersky",
  },
  {
    question: "Các cách nào có thể phát tán Virus máy tính?",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Chương trình nào sau đây không phải là chương trình diệt Virus?",
    answer: "Winrar",
  },
  {
    question: "Phương pháp nào có thể phòng tránh được Virus?",
    answer:
      "Update các bản vá lỗ hổng hệ thống, Cài đặt phần mềm Antivirus, Cảnh giác với những đường link hay thư điện tử lạ",
  },
  {
    question: "Trojan là một phương thức tấn công kiểu gì?",
    answer:
      "Điều khiển máy tính nạn nhân từ xa thông qua phần mềm cài sẵn trong máy nạn nhân",
  },
  {
    question: "Tên miền dntu.edu.vn là tên miền của quốc gia nào?",
    answer: "Việt Nam",
  },
  {
    question:
      "Trong các thuật ngữ về Công nghệ thông tin, ISP là viết tắt của:",
    answer: "Internet Service Provider",
  },
  {
    question:
      "Việc chứng thực một thông điệp điện tử bằng ……là để cho người nhận thông điệp đó hay bên thứ ba biết được nguồn gốc của thông điệp đó?",
    answer: "Chữ kí số",
  },
  // Module 2
  {
    question: "Phần mềm ứng dụng nào dùng để tạo bài thuyết trình?",
    answer: "Powerpoint",
  },
  {
    question: "Nhiệm vụ của Hệ điều hành là gì?",
    answer: "Quản lý tiến trình; Quản lý bộ nhớ máy tính",
  },
  {
    question:
      "Để xem thông tin phiên bản của Hệ điều hành cài đặt trên máy tính người dùng chọn thao tác nào sau đây?",
    answer: "Nhấn chuột phải vào Computer chọn Properties",
  },
  {
    question: "Mục tiêu chính của Hệ điều hành là gì?",
    answer: "Tách người dùng khỏi sự phức tạp của phần cứng",
  },
  {
    question:
      "Phát biểu nào là đúng khi nói về tùy chọn Change trong công cụ Uninstall a Program?",
    answer:
      "Thay đổi một chương trình bao gồm các tùy chọn cài đặt và gỡ bỏ của một ứng dụng",
  },
  {
    question:
      "Để xem thông tin chi tiết về hệ thống của máy tính cài Windows 7, người dùng lựa chọn thao tác nào sau đây?",
    answer: "Accessories →System Tools → Systems Information",
  },
  {
    question: "Lựa chọn các bước thực hiện để hiển thị bàn phím ảo?",
    answer: "Accessories →Ease of Access → On-Screen Keyboard; Vào run gõ osk",
  },
  {
    question: "Phím ESC có chức năng gì?",
    answer: "Hủy bỏ (cancel) một hoạt động đang thực hiện",
  },
  {
    question: "Phím Print Screen có chức năng gì?",
    answer: "Chụp toàn bộ màn hình đang hiển thị",
  },
  {
    question: "Chuột máy tính thuộc nhóm thiết bị nào?",
    answer: "Thiết bị nhập",
  },
  {
    question: "Hệ điều hành Windows 7 được lưu trữ ở đâu trong máy tính?",
    answer: "Hard disk",
  },
  {
    question:
      "Để thực hiện tạm dừng một bài hát đang phát bằng Windows Media Player người dùng chọn thao tác nào?",
    answer: "Nhấn Pause",
  },
  {
    question: "Chọn các phát biểu đúng khi nói về tệp tin?",
    answer:
      "Nén tệp tin là việc làm giảm dung lượng tệp tin gốc mà không làm mất dữ liệu của tệp tin gốc; Nén tệp tin giúp tăng không gian lưu trữ; Nén tệp tin giúp giảm băng thông đường truyền trên mạng",
  },
  {
    question:
      "Lựa chọn bảng mã để gõ tiếng Việt với phông chữ là Times New Roman.",
    answer: "Unicode",
  },
  {
    question:
      "Trong bảng điều khiển phần mềm Unikey. Bảng mã chọn là Unicode thì kiểu gõ lựa chọn để gõ tiếng Việt là gì?",
    answer: "Telex",
  },
  {
    question: "Lựa chọn các cách tắt máy tính đúng?",
    answer: "Nhấn nút Start, chọn Shut down; Nhấn Alt+F4, chọn Shut down",
  },
  {
    question:
      "Để thay đổi mật khẩu cho máy tính cài hệ điều hành Windows 7  người dùng chọn cách nào sau đây?",
    answer: "Control Panel -> User account -> Change your password",
  },
  {
    question: "Chọn các phát biểu đúng?",
    answer:
      "Chuột máy tính và touchpad có chức năng gần như nhau; Để kích hoạt một ứng dụng, nhấn đúp chuột trái.; Để tạo hiển thị một trình đơn tắt với nhiều tùy chọn cho thư mục. Di chuyển con trỏ chuột đến thư mục sau đó nhấn chuột phải",
  },
  {
    question:
      "Khi sử dụng touchpad để kéo một tệp tin sang vị trí mới trên màn hình Desktop người dùng thao tác như thế nào?",
    answer:
      "Chọn tệp tin sau đó giữ phím Ctrl rồi di tay trên touchpad đến vị trí mới",
  },
  {
    question:
      "Để gỡ bỏ một ứng dụng, từ nút Start người dùng lựa chọn vào mục nào?",
    answer: "Control Panel",
  },
  {
    question: "Các tệp tin hệ thống có phần đuôi mở rộng là gì?",
    answer: ".sys",
  },
  {
    question: "Các tệp tin văn bản có phần đuôi mở rộng là gì?",
    answer: ".doc; .rtf",
  },
  { question: "Tệp tin nén có các phần mở rộng là?", answer: ".rar; .zip" },
  {
    question: "Chọn các đáp án đúng khi nói về WinRAR",
    answer:
      'Add to archive...: Mở chương trình WinRAR để tạo tập tin nén với nhiều lựa chọn khác.; Add to "tên_tập_tin.rar": Tạo nhanh tập tin nén và lấy tên của chính đối tượng được chọn.',
  },
  {
    question: "Phiên bản MS-Office 2013 hỗ trợ lưu các định dạng mở rộng nào?",
    answer: "*.pdf; *.rtf; *.txt",
  },
  {
    question:
      "Chuyển đổi định dạng từ pdf sang word dùng Solid Converter PDF người dùng chọn mục nào?",
    answer: "(Nội dung mục D)",
  },
  {
    question: "Chọn các đáp án đúng.",
    answer:
      "TCVN3: Là bảng mã theo tiêu chuẩn (cũ) của Việt Nam.; Font là tập hợp hoàn chỉnh các chữ cái, các dấu câu, các con số, và các ký tự đặc biệt, theo một kiểu loại, định dạng (thường hoặc đậm nét), hình dáng (thẳng hoặc nghiêng) và kích cỡ phù hợp và có thể phân biệt khác nhau; Unicode: Là bộ mã chuẩn quốc tế được thiết kế để dùng làm bộ mã duy nhất cho tất cả các ngôn ngữ khác nhau trên thế giới",
  },
  {
    question: "Chọn các phông chữ hỗ trợ gõ tiếng Việt với bảng mã Unicode",
    answer: "Tahoma; Time New Roman",
  },
  {
    question:
      "Các phông chữ “.Vnarial, .Vntime, .VnarialH, .VntimeH”  sử dụng bảng mã nào để gõ tiếng Việt?",
    answer: "TCVN3; ABC",
  },
  {
    question: "Đâu là các lựa chọn cấu hình Unikey 4.0 khởi động cùng máy tính",
    answer: "Show this dialog box at startup; Auto-run UniKey at boot time",
  },
  {
    question:
      "Để chuyển đổi các bảng mã với Unikey 4.0 người dùng lựa chọn mục nào?",
    answer: "Toolkit",
  },
  {
    question:
      "Để lưu một tên mới cho một tệp tin MS-Word đang chỉnh sửa người dùng thực hiện như thế nào?",
    answer: "Vào File chọn Save As",
  },
  {
    question: "Chọn các phát biểu đúng",
    answer:
      "Chuột trái (left button) dùng để chọn, mở hay kích chạy một ứng dụng; Chuột phải (right button) dùng mở một số trình menu lệnh; Trong một số chương trình xử lý ảnh nút cuộn có tác dụng phóng to thu nhỏ",
  },
  {
    question:
      "Để phân loại nội dung theo kiểu trong một thư mục, người dùng chọn cột nào?",
    answer: "Type",
  },
  {
    question: "Sắp xếp các bước sử dụng máy tính đúng cách và an toàn",
    answer: "1-3-2-4",
  },
  {
    question: "Để bật máy tính người dùng sử dụng cách nào sau đây?",
    answer: "Nhấn nút Power trên thùng máy tính",
  },
  {
    question: "Chọn các đáp án đúng",
    answer:
      "Bàn phím thật có nhiều nút hơn bàn phím ảo; Bàn phím ảo không có dãy phím chức năng",
  },
  { question: "Sắp xếp các bước để tắt máy tính đúng cách", answer: "2-3-1-4" },
  {
    question: "Lựa chọn các cách tắt máy tính đúng cách?",
    answer: "Nhấn Start chọn Shutdown; Nhấn tổ hợp phím Alt+F4, chọn Shutdown",
  },
  {
    question: "Phím Backspace có các tác dụng gì?",
    answer:
      "Xóa một ký tự ở phía trái của con trỏ chuột; Quay trở lại bước trước trong cửa sổ Windows Explorer; Lui dấu nháy về phía trái một ký tự",
  },
  {
    question:
      "Phím có chức năng thu nhỏ toàn bộ cửa sổ xuống thanh Taskbar để hiển thị màn hình Desktop?",
    answer: "Nhấn tổ hợp phím Windows + D; Nhấn tổ hợp phím Windows + M",
  },
  {
    question:
      "Trong cửa sổ Screen Resolution, để thay đổi độ phân giải của màn hình người dụng chọn mục nào?",
    answer: "Resolution",
  },
  {
    question: "Để kích hoạt nút Start người dùng chọn các cách nào?",
    answer:
      "Nhấn chuột vào nút Start; Nhấn phím Window trên bàn phím; Nhấn Ctrl +Esc trên bàn phím",
  },
  {
    question:
      "Để xem các chương trình được cài đặt trên máy tính. Với tùy chọn từ nút Start",
    answer: "All Program",
  },
  {
    question: "Chọn các đáp án đúng khi nói về chế độ Sleep trên máy tính?",
    answer:
      "Ram vẫn hoạt động khi chọn chế độ Sleep; CPU không hoạt động khi chọn chế độ Sleep; Có thể sạc điện thoại qua cổng USB khi chọn chế độ Sleep cho máy tính",
  },
  {
    question:
      "Chọn đáp án đúng khi người dùng lựa chọn chế độ Sleep trên máy tính xách tay?",
    answer: "Vẫn sử dụng nguồn điện; Dữ liệu trên Ram vẫn còn",
  },
  {
    question:
      "Để khóa màn hình máy tính đang sử dụng người dùng có thể chọn các cách nào?",
    answer: "Nhấn phím Window + L; Nhấn nút Start, chọn Lock",
  },
  {
    question: "Chọn các phát biểu đúng",
    answer:
      "Chế độ Hibernate tiết kiệm điện hơn chế độ Sleep; Chế độ Sleep có thể sạc được pin cho điện thoại qua cổng USB; Chế độ Sleep khởi động lại nhanh hơn chế độ Hibernate",
  },
  {
    question:
      "Để chuyển sang tài khoản người dùng khác mà không cần đăng xuất khỏi tài khoản hiện hành. Người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn Switch user",
  },
  {
    question:
      "Khi người dùng chọn chế độ Log off trên máy tính. Điều đó có nghĩa là gì?",
    answer:
      "Đóng tất cả các mục đang mở, đăng xuất ra khỏi tài khoản người dùng hiện tại, và trở về màn hình đăng nhập.",
  },
  {
    question:
      "Khi người dùng lựa chọn chế độ Hibernate trên máy tính. Điều đó có nghĩa là gì?",
    answer:
      "Lưu trạng thái làm việc của máy tính vào ổ cứng, rồi tắt máy tính; Phải bật nguồn để khởi động máy tính",
  },
  {
    question:
      "Để thay đổi tùy chỉnh của màn hình Desktop trong Windows 7. Người dùng có thể lựa chọn các cách nào sau đây?",
    answer:
      "Nhấn chuột phải lên trên Desktop, chọn Personalize; Vào Start, Control Panel chọn Appearance and Pesonalization, chọn Personalize",
  },
  {
    question: "Chọn các đáp án đúng",
    answer:
      "My Themes:  Các chủ đề đã tùy biến, đã lưu hoặc tải về; Installed Themes: Các chủ đề được tạo bởi các nhà sản xuất máy tính hoặc các nhà cung cấp ngoài Microsoft; Aero Themes: Các chủ đề bao gồm các hiệu ứng Aero glass và nhiều chủ đề bao gồm một bản trình chiếu màn hình nền.",
  },
  {
    question: "Trong Windows 7, nhóm “Basic and High Contrast Themes” là gì?",
    answer:
      "Các chủ đề được thiết kế để cải thiện hiệu suất của máy tính hoặc làm cho các đối tượng dễ nhìn thấy hơn",
  },
  {
    question: "Chủ đề không bao gồm các hiệu ứng Aero glass?",
    answer: "Basic and High Contrast Themes",
  },
  {
    question: "Chọn các đáp án đúng",
    answer:
      "Taskbar Buttons: Nút hiển thị cho mỗi chương trình ứng dụng đang mở và một số ứng dụng được xây dựng sẵn trong Windows.; Show desktop button: Nhấp chuột vào nó để ngay lập tức thu nhỏ tất cả cửa sổ đang mở trên Desktop; Start Button: Nhấn vào đây để mở trình đơn và chọn đối tượng để mở các chương trình, tìm các tập tin, hoặc tắt máy",
  },
  {
    question:
      "Để thay đổi màu cho đường viền cửa sổ người dùng sử dụng tùy chọn nào?",
    answer: "Window Color",
  },
  {
    question: "Các cách có thể để kích hoạt Help trên Window 7",
    answer:
      "Nhấn nút (Help) trong bất kì hộp thoại; Nhấn vào Start, chọn Help and Support; Nhấn phím F1",
  },
  {
    question:
      "Chọn đáp án đúng về thanh công cụ ở trên cùng của mỗi cửa sổ Help",
    answer:
      "Arrows: Cho phép bạn đến lại các bước thông qua hệ thống Help.; Browse Help: Hiển thị vị trí hiện tại trong mục lục; Learn about other support options: Đi đến trang web của Microsoft để được hỗ trợ nhiều hơn nữa",
  },
  {
    question: "Cách xóa biểu tượng trên màn hình Desktop",
    answer:
      "Nhấn chuột vào biểu tượng muốn xóa, nhấn phím delete; Nhấn chuột phải vào biểu tượng muốn xóa, chọn Delete; Nhấn và giữ chuột trái, di biểu tượng tới thùng rác.",
  },
  {
    question: "Chọn các đáp án đúng?",
    answer:
      "Extra Large Icons: Hiển thị các tệp tin và thư mục bằng các biểu tượng rất lớn; Detail: Liệt kê nội dung của các thư mục đang mở và cung cấp thông tin chi tiết về các tệp tin và thư mục bên trong nó, bao gồm tên, kiểu, cỡ và ngày tháng chỉnh sửa; Content: Hiển thị một số thuộc tính và nội dung tham chiếu của tệp tin",
  },
  {
    question:
      "Để chọn toàn bộ tệp tin và thư mục trong ổ đĩa D, người dùng nhấn tổ hợp phím nào sau đây?",
    answer: "Ctrl + A",
  },
  {
    question:
      "Để thực hiện tìm kiếm ở chế độ nâng cao trên máy tính người dùng thực hiện như thế nào?",
    answer:
      "Từ Menu Start nhập từ khóa vào ô tìm kiếm sau đó click chuột vào “See more result”",
  },
  {
    question:
      "Trong hình sau, vị trí của Taskbar Notification Area là vị trí số mấy?",
    answer: "6",
  },
  {
    question:
      "Để đóng một cửa sổ ứng dụng đang làm việc người dùng sử dụng tổ hợp phím nào sau đây?",
    answer: "Alt+F4",
  },
  {
    question:
      "Để hiển thị icon Computer trên màn hình Desktop người dùng có thể lựa chọn cách nào sau đây?",
    answer:
      "Vào Start, nhấn chuột phải vào Computer, chọn Show on Desktop; Vào Desktop icons, đánh dấu chọn Computer, nhấn Apply",
  },
  {
    question: "Chọn đáp án đúng khi người dùng chọn Minimize?",
    answer: "Thu nhỏ lại cửa sổ; Thay cửa sổ bằng một nút trên thanh tác vụ",
  },
  {
    question:
      "Để hiển thị cửa sổ ra toàn màn hình người dùng lựa chọn cách nào?",
    answer: "Maximize",
  },
  {
    question:
      "Để hiển thị thanh menu trong cửa sổ Windows Explorer người dùng nhấn phím nào?",
    answer: "Nhấn Alt",
  },
  {
    question:
      "Để tắt một ứng dụng đang bị treo người dùng lựa chọn cách nào sau?",
    answer: "Vào Windows task manager, chọn ứng dụng bị treo nhấn End Task",
  },
  {
    question:
      "Phát biểu nào sau đây là đúng khi người dùng lựa chọn Switch user trên máy tính?",
    answer:
      "Chuyển sang tài khoản người dùng khác mà không cần đăng xuất khỏi tài khoản hiện hành",
  },
  {
    question:
      "Phát biểu nào sau đây là đúng về chế độ Hibernate trên máy tính?",
    answer: "Lưu toàn bộ trạng thái làm việc của máy vào ổ cứng rồi tắt máy",
  },
  {
    question:
      "Để thiết lập không hiển thị icon Recycle Bin trên màn hình Desktop, người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn bỏ chọn Recycle Bin trong cửa sổ Desktop Icon Settings",
  },
  {
    question:
      "Để thiết lập kích thước hiển thị cho các icon trên màn hình Desktop lớn nhất, người dùng lựa chọn mục nào trong thẻ View?",
    answer: "Largr icons",
  },
  {
    question: "Trong các phần mềm sau, phần mềm nào là phần mềm ứng dụng?",
    answer: "Microsoft Word",
  },
  {
    question: "Lựa chọn biểu tượng của máy in được cài đặt trên máy tính",
    answer: "D",
  },
  {
    question: "Chọn đáp án đúng khi nói về máy in trong hình",
    answer:
      "Máy in được chia sẻ qua mạng, Máy in có địa chỉ IP 172.16.105.225, Có thể in từ máy in này",
  },
  {
    question: "Một máy in có trạng thái như trong hình có ý nghĩa gì?",
    answer: "Máy in mặc định, Trạng thái offline (không kết nối với máy tính)",
  },
  {
    question:
      "Để xóa bỏ một máy in trên máy tính người dùng có thể lựa chọn các phương án nào?",
    answer:
      "Chọn máy in, nhấn Remove devices, Nhấn chuột phải lên máy in, chọn Remove devices",
  },
  {
    question: "Để thêm một máy in chia sẻ qua mạng, người dùng cần điều gì?",
    answer:
      "Kết nối đến được địa chỉ IP của máy tính có máy in chia sẻ, Máy in chia sẻ qua mạng phải được bật",
  },
  {
    question:
      "Để thiết lập một máy in mặc định trên máy tính người dùng phải thực hiện như thế nào?",
    answer: "Nhấn chuột phải vào máy in, chọn Set as default printer.",
  },
  {
    question:
      "Lựa chọn các cách có thể cài driver cho một máy in đang được kết nối với máy tính.",
    answer:
      "Vào manager, chọn update driver cho máy in, Vào Devices and Printers, chọn Add a print, Chạy file setup.exe trong thư mục driver của máy in",
  },
  {
    question:
      "Để xóa một lệnh in trong danh sách các lệnh đang in, người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn chuột phải lên lệnh in trong hàng đợi, chọn Cancel",
  },
  {
    question: "Để cài đặt máy in trên máy tính cần các thiết bị nào?",
    answer: "Máy in, Dây kết nối USB hoặc LPT, Đĩa Driver của máy in",
  },
  {
    question: "Các cổng có thể kết nối máy tính với máy in?",
    answer: "USB, LPT",
  },
  {
    question: "Các cách có thể để cài đặt máy in vào máy tính?",
    answer:
      "Chạy tệp tin cài đặt máy in, Vào Devices and Printers, nhấn Add a local printer, Vào manager, update driver cho máy in vừa kết nối",
  },
  {
    question: "Các bước để thực hiện chia sẻ máy in qua mạng là?",
    answer: "Nhấn chuột phải vào máy in chọn Printer Properties, nhấn Sharing",
  },
  {
    question:
      "Để in một tài liệu ra 6 bản, người dùng nhấn Ctrl+P  sau đó chọn mục nào?",
    answer: "Copies nhập sô 6",
  },
  {
    question:
      "Để chọn in một tài liệu trên MS-Word, người dùng có thể sử dụng các cách nào sau?",
    answer: "Ctrl + P, Nhấn File, chọn Print, Nhấn Quick Print",
  },
  {
    question:
      "Để thay đổi thứ tự in ấn hay độ ưu tiên trên máy in, người dùng chọn mục nào sau đây?",
    answer: "Properties",
  },
  {
    question: "Điều gì là đúng khi sử dụng phần mềm diệt virus miễn phí?",
    answer: "Không phải trả phí, Không xác định thời gian hết hạn",
  },
  {
    question: "Chọn các phần mềm diệt virus miễn phí?",
    answer: "Microsoft Security Essentials (MSE), CMC Antivirus",
  },
  {
    question: "Chức năng của phần mềm diệt Virus là gì?",
    answer: "Bảo vệ dữ liệu, Phát hiện virus, Loại bỏ phần mềm độc hại",
  },
  {
    question: "Phần mềm Microsoft Security Essentials là phần mềm gì?",
    answer:
      "Bảo vệ máy tính theo thời gian thực, Phần mềm của Microsoft phát triển",
  },
  {
    question:
      "Khi cài phần mềm Microsoft Security Essentials. Thời gian sử dụng của phần mềm là bao lâu?",
    answer: "Không xác định thời gian sử dụng",
  },
  {
    question: "Những đặc điểm của phần mềm diệt virus có bản quyền là gì?",
    answer: "Người sử dụng phải trả phí, Có xác định thời gian hết hạn",
  },
  {
    question:
      "Để quét ổ đĩa C trên máy tính với Microsoft Security Essentials. Trong tùy chọn quét người dụng chọn mục nào?",
    answer: "Tùy chỉnh",
  },
  {
    question:
      "Trong cửa sổ Change keyboards or other input methods để thêm kiểu gõ cho bàn phím chọn thẻ nào sau đây?",
    answer: "General",
  },
  {
    question:
      "Ngôn ngữ mặc định của bàn phím sau khi cài đặt lại Hệ điều hành Windows 7 cho máy tính là gì?",
    answer: "English, US",
  },
  {
    question:
      "Để chuyển đổi chế độ gõ bàn phím sang tiếng Việt và ngược lại người dùng có thể lựa chọn các cách nào sau?",
    answer: "Ctrl+Shift, Alt+Z",
  },
  {
    question:
      "Để xóa dữ liệu trong thùng rác, người dùng có thể lựa chọn các cách nào sau đây?",
    answer:
      "Trên thanh lệnh, nhấn chuột vào Empty the Recycle Bin; Nhấn chuột phải vào khoảng trống của cửa sổ thùng rác, chọn Empty Recycle Bin; Nhấn chuột phải vào biểu tượng thùng rác trên màn hình, chọn Empty Recycle Bin",
  },
  {
    question:
      "Để xóa tạm thời một thư mục trên máy tính người dùng có thể sử dụng các cách nào sau đây?",
    answer:
      "Nhấn Delete; Nhấn và giữ chuột trái, di thư mục tới thùng rác.; Click chuột phải lên thư mục chọn Delete",
  },
  {
    question:
      "Khi thực hiện xóa một tệp tin xuất hiện thông báo như trong hình. Điều này có nghĩa là gì?",
    answer: "Tệp tin đang mở",
  },
  {
    question:
      "Để khôi phục tệp tin có tên là cntt.docx vừa xóa người dùng phải thực hiện như thế nào?",
    answer:
      "Mở thùng rác, tìm và chọn tệp tin cntt.docx. Nhấn chuột phải chọn Restore",
  },
  {
    question:
      "Hành động người dùng chọn một tệp tin, sau đó nhấn một lần chuột vào tệp tin có ý nghĩa gì?",
    answer: "Đặt lại tên cho tệp tin",
  },
  {
    question:
      "Các cách để thay đổi tên cho một thư mục trên máy tính cài đặt Hệ điều hành Windows 7?",
    answer:
      "Chọn thư mục, nhấn phím F2; Nhấn chuột phải vào thư mục chọn Rename",
  },
  {
    question: "Các ký tự không thể sử dụng để đặt tên cho tệp tin hay thư mục?",
    answer: "?; \\; *",
  },
  {
    question: "Lựa chọn ký tự có thể dùng để đặt tên cho thư mục",
    answer: "#; $",
  },
  {
    question: "Chọn nhóm các ký tự có thể sử dụng để đặt tên cho tệp tin?",
    answer: "+ - _ x",
  },
  {
    question:
      "Để chọn tất cả các tệp tin và thư mục trong thư mục CNTT người dùng có thể lựa chọn các thao tác nào sau đây?",
    answer:
      "Nhấn tổ hợp phím Ctrl+A; Nhấn chuột vào tập tin hay thư mục đầu tiền trong danh sách, nhấn phím Shift sau đó đưa con trỏ chuột đến tệp tin hay thư mục cuối cùng; Nhấn chuột vào Organize, chọn Select All",
  },
  {
    question:
      "Để đổi tên thư mục CNTT thành HTTT, người dùng có thể thực hiện như thế nào?",
    answer:
      "Nhấn chuột chọn thư mục CNTT, nhấn F2, gõ HTTT; Nhấn chuột phải vào thư mục CNTT chọn Rename, gõ HTTT",
  },
  {
    question: "Phát biểu đúng về phần đuôi mở rộng của tệp tin.",
    answer: "Có thể chỉ ra kiểu của tệp tin đó",
  },
  {
    question: "Chọn tệp tin nén có tên là CNTT.",
    answer: "CNTT.rar; CNTT.zip",
  },
  {
    question: "Chọn phát biểu đúng về tệp tin ẩn.",
    answer: "Tệp tin ẩn chỉ hiển thị khi tất cả các tệp tin ẩn hiển thị",
  },
  {
    question: "Phát biểu nào là đúng?",
    answer:
      "Khi di chuyển tệp tin sử dụng lệnh Cut và Paste; Khi sao chép tệp tin sử dụng lệnh Copy và Paste",
  },
  {
    question:
      "Trên màn hình Desktop để thay đổi độ phân giải của màn hình người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn chuột phải chọn Screen resolution",
  },
  {
    question:
      "Đường dẫn (path) đúng cho tệp tin cntt.docx trong thư mục CNTT trong ổ D là?",
    answer: "D:\\CNTT\\cntt.docx",
  },
  {
    question: "Tên của tệp tin tối đa có bao nhiêu ký tự?",
    answer: "255 và không có ký tự đặc biệt",
  },
  {
    question:
      "Để xóa tạm thời một tệp tin, người dùng lựa chọn cách nào dưới đây?",
    answer: "Chọn tệp tin nhấn phím Delete",
  },
  {
    question:
      "Cách xóa vĩnh viễn một tệp tin trên máy tính. Người dùng thực hiện lựa chọn cách nào sau đây?",
    answer: "Chọn tệp tin cần xóa, nhấn Shift+Delete",
  },
  {
    question:
      "Để khôi phục một tệp tin vừa xóa tạm thời. Người dùng phải thực hiện như thế nào?",
    answer:
      "Di chuyển vào thùng rác (Recycle Bin), tìm tệp tin vừa xóa. Nhấn chuột phải lên tệp tin chọn Restore.",
  },
  {
    question:
      "Để xóa một thư mục tạm thời. Người dùng có thể sử dụng các cách nào sau đây?",
    answer:
      "Chọn thư mục, sau đó nhấn phím Delete; Nhấn chuột phải lên thư mục chọn Delete; Nhấn và giữ chuột trái, di biểu tượng tới thùng rác.",
  },
  {
    question: "Các cách có thể để mở một cửa số Windows Explorer là?",
    answer:
      "Nhấp chuột vào Start và sau đó nhấn chuột vào Computer.; Nhấp chuột vào Start, All Programs, Accessories, sau đó nhấn chuột vào Windows Explorer.; Nhấn tổ hợp phím Windows + E.",
  },
  {
    question:
      "Xem thông tin đầy đủ về một tệp tin, người dùng lựa chọn cách nào dưới đây?",
    answer: "Nhấn chuột phải lên tệp tin chọn Properties",
  },
  {
    question:
      "Để ẩn một tệp tin trong thư mục, người dùng lựa chọn cách nào dưới đây?",
    answer: "Nhấn chuột phải chọn Properties, đánh dấu Hidden. Ok",
  },
  {
    question:
      "Khi xóa một biểu tượng shortcut của một thư mục. Điều đó có nghĩa là gì?",
    answer: "Chỉ xóa icon shortcut, thư mục không bị xóa",
  },
  {
    question:
      "Để tạo một thư mục mới, người dùng có thể sử dụng các cách nào dưới đây?",
    answer:
      "Nhấn chuột phải chọn New-> Folder; Trên thanh lệnh, Nhấp chuột vào",
  },
  {
    question:
      "Lựa chọn các cách có thể đổi tên cho một thư mục trên máy tính cài Hệ điều hành Windows 7.",
    answer:
      "Nhấn chuột vào biểu tượng thư mục, sau đó nhấn chuột vào tên thư mục để kích hoạt chế độ chỉnh sửa.; Trên thanh lệnh, nhấp chuột vào và sau đó nhấn chuột vào Rename.; Nhấn chuột phải lên thư mục chọn Rename.",
  },
  {
    question:
      "Để chia sẻ một tệp tin cntt.docx trong mạng Lan. Người dùng có thể lựa chọn các cách nào sau đây?",
    answer:
      "Di chuyển tệp tin và thư mục đã được chia sẻ; Di chuyển tệp tin vào thư mục mới",
  },
  {
    question:
      "Để tạo một shortcut cho thư mục CNTT trên màn hình Desktop người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn chuột phải lên thư mục CNTT, chọn Send to Desktop",
  },
  {
    question: "Khi thấy một thư mục như sau, điều đó có ý nghĩa gì?",
    answer: "Đổi tên thư mục",
  },
  {
    question:
      "Chọn các phát biểu đúng để khôi phục tập tin hay thư mục trong thùng rác.",
    answer:
      "Nhấn chuột chọn tệp tin hay thư mục sau đó nhấn chuột phải chọn Restore; Nhấn chuột chọn tệp tin hay thư mục sau đó chọn Restore this item; Nhấn chuột vào Restore all items để khôi phục tất cả",
  },
  { question: "Chế độ xem trong hình dưới là gì?", answer: "Tiles" },
  {
    question:
      "Chế độ xem hiển thị các tập tin hay thư mục bằng các biểu tượng cỡ trung bình, có tên tệp tin ở bên phải biểu tượng, định dạng và kích cỡ tệp tin là?",
    answer: "Tiles",
  },
  {
    question:
      "Tùy chọn Screen Saver trên Hệ điều hành Windows 7 có chức năng gì?",
    answer: "Chọn chế độ bảo vệ màn hình",
  },
  {
    question: "Các cách bật chế độ gõ chữ in Hoa trên máy tính là?",
    answer: "Caps Lock; Giữ phím Shift và gõ chữ cái",
  },
  { question: "Phông chữ Tahoma sử dụng cho bảng mã nào?", answer: "Unicode" },
  {
    question: "Phông chữ VNTime sử dụng bảng mã nào để gõ tiếng Việt?",
    answer: "ABC; TCVN3",
  },
  {
    question:
      "Khi người dùng sao chép tệp tin cntt.ppt vào thư mục CNTT mà đã có sẵn tệp cùng tên, hệ thống sẽ đưa ra các lựa chọn gì?",
    answer: "Copy and Replace; Don’t copy; Copy, but keep both files",
  },
  {
    question:
      "Xuất hiện thông báo “Don’t copy” khi sao chép một tệp tin có nghĩa là gì?",
    answer: "Đã có một tệp tin giống tệp tin sao chép",
  },
  {
    question:
      "Khi xuất hiện lựa chọn “Copy, but keep both files”, điều đó có nghĩa là gì?",
    answer:
      "Giữ nguyên tệp tin trong thư mục, và đổi tên tệp tin sao chép bằng cách đánh số ở cuối tệp tin",
  },
  {
    question: "Khi lựa chọn Copy and Replace có nghĩa là gì?",
    answer: "Dữ liệu trong tệp tin mới sẽ chèn vào tệp tin đang có",
  },
  {
    question: "Các cách tìm kiếm tất cả tệp tin có đuôi .pdf trong ổ đĩa C là?",
    answer:
      "Nhấn Start, nhập từ khóa “*.pdf” vào ô tìm kiếm; Vào ổ đĩa C, nhập từ khóa “*.pdf” vào ô tìm kiếm",
  },
  {
    question:
      "Để tìm kiếm toàn bộ file có đuôi là txt trên máy tính người dùng thực hiện như thế nào?",
    answer: "Vào Computer, nhập từ khóa “*.txt” vào ô tìm kiếm",
  },
  {
    question:
      "Để tìm kiếm các tệp tin, thư mục có chữ CNTT, người dùng có thể làm gì?",
    answer:
      "Nhập từ khóa “cntt”; Nhập từ khóa “CNTT”; Nhập từ khóa “*CNTT*” vào ô tìm kiếm",
  },
  {
    question:
      "Để tìm kiếm tất cả các tệp tin chỉnh sửa ngày 27/07/2016, người dùng cần làm gì?",
    answer:
      "Đưa con trỏ chuột vào ô tìm kiếm, nhấn chọn Date modefile là ngày 27/07/2016",
  },
  {
    question:
      "Để xóa một tệp tin ẩn trong ổ đĩa C, người dùng cần phải làm gì?",
    answer: "Không xóa được",
  },
  {
    question:
      "Trong mục Advanced settings, để luôn hiển thị phần mở rộng của tệp tin trong danh sách, người dùng cần bỏ chọn mục nào?",
    answer: "Hide extensions for known file types",
  },
  {
    question: "Đâu là một thư mục shortcut?",
    answer: "Là thư mục có biểu tượng mũi tên nhỏ ở góc",
  },
  {
    question: "Đâu là biểu tượng icon Computer trên màn hình Desktop?",
    answer: "Biểu tượng có hình máy tính với tên 'Computer'",
  },
  // Module 3
  {
    question: "Trong soạn thảo văn bản, người dùng sử dụng phím Enter khi nào?",
    answer:
      "Khi đến cuối của một đoạn văn bản hoặc khi muốn chèn thêm một dòng trống",
  },
  {
    question:
      "Phím tắt nào sau đây để đưa con trỏ chuột về vị trí đầu tiên của văn bản?",
    answer: "Ctrl+Home",
  },
  {
    question:
      "Phím tắt hoặc tổ hợp phím nào sau đây để đưa con trỏ chuột về vị trí đầu dòng của dòng văn bản hiện tại?",
    answer: "Home",
  },
  {
    question:
      "Phím tắt hoặc tổ hợp phím nào sau đây chuyển con trỏ chuột đến trang tiếp ngay sau trang hiện tại?",
    answer: "PageDown",
  },
  {
    question:
      "Phím tắt hoặc tổ hợp phím nào sau đây giúp chuyển con trỏ chuột đến đoạn văn bản tiếp theo bên dưới?",
    answer: "Ctrl+Down Arrow",
  },
  {
    question: "Phím nào sau đây sử dụng để chọn các văn bản không liên tiếp?",
    answer: "Ctrl",
  },
  {
    question: "Phím nào sau đây sử dụng để chọn các văn bản liên tiếp?",
    answer: "Shift",
  },
  {
    question:
      "Điều gì được thể hiện khi biểu tượng con trỏ chuột như hình dưới đây?",
    answer:
      "Con trỏ chuột trong vùng Thanh lựa chọn (Selection Bar) và cho phép chọn một khối văn bản",
  },
  {
    question: "Đâu là tên mở rộng định danh của tài liệu Word 2010?",
    answer: ".docx",
  },
  {
    question: "Lựa chọn tổ hợp phím tắt nào để căn lề giữa cho văn bản?",
    answer: "Ctrl + E",
  },
  {
    question: "Chức năng của Margins trong thực đơn Page Layout là gì?",
    answer: "Định dạng lề giấy",
  },
  {
    question: "Trong Microsoft Word, hộp thoại Paragraph có chức năng gì?",
    answer: "Điều chỉnh khoảng cách giữa các đoạn, các dòng trên văn bản.",
  },
  {
    question:
      "Lệnh dán tất cả (Paste All) làm việc từ bộ nhớ tạm của Microsoft Word thực hiện như thế nào?",
    answer:
      "Dán tất cả mọi thứ trong bộ nhớ tạm theo thứ tự bạn thu thập được chúng",
  },
  {
    question: "Chuyện gì xảy ra khi người dùng thay đổi kích thước phông chữ?",
    answer: "Ký tự được điều chỉnh cả chiều cao và chiều rộng",
  },
  {
    question:
      "Cho đoạn văn bản được định dạng như sau. Hãy cho biết đoạn văn bản được định dạng theo kiểu gì?",
    answer: "Đoạn văn bản được căn đều hai bên",
  },
  {
    question:
      "Hãy cho biết biểu tượng sau tương ứng với kiểu điều chỉnh người dùng tab nào?",
    answer: "Left tab",
  },
  {
    question:
      "Hãy cho biết biểu tượng sau tương ứng với kiểu điều chỉnh người dùng tab nào?",
    answer: "Center tab",
  },
  {
    question:
      "Hãy cho biết biểu tượng sau tương ứng với kiểu điều chỉnh người dùng tab nào?",
    answer: "Right tab",
  },
  {
    question:
      "Hãy cho biết biểu tượng sau tương ứng với kiểu điều chỉnh người dùng tab nào?",
    answer: "Decimal tab",
  },
  {
    question:
      "Hãy cho biết biểu tượng sau tương ứng với kiểu điều chỉnh người dùng tab nào?",
    answer: "Bar tab",
  },
  {
    question:
      "Hãy cho biết lí do bạn muốn tùy chỉnh kiểu biểu tượng liệt kê danh sách (bullet style)?",
    answer: "Để tạo ra một cách nhìn khác cho tài liệu",
  },
  {
    question:
      "Lựa chọn nào sau đây dùng thay đổi khoảng cách giữa các dòng văn bản?",
    answer: "Line spacing",
  },
  {
    question:
      "Chức năng nào sau đây bạn có thể sử dụng khi cần định dạng một vài khối văn bản, cách chia sẻ các lựa chọn định dạng tương tự?",
    answer: "Styles",
  },
  {
    question:
      "Lựa chọn nào sau đây cho phép bỏ qua các ký tự tìm kiếm, nếu ký tự tìm kiếm là một phần của một từ?",
    answer: "Find whole words only",
  },
  {
    question:
      "Chức năng nào quyết định kích thước trang giấy mặc định trong hệ thống?",
    answer: "Page Layout",
  },
  {
    question: "Mục đích của việc thiết lập lề giấy là gì?",
    answer: "Để xác định khoảng cách giữa các cạnh của giấy và phần văn bản in",
  },
  {
    question:
      "Phím tắt hoặc tổ hợp phím nào sau đây dùng để chèn ngắt một trang cứng?",
    answer: "Ctrl+Enter",
  },
  {
    question: "Thẻ nào trong Ribbon giúp bạn làm việc với các số trang?",
    answer: "Insert",
  },
  {
    question: "Thẻ nào trong Ribbon giúp bạn làm việc với phần mục lục?",
    answer: "Reference",
  },
  {
    question:
      "Thẻ nào trong Ribbon giúp bạn chia tài liệu thành nhiều cột khác nhau?",
    answer: "Page Layout",
  },
  {
    question:
      "Cách hiển thị nào sau đây hiển thị các cột của văn bản như một cột, cho phép bạn tập trung chỉnh sửa các văn bản thay vì cách bố trí tài liệu?",
    answer: "Draft",
  },
  {
    question: "Hãy cho biết lựa chọn nào cho phép bạn in các trang cụ thể?",
    answer: "Pages",
  },
  {
    question:
      "Một đối tượng được chọn trong tài liệu sẽ có biểu hiện như thế nào?",
    answer: "Xuất hiện vùng chọn có viền xung quanh đối tượng",
  },
  {
    question: "Chọn thẻ Ribbon để thêm một đối tượng vào tài liệu?",
    answer: "Insert",
  },
  {
    question: "Chọn chức năng để điều hướng văn bản xung quanh bức tranh?",
    answer: "Wrap Text",
  },
  {
    question:
      "Tùy chọn nào trong Microsoft Word cho phép người dùng tự động tạo ra một bảng?",
    answer: "Insert\\ Tables \\ Table \\Insert Table...",
  },
  {
    question:
      "Chọn lý do tại sao người dùng nên chỉ định dòng tiêu đề cho bảng dữ liệu?",
    answer:
      "Để hiển thị tên của từng cột khi lựa chọn thứ tự sắp xếp; Để không bao gồm hàng tiêu đề cột trong sắp xếp",
  },
  {
    question: "Sử dụng thẻ nào để thêm lời ghi chú vào tài liệu?",
    answer: "Review",
  },
  {
    question:
      "Làm thế nào để tạo ra một bản sao của chỉ phần đánh dấu (markup) trong tài liệu?",
    answer: "Sử dụng danh sách lệnh Markup từ tùy chọn Print All Pages",
  },
  {
    question:
      "Để đưa con trỏ nhập về cuối dòng hiện tại, nhấn phím hoặc tổ hợp phím nào?",
    answer: "End",
  },
  {
    question: "Để chọn toàn bộ văn bản, nhấn tổ hợp phím nào?",
    answer: "Ctrl+A",
  },
  {
    question:
      "Để lựa chọn một khối chữ nhật bất kỳ, người dùng đặt con trỏ tại vị trí phía trên bên trái, sau đó nhấn tổ hợp phím nào?",
    answer: "Ctrl+Shift+F8",
  },
  {
    question: "Dấu chấm phẩy (;) có công dụng như thế nào?",
    answer:
      "Dùng để chia một câu dài thành nhiều thành phần câu, mỗi phần câu đã diễn hết một ý, nhưng những ý này có liên quan đến nhau",
  },
  {
    question: "Để ẩn/hiển thị thanh Ribbon, có thể sử dụng cách nào:",
    answer:
      "Nhấn chuột phải lên Người dùng bất kỳ hoặc lên vùng trống trên thanh menu và chọn Minimize the Ribbon; Giữ Ctrl và nhấn phím F1 để ẩn hoặc hiển thị",
  },
  {
    question: "Để lưu mới một tập tin văn bản người dùng có thể làm cách nào?",
    answer:
      "Chọn vào biểu tượng trên góc trái của cửa sổ Word; Nhấn tổ hợp phím Ctrl + S; Chọn vào thẻ File, chọn lệnh Save",
  },
  {
    question:
      "Muốn chèn một hình ảnh từ một thư mục có sẵn trong máy tính vào Microsoft Word người dùng chọn cách nào sau đây?",
    answer: "Insert\\Picture",
  },
  {
    question:
      "Hiển thị thước theo chiều ngang và dọc văn bản trong Microsoft Word. Người dùng có thể thực hiện bằng cách nào?",
    answer: "View/Ruler",
  },
  {
    question:
      "Khi soạn thảo văn bản, để khai báo thời gian tự lưu văn bản, người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Save",
  },
  {
    question:
      "Khi định dạng văn bản, muốn hiển thị thanh thước đo dạng Centimeters, người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Advanced",
  },
  {
    question: "Sử dụng phím tắt nào sau đây để tạo một tài liệu trắng mới?",
    answer: "Ctrl+N",
  },
  {
    question: "Sử dụng phím tắt nào sau đây để hiển thị hộp thoại Font?",
    answer: "Ctrl+D",
  },
  {
    question: "Chọn thẻ nào để tạo được các đường viền như hình vẽ trong word?",
    answer: "Page Layout",
  },
  {
    question: "Để tạo chữ nghệ thuật, lựa chọn tùy chọn nào sau đây?",
    answer: "WordArt",
  },
  {
    question:
      "Muốn chèn số trang vào vị trí giữa của tiêu đề dưới của tài liệu, sử dụng tùy chọn nào sau đây?",
    answer: "Page Number",
  },
  {
    question:
      "Trong phiên bản Microsoft Word 2010 người dùng không thể thực hiện được việc nào?",
    answer: "Kiểm tra lỗi chính tả tiếng Việt.",
  },
  {
    question: "Chọn phát biểu sai:",
    answer: "Office chỉ cho phép chọn các định dạng header and footer có sẵn",
  },
  {
    question:
      "Muốn tạo được một chữ có dạng như sau : Word thì chọn mục nào sau khi chọn hộp thoại Font?",
    answer: "Double Strikethrough",
  },
  {
    question:
      "Muốn đặt tiêu đề cho các trang chẵn lẻ là khác nhau, người dùng sử dụng chức năng nào sau đây?",
    answer: "Page Layout",
  },
  {
    question:
      "Muốn định nghĩa các từ gõ tắt, người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Proofing",
  },
  {
    question:
      "Đối với các máy in không in được 2 mặt, muốn in các trang chẵn trước, trang lẻ sau hoặc ngược lại. Lựa chọn mục nào sau đây?",
    answer: "Print All Pages",
  },
  {
    question:
      "Trong soạn thảo văn bản với Microsoft Word, muốn tạo ký tự to đầu dòng của đoạn văn, người dùng thực hiện trong thẻ nào sau đây?",
    answer: "Insert",
  },
  {
    question:
      "Trong soạn thảo văn bản với Microsoft Word, muốn trình bày văn bản dạng cột (dạng thường thấy trên các trang báo và tạp chí), người dùng chọn thẻ nào sau đây?",
    answer: "Page Layout",
  },
  {
    question:
      'Người dùng gõ dòng chữ "Cộng hòa xã hội chủ nghĩa Việt Nam" bằng font chữ Times New Roman, Unicode. Sau đó muốn chuyển sang font .VN times mà các chữ đó vẫn đọc được bình thường thì dùng cách nào?',
    answer:
      "Người dùng cần sử dụng một phần mềm cho phép thực hiện điều này, ví dụ như Vietkey Office hoặc Unikey",
  },
  {
    question:
      "Người dùng đang gõ văn bản và dưới chân những ký tự đang gõ xuất hiện các dấu xanh đỏ. Điều đó có ý nghĩa gì?",
    answer:
      "Dấu xanh là do bạn gõ sai quy tắc ngữ pháp, dấu đỏ là do bạn gõ sai chính tả",
  },
  {
    question:
      "Để chọn một dòng trong một bảng biểu, người dùng cần phải làm gì?",
    answer: "Nhấn chuột vào phía ngoài bên trái của dòng đó",
  },
  {
    question:
      "Trong soạn thảo với Microsoft Word, tổ hợp phím Ctrl - H có tác dụng gì?",
    answer: "Chức năng thay thế trong soạn thảo",
  },
  {
    question:
      "Trong Microsoft Word, tổ hợp phím nào cho phép ngay lập tức đưa con trỏ về đầu dòng văn bản?",
    answer: "Ctrl+Home",
  },
  {
    question: "Lựa chọn các phát biểu sai:",
    answer: "Ctrl + Shift + U: bật hoặc tắt nét gạch đơn dưới chữ",
  },
  {
    question:
      "Trong soạn thảo với Microsoft Word, muốn chèn các kí tự đặc biệt vào văn bản, người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Symbol",
  },
  {
    question:
      "Trong soạn thảo với Microsoft Word, muốn chèn các kí hiệu toán học vào văn bản, người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Equation",
  },
  {
    question:
      "Để có thể đánh được chỉ số dưới, ví dụ như hình minh họa người dùng cần phải làm như thế nào?",
    answer: "Bôi đen số 2, nhấn tổ hợp phím (Ctrl = )",
  },
  {
    question:
      "Trong khi soạn thảo văn bản, nếu kết thúc 1 đoạn (Paragraph) và muốn sang 1 đoạn mới, người dùng sử dụng lựa chọn nào sau đây?",
    answer: "Nhấn phím Enter",
  },
  {
    question:
      "Nút Format Painter có hình chổi quét trên thanh công cụ Home người dùng có chức năng gì?",
    answer: "Sao chép định dạng",
  },
  {
    question:
      "Để làm ẩn các ký tự đặc biệt như hình minh hoạ, người dùng sử dụng biểu tượng nào sau đây?",
    answer: "Biểu tượng ¶ (Paragraph marks)",
  },
  {
    question:
      "Muốn chuyển toàn bộ văn bản thành chữ in hoa thì sử dụng biểu tượng nào?",
    answer: "Chọn biểu tượng 'Change Case' và chọn UPPERCASE",
  },
  {
    question:
      "Muốn chuyển toàn bộ văn bản thành chữ in thường thì sử dụng biểu tượng nào?",
    answer: "Chọn biểu tượng 'Change Case' và chọn lowercase",
  },
  {
    question:
      "Muốn chuyển các chữ cái đầu mỗi câu trong văn bản thành chữ hoa thì sử dụng biểu tượng nào?",
    answer: "Chọn biểu tượng 'Change Case' và chọn Capitalize Each Word",
  },
  {
    question:
      "Muốn chèn tiêu đề đầu mỗi trang người dùng sử dụng lựa chọn nào sau đây?",
    answer: "Insert\\Header",
  },
  {
    question:
      "Muốn chèn tiêu đề cuối mỗi trang người dùng sử dụng lựa chọn nào sau đây?",
    answer: "Insert\\Footer",
  },
  {
    question:
      "Để dãn khoảng cách giữa các dòng cho một đoạn văn bản, trước khi chọn hộp thoại Paragraph người dùng phải làm gì?",
    answer: "Chọn đoạn văn bản",
  },
  {
    question:
      "Để chọn một câu trong văn bản người dùng lựa chọn thao tác nào sau đây?",
    answer: "Nhấn phím Ctrl và nhấn chuột tại một ký tự bất kỳ của câu",
  },
  {
    question:
      "Để chọn một đoạn văn bản người dùng lựa chọn thao tác nào sau đây?",
    answer: "Nhấn đúp chuột vào khoảng trống bên trái của dòng lựa chọn",
  },
  {
    question:
      "Văn bản hành chính được trình bày trên khổ giấy A4. Lề trang mặt trước được xác định như thế nào?",
    answer: "Lề trên: 20-25, Lề dưới: 20-25, Lề trái: 30-35, Lề phải: 15-20",
  },
  {
    question:
      "Để lưu văn bản dưới dạng một tệp mẫu để có thể sử dụng lại nhiều lần thì tệp đó có phần mở rộng là gì?",
    answer: "*.DOTX",
  },
  {
    question:
      "Để xóa một hàng hay một cột khỏi bảng thì lựa chọn nào là đúng sau khi đã chọn 1 dòng hoặc 1 cột?",
    answer: "Chọn Delete trên nhóm lệnh Layout",
  },
  {
    question:
      "Làm thế nào để tách 1 bảng thành 2 bảng con có số cột bằng bảng cũ và tổng số hàng bằng bảng cũ?",
    answer: "Chọn Split Table trên nhóm lệnh Layout",
  },
  {
    question:
      "Trong Microsoft Word cho phép chèn công thức toán học vào một bảng giống như trong môi trường Microsoft Excel?",
    answer:
      "Trong Microsoft Word cho phép chèn công thức toán học vào một bảng giống như trong môi trường Microsoft Excel",
  },
  {
    question:
      "Muốn chuyển đổi giữa hai chế độ gõ: chế độ gõ chèn và chế độ gõ đè; người dùng bấm phím gì?",
    answer: "Insert",
  },
  {
    question:
      "Muốn chuyển dữ liệu từ dạng bảng sang văn bản sau khi đã chọn bảng, người dùng chọn thẻ nào sau đây?",
    answer: "Layout",
  },
  {
    question:
      "Lựa chọn vùng nào để thay đổi màu sắc, kích cỡ các đường viền của bảng trong Microsoft Word?",
    answer: "Nhóm lệnh Design",
  },
  {
    question:
      "Muốn thay đổi danh sách đang được bôi đen thành danh sách đánh số thứ tự, nhấn vào menu nào?",
    answer: "Home",
  },
  {
    question: "Để làm ẩn các ký tự đặc biệt trong văn bản, lựa chọn đúng là?",
    answer: "Trong Word Options\\Display huỷ bỏ việc chọn mục Paragraph marks",
  },
  {
    question:
      "Chức năng Mirror margins trong Page setup\\Margins dùng để làm gì?",
    answer: "In tài liệu theo mặt đối xứng của giấy",
  },
  {
    question:
      "Khi bạn muốn in hai mặt của một tờ giấy, bạn sử dụng lựa chọn nào sau đây?",
    answer: "Mirror margins",
  },
  {
    question:
      "Muốn trình bày văn bản trong khổ giấy theo hướng ngang người dùng chọn mục nào?",
    answer: "Landscape",
  },
  {
    question:
      "Để chèn ngắt trang trong Microsoft Word người dùng chọn thẻ nào sau đây?",
    answer: "Insert",
  },
  {
    question:
      "Muốn xem các trang khác nhau của một tài liệu trên một màn hình, người dùng chọn thẻ nào?",
    answer: "View",
  },
  {
    question: "Phát biểu nào dưới đây là sai?",
    answer: "Nhấn Ctrl+P tương đương với nhấn nút Print trên nhóm lệnh Home",
  },
  {
    question:
      "Muốn sao chép định dạng của một dòng văn bản nào đó, người dùng kéo chọn dòng đó và lựa chọn lệnh nào sau đây?",
    answer: "Format Painter (biểu tượng hình chổi quét)",
  },
  {
    question:
      "Để định dạng đường viền cho một bảng thì thực hiện trên nhóm lệnh nào?",
    answer: "Design",
  },
  {
    question:
      "Trên hình vẽ, muốn thay đổi danh sách đang được bôi đen thành danh sách đánh số thứ tự, nhấn vào menu nào để có thể truy xuất đến chức năng mong muốn?",
    answer: "Home",
  },
  {
    question:
      "Khi soạn thảo văn bản có dạng như hình minh hoạ, để làm ẩn các ký tự đặc biệt, lựa chọn đúng là:",
    answer: "Trong Word Options\\Display huỷ bỏ việc chọn mục Paragraph marks",
  },
  {
    question:
      "Chức năng Mirror margins trong Page setup\\Margins dùng để làm gì?",
    answer: "In tài liệu theo mặt đối xứng của giấy",
  },
  {
    question:
      "Khi bạn muốn in hai mặt của một tờ giấy, bạn sử dụng lựa chọn nào sau đây?",
    answer: "Mirror margins",
  },
  {
    question:
      "Trong soạn thảo Microsoft Word, muốn trình bày văn bản trong khổ giấy theo hướng ngang người dùng chọn mục nào sau đây?",
    answer: "Landscape",
  },
  {
    question:
      "Để chèn ngắt trang trong Microsoft Word người dùng chọn thẻ nào sau đây?",
    answer: "Insert",
  },
  {
    question:
      "Muốn xem các trang khác nhau của một tài liệu trên một màn hình, người dùng chọn các thẻ nào?",
    answer: "View",
  },
  {
    question:
      "Trong Microsoft Word hỗ trợ sao lưu văn bản đang soạn thành các định dạng nào?",
    answer: "*.docx, *.dotx, *.htm, *.txt",
  },
  {
    question:
      "Khi soạn thảo văn bản trong Microsoft Word, muốn di chuyển từ 1 ô này sang ô kế tiếp về bên phải của một bảng (Table) người dùng bấm phím gì?",
    answer: "Tab",
  },
  {
    question:
      "Theo hình minh hoạ, bạn muốn làm cho dãy chữ cái các dòng đang chọn được đánh lại bắt đầu từ chữ cái a người dùng chọn mục số mấy?",
    answer: "Số 2",
  },
  {
    question:
      "Muốn thực hiện cắt bớt các vùng trắng xung quanh một bức ảnh trong Microsoft Word người dùng chọn thẻ nào sau đây?",
    answer: "Format",
  },
  {
    question:
      "Muốn thực hiện chèn một hình ảnh có sẵn trong máy tính vào văn bản người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Picture",
  },
  {
    question:
      "Muốn thực hiện chèn một biểu tượng có sẵn trong Office vào văn bản người dùng sử dụng tùy chọn nào sau đây?",
    answer: "ClipArt",
  },
  {
    question:
      "Muốn thực hiện chèn một hình tròn vào văn bản người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Shapes",
  },
  {
    question:
      "Muốn thực hiện chèn một biểu đồ vào văn bản người dùng sử dụng tùy chọn nào sau đây?",
    answer: "Chart",
  },
  {
    question:
      "Muốn chèn chữ nghệ thuật (WordArt) vào văn bản người dùng sử dụng nhóm lệnh nào trong thẻ Insert?",
    answer: "Text",
  },
  {
    question:
      "Muốn chèn một công thức toán học vào văn bản người dùng sử dụng nhóm lệnh nào trong thẻ Insert?",
    answer: "Symbols",
  },
  {
    question: "Lựa chọn phát biểu sai trong các phát biểu sau:",
    answer:
      "Trong Microsoft Word không cho phép kiểm tra và thay thế các lỗi chính tả",
  },
  {
    question:
      "Muốn đánh chỉ mục các đoạn văn bản, người dùng sử lựa chọn nhóm thẻ nào sau đây?",
    answer: "Home",
  },
  {
    question:
      "Trong một văn bản có 2 trang khổ A4, yêu cầu trang 1 đặt khổ giấy A4, trang 2 khổ A3. Vậy người dùng phải thao tác như thế nào?",
    answer:
      "Đưa con trỏ tại đầu dòng đầu tiên của trang 2. Sau đó chọn trên nhóm lệnh Page layout\\Page setup\\Paper size\\chọn khổ giấy A3 và chọn This point Forward tại mục Apply to",
  },
  {
    question:
      "Một văn bản có 3 trang khổ A4 đang để hướng giấy dọc. Yêu cầu thay đổi trang 1,3 vẫn là hướng giấy dọc, trang 2 là hướng giấy ngang. Ngoài yêu cầu chọn nội dung tại trang 2, người dùng phải sử dụng lựa chọn nào trong mục Apply to?",
    answer: "Selected text",
  },
  {
    question:
      "Một ai đó đã cố tình xoá nội dung của một tệp đã đặt mật khẩu nhưng không thể xoá được, và xoá đến đâu thì dòng chữ được đổi màu đến đó và xuất hiện một đường liền gạch xuyên qua như hình minh hoạ. Làm thế nào để mất đường đó sau khi đã gỡ bỏ mật khẩu?",
    answer: "Trên nhóm lệnh Layout  chọn mục Accept or Reject changes...",
  },
  {
    question:
      "Cho một bảng danh sách 200 sinh viên gồm có tiêu đề TT, Họ tên, lớp...Muốn có tiêu đề các trang sau lặp lại như trang đầu tiên mà không cần cần lệnh copy tiêu đề đó, thì người dùng làm thế nào?",
    answer: "Layout\\ Repeat Header Rows",
  },
  {
    question:
      "Để có vị trí bảng như hình minh hoạ, người dùng vào đâu sau khi nhấn chuột phải và chọn Table Properties:",
    answer: "Table Properties... chọn mục Table",
  },
  {
    question:
      "Muốn chèn một ghi chú ở cuối trang người dùng lựa chọn thao tác nào sau đây?",
    answer: "Trên nhóm lệnh References/ Insert Footnote",
  },
  {
    question:
      "Muốn xây dựng mục lục của tài liệu một cách tự động, dùng nhóm lệnh nào sau đây?",
    answer: "Nhóm lệnh References",
  },
  {
    question:
      "Muốn định dạng khoảng cách giữa đoạn được chọn với đoạn trước đó, người dùng sử dụng lựa chọn nào sau đây?",
    answer: "Before",
  },
  {
    question:
      "Muốn định dạng khoảng cách giữa đoạn được chọn với đoạn sau, người dùng sử dụng lựa chọn nào sau đây?",
    answer: "After",
  },
  {
    question:
      "Muốn định dạng khoảng cách giữa các dòng văn bản trong một đoạn, người dùng sử dụng lựa chọn nào sau đây?",
    answer: "Line spacing",
  },
  {
    question:
      "Muốn định dạng khoảng cách giữa các dòng văn bản trong một đoạn là 2.5 pt, người dùng sử dụng lựa chọn nào sau đây?",
    answer: "Multiple",
  },
  {
    question:
      "Trong khi đang soạn thảo văn bản trên Word bạn vô tình nhấn vào phím Insert trên bàn phím, điều gì sẽ xảy ra?",
    answer:
      "Khi gõ các phím trên bàn phím thì văn bản tự động bị xóa các chữ cái phía bên phải (nếu có)",
  },
  {
    question:
      "Khi định dạng trang giấy trong thẻ Page Layout\\ Page Setup, có hộp thoại như sau: Cho biết Whole document có nghĩa là gì?",
    answer: "Áp dụng định dạng cho toàn bộ tài liệu",
  },
  {
    question:
      "Cho một danh sách khách mời trên file Excel, một văn bản nội dung mời trên file Word. Yêu cầu, bạn thực hiện một cách tự động công việc xuất ra giấy mời của từng khách tương ứng với danh sách đã cho. Bạn sử dụng thẻ nào sau đây?",
    answer: "Mailings",
  },
  {
    question: "Văn bản là gì?",
    answer:
      "Văn bản là phương tiện để ghi nhận những thông tin, truyền đạt các thông tin từ chủ thể này đến chủ thể khác bằng một ký hiệu hoặc bằng ngôn ngữ nhất định nào đó",
  },
  {
    question:
      "Để định dạng màu nền cho văn bản người dùng chọn thẻ nào sau đây?",
    answer: "Page Layout",
  },
  {
    question: "Thể thức văn bản là gì?",
    answer:
      "Thể thức văn bản là toàn bộ các bộ phận cấu thành văn bản, nhằm đảm bảo cho văn bản có hiệu lực pháp lý và sử dụng được thuận lợi trong quá trình hoạt động các cơ quan. Thể thức là đối tượng chủ yếu của những nghiên cứu về tiêu chuẩn hoá văn bản",
  },
  {
    question:
      "Chức năng Delete entire row ở hộp hội thoại Delete Cell bên dưới có chức năng gì?",
    answer: "Xóa dòng lựa chọn.",
  },
  {
    question:
      "Chức năng Delete entire column ở hộp hội thoại Delete Cell bên dưới có chức năng gì?",
    answer: "Xóa cột lựa chọn.",
  },
  {
    question:
      "Muốn thực hiện tách bảng dữ liệu hiện tại ra thành hai 2 bảng nhỏ, người dùng sử dụng nhóm lệnh nào trong thẻ Layout sau đây?",
    answer: "Merge",
  },
  {
    question:
      "Muốn thực hiện gộp ô dữ liệu TT, Họ và tên theo hàng, Điểm toán theo cột như hình dưới, người dùng sử dụng nhóm lệnh nào trong thẻ Layout sau đây?",
    answer: "Merge",
  },
  {
    question:
      "Để thao tác đưa con trỏ đến ô tiếp trong ô bảng biểu, người dùng phím hoặc tổ hợp phím gì?",
    answer: "Tab",
  },
  {
    question: "Hộp hội thoại bên dưới có chức năng gì?",
    answer: "Tạo bảng biểu",
  },
  {
    question: "Tổ hợp phím Ctrl + G có tác dụng gì?",
    answer: "Truy cập nhanh tới một trang văn bản",
  },
  {
    question: "Ở bảng bên dưới là bảng chức năng của hộp hội thoại nào?",
    answer: "WordArt",
  },
  {
    question:
      "Bảng chức năng của hộp hội thoại Format picture có chức năng gì?",
    answer: "Định dạng hình ảnh",
  },
  {
    question: "Bảng hội thoại Page number Format bên dưới có chức năng gì?",
    answer: "Định dạng số trang bắt đầu",
  },
  {
    question: "Biểu tượng có chức năng gì?",
    answer: "Cắt đối tượng được đánh dấu vào Clipboard",
  },
  {
    question: "Định dạng Bullets and Numbering có tác dụng gì?",
    answer: "Tạo ra các số thứ tự, ký hiệu tự động ở đầu mỗi đoạn văn bản.",
  },
  {
    question: "Biểu tượng có chức năng gì?",
    answer: "Sao chép đối tượng được đánh dấu vào Clipboard",
  },
  {
    question: "Biểu tượng có chức năng gì?",
    answer: "Dán nội dung từ Clipboard vào vị trí soạn thảo",
  },
  {
    question: "Tổ hợp phím tắt nào sử dụng để đóng tài liệu đang mở?",
    answer: "Alt + F4",
  },
  {
    question: "Tổ hợp phím tắt Ctrl + 2 có chức năng gì?",
    answer:
      "Điều chỉnh khoảng cách giữa các dòng trong cùng một đoạn là 2(Double )",
  },
  {
    question: "Tổ hợp phím tắt Ctrl + 5 có chức năng gì?",
    answer: "Điều chỉnh khoảng cách giữa các dòng trong cùng một đoạn là 1.5",
  },
  {
    question: "Tổ hợp phím tắt Ctrl + Shift + '=' có tác dụng gì?",
    answer: "Tạo chỉ số trên.",
  },
  {
    question: "Tổ hợp phím tắt Ctrl + '=' có tác dụng gì?",
    answer: "Tạo chỉ số dưới",
  },
  {
    question: "Tổ hợp phím tắt Ctrl + L có tác dụng gì?",
    answer: "Căn trái văn bản",
  },
  {
    question: "Tổ hợp phím tắt Ctrl + R có tác dụng gì?",
    answer: "Căn phải văn bản",
  },
  // Module 4
  {
    question: "Chọn các đáp án đúng phát biểu về chương trình MS-Excel?",
    answer:
      "Excel là một chương trình ứng dụng dùng để tính toán đại số, phân tích dữ liệu; Excel là một chương trình ứng dụng dùng để truy cập các nguồn dữ liệu khác nhau; Thế mạnh của phần mềm Excel là vẽ đồ thị và các sơ đồ",
  },
  {
    question: "Cửa sổ MS-Excel thuộc loại nào?",
    answer: "Cửa sổ ứng dụng",
  },
  {
    question: "Một bảng tính MS-Excel gồm bao nhiêu cột và dòng?",
    answer: "16384 cột, 1048576 dòng",
  },
  {
    question:
      "Một Workbook mặc định thường có 3 Sheet, muốn thay đổi số Sheet đó người dùng lựa chọn cách nào sau đây?",
    answer: "File \\Excel Options\\ General",
  },
  {
    question:
      "Trong bảng tính MS-Excel, giao của một hàng và một cột được gọi là gì?",
    answer: "Ô",
  },
  {
    question: "Thanh tiêu đề trong MS-Excel có tính năng gì?",
    answer: "Cho biết tên chương trình ứng dụng, tên tệp tin",
  },
  {
    question:
      "Thanh truy cập nhanh Quick Access Toolbar mặc định có 3 công cụ có sẵn, đó là?",
    answer: "Save, Undo, Redo",
  },
  {
    question: "Trong MS-Excel có các chế độ làm việc theo thứ tự nào sau đây?",
    answer: "Ready - Enter - Edit – Point",
  },
  {
    question:
      "Để khởi động chương trình MS-Excel, người dùng thực hiện cách nào sau đây?",
    answer:
      "Nhấn nút Start, Chọn Programs, chọn Microsoft Office, chọn Microsoft Excel.",
  },
  {
    question:
      "Trong MS-Excel, để mở một bảng tính đã có, người dùng thực hiện cách nào sau đây?",
    answer: "Nhấn tổ hợp phím Ctrl + O; Vào menu File chọn Open",
  },
  {
    question:
      "Muốn chọn nhiều tệp tin không kề nhau để mở các file đó trong MS-Excel, người dùng thực hiện cách nào sau đây?",
    answer:
      "Chọn tệp tin đầu tiên muốn mở, giữ phím Ctrl sau đó nhấn chuột vào các tệp tin khác",
  },
  {
    question:
      "Để che giấu/ hiển thị thanh Ribbon trong MS-Excel, người dùng lựa chọn cách nào sau đây?",
    answer:
      "Nhấn chuột phải vào vùng trống trên Ribbon và chọn Minimize the Ribbon",
  },
  {
    question:
      "Để lưu bảng tính vào bộ nhớ ngoài, người dùng lựa chọn cách nào sau đây?",
    answer: "Tất cả đều đúng",
  },
  {
    question:
      "Để lưu bảng tính theo đường dẫn mặc định, người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn File → Excel Option → Save → Browser",
  },
  {
    question:
      "Sử dụng chức năng trợ giúp trong MS-Excel, người dùng nhấn phím gì?",
    answer: "F1",
  },
  {
    question:
      "Để chuyển trạng thái hiện hành giữa các bảng tính trong MS-Excel, người dùng lựa chọn cách nào sau đây?",
    answer:
      "Mở thực đơn lệnh View chọn biểu tượng Switch Windows, và nhấn chọn tên bảng tính",
  },
  {
    question:
      "Để phóng to, thu nhỏ bảng tính người dùng lựa chọn thao tác sau đây?",
    answer:
      "Vào View → chọn Zoom; Kích chọn vào thanh trạng thái góc phải dưới màn hình, chọn Zoom In hoặc Zoom Out",
  },
  {
    question:
      "Để thu gọn bảng tính chỉ bằng một thao tác duy nhất, người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn chuột vào nút Minimize",
  },
  {
    question:
      "Tập tin khuôn mẫu (Template) trong Excel, có định dạng đuôi là gì?",
    answer: ".xltx",
  },
  {
    question:
      "Trong khi làm việc với MS-Excel, muốn lưu bảng tính hiện thời vào đĩa, người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn File chọn Save",
  },
  {
    question:
      "Để đổi tên một sheet đang tồn tại bên trong MS-Excel, người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn chuột phải vào vị trí tên sheet, chọn Rename",
  },
  {
    question:
      "Trong MS-Excel, để đóng một bảng tính, người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn nút File chọn Close",
  },
  {
    question:
      "Để cố định dòng tiêu đề 1 và cột tiêu đề 1 khi cuộn màn hình như hình minh họa, người dùng đặt con trỏ tại ô nào dưới đây?",
    answer: "Ô B2",
  },
  {
    question:
      "Trong các địa chỉ sau đây, địa chỉ nào là địa chỉ tuyệt đối (theo cả hàng và cột)?",
    answer: "$B$1:$D$10",
  },
  {
    question: "Trong MS-Excel, địa chỉ tuyệt đối là gì?",
    answer: "Không thay đổi tọa độ khi sao chép công thức.",
  },
  {
    question:
      "Để thay đổi qua lại giữa các loại địa chỉ tương đối, tuyệt đối người dùng sử dụng phím nào?",
    answer: "F4",
  },
  {
    question:
      "Khi đang làm việc với MS-Excel, người dùng có thể di chuyển từ sheet này sang sheet khác bằng cách sử dụng các phím hoặc các tổ hợp phím nào?",
    answer: "Ctrl + Page Up, Ctrl+ Page Down",
  },
  {
    question:
      "Để chuyển đổi giữa các bảng tính đang mở, người dùng sử dụng tổ hợp phím nào?",
    answer: "Alt + Tab",
  },
  {
    question:
      "Phím nào trên bàn phím cho phép người dùng di chuyển con trỏ chuột từ trường này sang trường khác?",
    answer: "Tab",
  },
  {
    question:
      "Trong bảng tính MS-Excel, để sửa dữ liệu trong một ô tính mà không cần nhập lại, người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn chuột chọn ô tính cần sửa, rồi nhấn phím F2",
  },
  {
    question: "Để lấy lại dữ liệu thao tác vừa làm người dùng nhấn chọn gì?",
    answer: "Ctrl+Z; Nhấn vào biểu tượng nút Undo",
  },
  {
    question: "Để hủy bỏ thao tác vừa làm người dùng nhấn chọn gì?",
    answer: "Nhấn vào biểu tượng nút Redo",
  },
  {
    question: "Trong MS-Excel phím tắt CTRL + G có chức năng gì?",
    answer: "Nhảy tới một ô",
  },
  {
    question:
      "Để thực hiện chức năng tìm kiếm một ô trong MS-Excel người dùng nhấn chọn tổ hợp phím nào?",
    answer: "Ctrl+F",
  },
  {
    question:
      "Để sắp xếp cơ sở dữ liệu đang chọn thì sử dụng lệnh nào sau đây?",
    answer: "Data Sort",
  },
  {
    question:
      "Khi sử dụng hàm trong MS-Excel để tính toán, muốn sao chép kết quả tới vị trí khác người dùng lựa chọn cách nào sau đây?",
    answer: "Sao chép dữ liệu với những thông số ấn định (Paste special)",
  },
  {
    question: "Đặc trưng và ứng dụng của phần mềm MS-Excel là gì?",
    answer:
      "Thực hiện được nhiều phép tính từ đơn giản đến phức tạp; Tổ chức và lưu trữ thông tin dưới dạng bảng như bảng lương, bảng kế toán, bảng thanh toán, bảng thống kê, bảng dự toán ...",
  },
  {
    question:
      "Để thực hiện sao chép dữ liệu các ô trên cùng Sheet, người dùng thực hiện như thế nào?",
    answer:
      "Chọn ô cần sao chép, nhấn Ctrl + C, di chuyển đến ô cần dán, nhấn Ctrl +V; Chọn ô cần sao chép, nhấn chuột phải chọn Copy,  di chuyển đến ô cần dán, nhấn Paste",
  },
  {
    question:
      "Để thực hiện xóa dữ liệu trên các ô trên cùng Sheet, người dùng làm thế nào?",
    answer: "Chọn các ô cần xóa, nhấn chuột phải, chọn Delete Cell",
  },
  {
    question: "Chọn phát biểu sai:",
    answer: "Không thể điền tự động trong MS-Excel.",
  },
  {
    question:
      "Sau khi nhập liệu và lựa chọn vùng dữ liệu. Muốn điền tự động theo xu thế cấp số nhân, người dùng sẽ lựa chọn cách nào sau đây?",
    answer:
      "Nhấn và giữ chuột phải ở góc phải dưới vùng dữ liệu, kéo đến vị trí mong muốn rồi chọn Growth Trend",
  },
  {
    question:
      "Trong bảng tính Excel, tại ô A2 có sẵn dãy kí tự '1DHCNDN2'. Nếu sử dụng nút điền để điền dữ liệu đến các cột B2, C2, D2, E2; thì kết quả nhận được tại ô E2 là:",
    answer: "1DHCNDN6",
  },
  {
    question:
      "Để chọn một dãy các dòng, hoặc các cột liền kề nhau trong MS-Excel người dùng lựa chọn cách nào sau đây?",
    answer:
      "Nhấn Shift, và nhấn chọn các dòng hoặc cột đó; Nhấn Shift và phím mũi tên di chuyển",
  },
  {
    question:
      "Để chọn một dãy các dòng, hoặc các cột không liền kề nhau trong MS-Excel người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn Ctrl và nhấn chọn các dòng hoặc cột đó",
  },
  {
    question:
      "Để hiện một dòng, một cột trong MS-Excel người dùng chọn thao tác nào?",
    answer: "Chọn dòng/ cột đó, phải chuột chọn UnHide",
  },
  {
    question:
      "Muốn xoá một hàng trong MS-Excel, người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn cả hàng, nhấn chuột phải, chọn Delete",
  },
  {
    question:
      "Để chèn thêm một dòng vào bảng tính người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn một hàng, nhấn chuột phải, chọn Insert",
  },
  {
    question:
      "Để chèn thêm một cột vào bảng tính người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn một cột, nhấn chuột phải chọn Insert",
  },
  {
    question:
      "Trong MS-Excel, để xoá một hàng và dồn dữ liệu hàng dưới lên, người dùng chọn hàng cần xóa và lệnh nào sau đây?",
    answer: "Home, Delete..., Shift Cell Up",
  },
  {
    question:
      "Để thay đổi độ rộng một cột trong bảng tính MS-Excel, người dùng lựa chọn cách nào sau đây?",
    answer: "Home - Format – Column Width",
  },
  {
    question:
      "Để ẩn một dòng, một cột trong bảng tính Excel, người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn dòng/ cột đó, nhấn chuột phải, chọn Hide",
  },
  {
    question:
      "Để gỡ bỏ việc cố định tiêu đề, người dùng lựa chọn cách nào sau đây?",
    answer: "Chọn lệnh Unfreeze Panes trong thực đơn lệnh View",
  },
  {
    question:
      "Muốn chèn thêm một bảng tính, người dùng lựa chọn cách nào sau đây?",
    answer: "Nhấn tổ hợp phím Shift+ F11",
  },
  {
    question:
      "Để lưu tên mới một tệp MS-Excel, người dùng lựa chọn cách nào sau đây?",
    answer: "Vào menu File /Save As",
  },
  {
    question: "Để đổ màu cho sheet tab người dùng chọn thao tác nào sau đây?",
    answer:
      "Nhấn chuột phải vào sheet đó, chọn Tab Color; Nhấn chọn sheet đó, vào Home –> Format –> Tab Color",
  },
  {
    question:
      "Muốn sao chép Sheet từ file Excel này file Excel khác người dùng thực hiện thế nào sau đây?",
    answer:
      "Nhấn chọn Sheet đó, nhấn chuột phải chọn Move Or Copy; Nhấn chọn Sheet đó, vào Home –> Format –> Move Or Copy",
  },
  {
    question: "Các toán tử thường được sử dụng trong MS-Excel là gì?",
    answer: "Tất cả đều đúng",
  },
  {
    question:
      "Trong bảng tính MS-Excel, điều kiện trong hàm IF được phát biểu dưới dạng một phép so sánh. Khi cần so sánh khác nhau thì sử dụng kí hiệu nào?",
    answer: "<>",
  },
  {
    question: "Khi thao tác với bảng tính MS-Excel, xuất hiện ##### là do gì?",
    answer: "Độ rộng của cột không đủ để hiển thị dữ liệu",
  },
  {
    question:
      "Khi thao tác với bảng tính MS-Excel, xuất hiện ##### muốn sửa lỗi này người dùng lựa chọn cách nào sau đây?",
    answer: "Chỉnh độ rộng của cột chứa lỗi đó lớn hơn",
  },
  {
    question:
      "Khi thao tác với bảng tính MS-Excel, xuất hiện #VALUE! là do gì?",
    answer: "Tất cả đều đúng",
  },
  {
    question:
      "Trong bảng tính MS-Excel, tại ô A2 có sẵn giá trị số không (0); Tại ô B2 gõ vào công thức =5/A2 thì nhận được kết quả là gì?",
    answer: "#DIV/0!",
  },
  {
    question:
      "Trong MS-Excel, khi viết sai tên hàm trong tính toán, chương trình thông báo lỗi gì?",
    answer: "#NAME!",
  },
  {
    question:
      "Trong quá trình thao tác với bảng tính trong MS-Excel, người dùng gặp phải lỗi #N/A ! là do gì?",
    answer: "Không có dữ liệu để tham chiếu",
  },
  {
    question:
      "Trong quá trình thực hiện tính toán, xuất hiện lỗi #NUM! là do gì?",
    answer: "Sử dụng dữ liệu không đúng kiểu số",
  },
  {
    question: "Trong MS-Excel, một hàm thường bắt đầu bằng gì?",
    answer: "Dấu =",
  },
  {
    question:
      "Để chèn một hàm vào một ô trong bảng tính người dùng lựa chọn cách nào sau đây?",
    answer: "Formular\\Insert Function\\chọn tên hàm cần sử dụng",
  },
  {
    question:
      "Trong khi nhập dữ liệu trong MS-Excel, khi người dùng chọn vùng số liệu vừa nhập vào, các kết quả tự động hiển thị trên thanh trạng thái được gọi là gì?",
    answer: "Tính toán nhanh AutoCalculate",
  },
  {
    question: "Trong MS-Excel, người dùng sử dụng tên vùng để làm gì?",
    answer:
      "Dễ dàng gợi nhớ mỗi khi khai báo phạm vi cho toạ độ các ô, khối, công thức trong các lệnh",
  },
  {
    question:
      "Trong MS-Excel để tính khoảng thời gian giữa 2 ngày người dùng thực hiện công thức nào sau đây. Biết rằng: A3=18/03/2016, B3=25/04/2017",
    answer: "=B3-A3",
  },
  {
    question:
      "Cách nào sau đây là đúng khi chỉ lấy ngày hệ thống từ máy tính vào một ô trong bảng tính MS-Excel",
    answer: "CTRL+;, Sử dụng hàm today()",
  },
  {
    question:
      "Tại ô C5 chứa giá trị 21/05/2016. Tại ô C6, nhập hàm Day(C5) sẽ cho kết quả là gì?",
    answer: "21",
  },
  {
    question:
      "Tại ô B6 chứa giá trị 24- Dec-16. Tại D6 nhập hàm Day(B6) sẽ trả ra kết quả là gì?",
    answer: "24",
  },
  {
    question:
      "Tại ô G15 chứa giá trị 13/08/2016. Tại ô H15 nhập hàm month(G15) trả ra kết quả là gì?",
    answer: "13",
  },
  {
    question:
      "Tại ô G15 chứa giá trị 08-19-2016. Tại ô H15 nhập hàm Year(G15) trả ra kết quả là gì?",
    answer: "2016",
  },
  {
    question:
      "Tại ô H5 có: =Days360(15/08/2016,01/08/2016) sẽ cho kết quả tại ô H5 là gì?",
    answer: "Kết quả khác",
  },
  {
    question:
      "Tại H5 chứa giá trị 08/15/2016. Tại G5 chứa 08/01/2016, tại F6 gõ vào G5-H5 cho kết quả là:",
    answer: "-14",
  },
  {
    question:
      "Muốn hiển thị được ngày, giờ của hệ thống lên một ô trong Excel người dùng sử dụng hàm gì? Ví dụ(8/15/2016 23:16)",
    answer: "=Now()",
  },
  {
    question: "Hàm Days360() dùng để làm gì?",
    answer: "Tính khoảng cách ngày giữa hai ô trong Excel",
  },
  {
    question:
      "Hàm Days360() để tính khoảng thời gian giữa hai khoảng thời gian nào?",
    answer: "Ngày bắt đầu và ngày kết thúc",
  },
  {
    question:
      "Tại ô H5 chứa giá trị 15/08/2016. Tại ô G5 nhập hàm =day(H5) cho kết quả: #VALUE!. Lỗi là do;",
    answer:
      "Giá trị tại ô G5 hiển thị sai định dạng quy định ngày tháng mà hệ thống quy định",
  },
  {
    question: "Hàm Sum() dùng để tính làm gì ?",
    answer:
      "Tổng các giá trị kiểu số trong một khối, các giá trị không phải kiểu số tính bằng không.",
  },
  {
    question:
      "Khi nhập hàm Sum() tại ô C7. Kết thúc việc nhập công thức, kết quả tính tổng không hiển thị mà chỉ hiển thị dữ liệu là hàm bạn nhập vào như tại ô C7 là do gì?",
    answer: "Bảng tính đang ở chế độ Show Formulas",
  },
  {
    question: "Hàm AVERAGE() dùng để làm gì?",
    answer:
      "Tính trung bình cộng các giá trị kiểu số trong một khối, ô trống tính bằng 0",
  },
  {
    question: "Tính trung bình cộng tại ô F3, kết quả trả ra là gì ?",
    answer: "8.333333334",
  },
  {
    question:
      "Công thức tính điểm trung bình tại ô H2, biết môn toán hệ số 2, môn tin hệ số 3?",
    answer: "=(F2*2+G2*3)/5",
  },
  {
    question:
      "Trong ô C4 chứa công thức: =MAX(47,5,4,64,13,56). Kết quả là gì?",
    answer: "64",
  },
  {
    question: "Tại ô A2 gõ vào công thức =MAX(30,10,65,5), kết quả là gì?",
    answer: "65",
  },
  {
    question: "Biểu thức =Min(2,3,7,-9,e) trả lại kết quả là bao nhiêu?",
    answer: "#Name?",
  },
  {
    question: "Hàm nào sai trong các hàm sau?",
    answer: "=INT(số 1, số 2): hàm cho kết quả là phần nguyên của phép chia",
  },
  {
    question: "Tại ô G2 có giá trị số 81; tại ô H2 gõ =SQRT(G2), kết quả là?",
    answer: "9",
  },
  {
    question: "Ô A2 = 10; ô B2 = 3. Tại ô C2 gõ =MOD(A2,B2), kết quả là?",
    answer: "1",
  },
  {
    question:
      "Ô A1=4, B1=36, C1=6. Nhập D1 công thức: =IF(AND(MOD(B1,A1)=0,MOD(B1,C1)=0),INT(B1/A1),IF(A1>C1,A1,C1))",
    answer: "9",
  },
  {
    question:
      "Ô A1:A3 lần lượt 234, 235, 236. Tại A4: =ROUND(SUM(A1:A3),-1), kết quả là?",
    answer: "710",
  },
  { question: "Hàm =ROUND(123456.789,-3) cho kết quả là?", answer: "123000" },
  {
    question: "Công thức =Round(24/5) trong Excel, kết quả là?",
    answer: "Thông báo lỗi",
  },
  { question: "Kết quả của =INT(1257.879) là gì?", answer: "1257" },
  {
    question: "ABS(3)+SQRT(9)-INT(81,13)+AVERAGE(5;6) kết quả là gì?",
    answer: "-69.5",
  },
  {
    question: 'LEFT("Đại Học Công Nghệ Đồng Nai", 7) sẽ trả về là gì?',
    answer: "Đại học",
  },
  { question: 'Công thức =RIGHT("OFFICE2013",4) trả về gì?', answer: "2013" },
  {
    question: 'Ô A2 chứa "Microsoft Excel". Công thức nào tách chuỗi "soft"?',
    answer: "MID(A2,6,4)",
  },
  { question: "Ô A2 = 2016. Tại ô B2 gõ =LEN(A2), kết quả là?", answer: "6" },
  {
    question: 'Ô A2 = "Tin hoc van phong IC3 GS4"; B2 =LOWER(A2), kết quả là?',
    answer: "tin hoc van phong ic3 gs4",
  },
  {
    question: 'Ô A2 = "Tin hoc van phong"; B2 =UPPER(A2), kết quả là?',
    answer: "TIN HOC VAN PHONG",
  },
  {
    question: 'Ô A2 = "Tin hoc van phong"; B2 =PROPER(A2), kết quả là?',
    answer: "Tin Hoc Van Phong",
  },
  {
    question: "Muốn chuyển ký tự số thành số dùng hàm nào?",
    answer: "Value()",
  },
  {
    question: 'Ô A1=7, B1="ABC". Hàm =AND(A1>5,B1="ABC") cho kết quả?',
    answer: "TRUE",
  },
  { question: "Trong Excel, các hàm AND, OR, NOT là gì?", answer: "Hàm Logic" },
  {
    question: 'Ô A1=5, B1="ABC". Hàm =AND(A1>5,B1="ABC") cho kết quả?',
    answer: "FALSE",
  },
  {
    question: "Phép toán logic trong Excel luôn cho kết quả là?",
    answer: "True hoặc False",
  },
  {
    question: "Công thức sai cú pháp là?",
    answer: "=IF(OR(1>2, “Dung”), “Dung”, “Sai”)",
  },
  { question: "Kết quả của công thức: =OR(2>3,4<1) là?", answer: "False" },
  {
    question:
      "Điểm TB = 6.5, công thức: = IF(ĐTB<5,”YẾU”,IF(ĐTB<6.5,”TB”,IF(ĐTB<8,”KHÁ”,”GIỎI”))). Kết quả là?",
    answer: "KHÁ",
  },
  { question: 'Công thức =if(2>3,"Sai") cho kết quả là?', answer: "False" },
  {
    question:
      'Công thức =IF(LEFT(B4,2)="Ca","Cafe",IF(LEFT(B4,2)="Ba","Bap","Tra")) với B4="Ca04" cho kết quả là?',
    answer: "Cafe",
  },
  {
    question: 'Điểm >=5 thì "Đạt", ngược lại "Không đạt". Công thức đúng?',
    answer: '=IF(G6>=5,"Đạt","Không đạt")',
  },
  {
    question: "Công thức =IF(3>5,100,IF(5<6,200,300)) cho kết quả là?",
    answer: "200",
  },
  {
    question:
      "Kết quả trả về tại cột Xếp loại: Đạt nếu ĐTB HK1 >= 5.0, nếu không thì Không Đạt",
    answer:
      "Đạt nếu Điểm TB HK1 lớn hơn hoặc bằng 5.0, nếu không thì Không Đạt",
  },
  {
    question: "Công thức =IF(3>5,100,IF(5>6,200,300)) cho kết quả là?",
    answer: "300",
  },
  {
    question:
      "A1=4, B1=36, C1=6. Công thức: =IF(AND(MOD(B1,A1)<>0,MOD(B1,C1)=0),INT(B1/A1),IF(A1>C1,A1,C1)) cho kết quả?",
    answer: "6",
  },
  {
    question:
      "Tại ô H5 chứa giá trị 15/08/2016. Tại ô G5 nhập hàm =day(H5) cho kết quả: #VALUE!. Lỗi là do;",
    answer:
      "Giá trị tại ô G5 hiển thị sai định dạng quy định ngày tháng mà hệ thống quy định",
  },
  {
    question: "Hàm Sum() dùng để tính làm gì ?",
    answer:
      "Tổng các giá trị kiểu số trong một khối, các giá trị không phải kiểu số tính bằng không.",
  },
  {
    question:
      "Khi nhập hàm Sum() tại ô C7 (như hình vẽ). Kết thúc việc nhập công thức, kết quả tính tổng không hiển thị kết quả mà chỉ hiển thị dữ liệu là hàm mà bạn nhập vào như  tại ô C7 là do gì?",
    answer: "Bảng tính đang ở chế độ Show Formulas",
  },
  {
    question: "Hàm AVERAGE() dùng để làm gì?",
    answer:
      "Tính trung bình cộng các giá trị kiểu số trong một khối, ô trống tính bằng 0",
  },
  {
    question: "Tính trung bình cộng tại ô F3, kết quả trả ra là gì ?",
    answer: "8.333333334",
  },
  {
    question:
      "Dựa vào bảng dữ liệu trên, hãy điền công thức tính điểm trung bình cho từng sv tại ô  H2. Biết môn toán tính hệ số 2, môn tin hệ số 3",
    answer: "=(F2*2+G2*3)/5",
  },
  {
    question:
      "Trong ô C4 chứa công thức: =MAX(47,5,4,64,13,56). Kết quả là gì?",
    answer: "64",
  },
  {
    question:
      "Trong bảng tính Excel, tại ô A2 gõ vào công thức =MAX(30,10,65,5) thì nhận được kết quả tại ô A2 là gì?",
    answer: "65",
  },
  {
    question: "Biểu thức sau trả lại kết quả là bao nhiêu?\n=Min(2,3,7,-9,e)",
    answer: "#Name?",
  },
  {
    question: "Hàm nào sai trong các hàm số sau?",
    answer: "=INT(số 1, số 2): hàm cho kết quả là phần nguyên của phép chia",
  },
  {
    question:
      "Trong bảng tính MS-Excel, tại ô G2 có sẵn giá trị số 81; Tại ô H2 gõ vào công thức =SQRT(G2) thì nhận được kết quả là gì?",
    answer: "9",
  },
  {
    question:
      "Trong MS-Excel, tại ô A2 có giá trị là số 10; ô B2 có giá trị là số 3. Tại ô C2 gõ công thức =MOD(A2,B2) thì nhận được kết quả là gì?",
    answer: "1",
  },
  {
    question:
      "Ô A1 chứa giá trị 4, B1 chứa 36, C1 chứa 6. Nhập vào D1 công thức: =IF(AND(MOD(B1,A1)=0,MOD(B1,C1)=0),INT(B1/A1),IF(A1>C1,A1,C1)).Cho biết kết quả trong ô D1 là gì?",
    answer: "9",
  },
  {
    question:
      "Trong MS-Excel, giả sử ô A1, A2, A3, có chứa lần lượt các số: 234, 235, 236, tại ô A4 ta điền công thức = ROUND(SUM(A1:A3),-1) thì kết quả là gì?",
    answer: "710",
  },
  {
    question: "Hàm =ROUND(123456.789,-3) sẽ cho kết quả là gì?",
    answer: "123000",
  },
  {
    question:
      "Khi nhập công thức =Round(24/5) trong MS-Excel, kết quả trả về là gì?",
    answer: "Thông báo lỗi",
  },
  {
    question:
      "Trong MS-Excel, kết quả của công thức =INT(1257.879) trả về là gì?",
    answer: "1257",
  },
  {
    question:
      "Kết quả của biểu thức \nABS(3)+SQRT(9)-INT(81,13)+AVERAGE(5;6) là gì?",
    answer: "-69,5",
  },
  {
    question:
      "Chọn kết quả đúng nhất: LEFT(“Đại Học Công Nghệ Đồng Nai”, 7) sẽ trả về là gì?",
    answer: "“Đại học”",
  },
  {
    question:
      "Với công thức =RIGHT(“OFFICE2013”,4) thì kết quả trả về sẽ là gì?",
    answer: "“2013” (dạng kí tự số)",
  },
  {
    question:
      "Giả sử tại ô A2 chứa chuỗi ký tự “Microsoft Excel”. Hãy cho biết công thức để tách chuỗi ký tự “soft” từ ô A2 là?",
    answer: "MID(A2,6,4)",
  },
  {
    question:
      "Trong Excel, tại ô A2 có giá trị là số 2016. Tại ô B2 gõ công thức =LEN(A2) thì nhận được kết quả ?",
    answer: "6",
  },
  {
    question:
      'Trong bảng tính Excel, tại ô A2 có sẵn dữ liệu là dãy kí tự "Tin hoc van phong IC3 GS4" ; Tại ô B2 gõ vào công thức =LOWER(A2) thì nhận được kết quả là?',
    answer: "tin hoc van phong ic3 gs4",
  },
  {
    question:
      'Trong bảng tính Excel, tại ô A2 có sẵn dữ liệu là dãy kí tự "Tin hoc van phong"; Tại ô B2 gõ vào công thức =UPPER(A2) thì nhận được kết quả là?',
    answer: "TIN HOC VAN PHONG",
  },
  {
    question:
      'Trong bảng tính Excel, tại ô A2 có sẵn dữ liệu là dãy kí tự "Tin hoc van phong"; Tại ô B2 gõ vào công thức =PROPER(A2) thì nhận được kết quả là?',
    answer: "Tin Hoc Van Phong",
  },
  {
    question:
      "Muốn chuyển ký tự số thành số người dùng sử dụng hàm nào sau đây?",
    answer: "Value()",
  },
  {
    question:
      'Ô A1 chứa giá trị số là 7, ô B1 chứa giá trị chuỗi là "ABC". Hàm =AND(A1>5,B1="ABC") sẽ cho kết quả là gì?',
    answer: "TRUE",
  },
  {
    question: "Trong Excel, các hàm AND, OR, NOT là gì?",
    answer: "Hàm Logic",
  },
  {
    question:
      'Ô A1 chứa giá trị số là 5, ô B1 chứa giá trị chuỗi là "ABC". Hàm =AND(A1>5,B1="ABC") sẽ cho kết quả là gì?',
    answer: "FALSE",
  },
  {
    question:
      "Các phép so sánh hay các phép toán Logic trong Excel bao giờ cũng cho ra kết quả là?",
    answer: "True hoặc False",
  },
  {
    question: "Công thức nào sau đây sai cú pháp:",
    answer: "=IF(OR(1>2, “Dung”), “Dung”, “Sai”)",
  },
  {
    question: "Kết quả trả về của công thức: =OR(2>3,4<1) sẽ là gì?",
    answer: "False",
  },
  {
    question:
      "Điểm trung bình (ĐTB) cuối năm  là 6.5. Nguyễn Văn A sẽ xếp loại gì nếu biết công thức xếp loại học tập như sau: = IF(ĐTB<5,”YẾU”,IF(ĐTB<6.5,”TB”,IF(ĐTB<8,”KHÁ”,”GIỎI”)))",
    answer: "KHÁ",
  },
  {
    question: "Công thức =if(2>3,”Sai”) cho kết quả là gì?",
    answer: "False",
  },
  {
    question:
      'Tại ô C4 nhập vào công thức =IF(LEFT(B4,2)="Ca","Cafe",IF(LEFT(B4,2)="Ba","Bap","Tra")) (Hình vẽ). Hãy cho biết kết quả trả ra tại ô C4 là gì? (Biết tại ô B4 Mã hàng là : Ca04)',
    answer: "Cafe",
  },
  {
    question:
      "Nếu thí sinh đạt từ 5 điểm trở lên, thí sinh đó được xếp loại Đạt, ngược lại nếu dưới 5 điểm, thì xếp loại Không đạt. Công thức nào dưới đây thể hiện đúng điều này? (Giả sử ô G6 đang chứa điểm thi)",
    answer: '=IF(G6>=5,"Đạt","Không đạt")',
  },
  {
    question:
      "Trong bảng tính Excel, tại ô A2 gõ vào công thức =IF(3>5,100,IF(5<6,200,300)) thì kết quả nhận được tại ô A2 là gì?",
    answer: "200",
  },
  {
    question:
      "Thực hiện hàm If như hình minh hoạ, kết quả trả về tại cột Xếp loại như sau:",
    answer:
      "“Đạt” nếu Điểm TB HK1 lớn hơn hoặc bằng 5.0, nếu không thì “Không Đạt”",
  },
  {
    question:
      "Trong bảng tính Excel, tại ô A2 gõ vào công thức =IF(3>5,100,IF(5>6,200,300)) thì kết quả nhận được tại ô A2 là gì?",
    answer: "300",
  },
  {
    question:
      "A1 chứa giá trị 4, B1 chứa 36, C1 chứa 6. Nhập vào D1 công thức: =IF(AND(MOD(B1,A1)<>0,MOD(B1,C1)=0),INT(B1/A1),IF(A1>C1,A1,C1)).Cho biết kết quả trong ô D1 là gì?",
    answer: "6",
  },
  {
    question: "Câu nào sau đây là không đúng ?",
    answer:
      "Excel hiển thị giá trị lỗi “######” khi nó không nhận ra văn bản nhập sai trong công thức",
  },
  {
    question:
      "Trong bảng tính Excel, hàm nào sau đây cho phép tính tổng các giá trị kiểu số thỏa mãn một điều kiện cho trước?",
    answer: "SUMIF",
  },
  {
    question:
      "Trong Excel, giả sử ô A1, A2, A3, có chứa lần lượt các số: 234, 235, 236, tại ô A4 ta điền công thức = COUNTA(A1:A3) thì kết quả là gì?",
    answer: "3",
  },
  {
    question:
      "Cho trước cột “Điểm trung bình” có địa chỉ E1:E10. Để đếm số học sinh có điểm trung bình  từ 7 trở lên thì sử dụng công thức nào sau đây:",
    answer: "=COUNTIF(E1:E10,”>=7”)",
  },
  {
    question: "Hàm Hlookup() cho phép tìm kiếm và tham chiếu theo nào?",
    answer: "Rows",
  },
  {
    question: "Trong Excel, hàm nào dùng để đếm các ô rỗng trong 1 danh sách?",
    answer: "COUNTBLANK",
  },
  {
    question:
      "Trong Excel cho biết kết quả của công thức sau: =COUNTA(C2:C4) Biết rằng: C2=18, C3=X, C4=Binh Duong, C5=6",
    answer: "4",
  },
  {
    question: "Trong Excel cú pháp hàm COUNTIF nào đúng?",
    answer: "COUNTIF(range,criteria)",
  },
  {
    question:
      "Để đếm số SV xếp loại Đạt và Không Đạt như hình minh họa, sử dụng hàm COUNTIF tại ô F14 sau đó sao chép công thức sang ô F15. Biểu diễn hàm COUNTIF nào dưới đây đáp ứng được yêu cầu trên:",
    answer: "COUNTIF($G$2:$G$10,E14)",
  },
  {
    question:
      "Trong Excel cho biết kết quả của công thức sau: =RANK(C3;C3:C6;1); Biết rằng C3=15, C4=2, C5=28,C6=9",
    answer: "2",
  },
  {
    question:
      "Cho trước một bảng dữ liệu ghi kết quả cuộc thi chạy cự ly 100m. Trong đó, cột ghi kết quả thời gian chạy của các vận động viên (tính bằng giây) có địa chỉ từ ô D2 đến ô D12. Để điền công thức xếp vị thứ cho các vận động viên (ô E2) thì dùng công thức nào?( Giả sử sắp xếp theo thứ tự giảm dần)",
    answer: "=RANK(D2,$D$2:$D$12,1)",
  },
  {
    question: "Hàm Vlookup() cho phép tìm kiếm và tham chiếu theo nào",
    answer: "Colums",
  },
  {
    question: "Trong Excel cú pháp hàm SUMIF nào là đúng?",
    answer: "SumIf(range, criteria,[sum_range])",
  },
  {
    question: "Công thức nào sau đây cho kết quả là thông báo lỗi?",
    answer: "=Left(“TAMMINH”)",
  },
  {
    question:
      "Nhập số 15 vào ô C6. Để ô C6 có giá trị là $15 người dùng lựa chọn cách nào sau đây?",
    answer:
      "Vào thực đơn Home - Number - Currency; Nhấn chuột phải tại C6, chọn  Format Cells -> Number -> Accounting; Chọn ô C6 rồi nhấn chuột vào nút $ trong nhóm Number của thẻ Home",
  },
  {
    question:
      "Để thực hiện định dạng đường viền cho bảng dữ liệu Trong hộp thoại Format Cells, chọn thẻ nào?",
    answer: "Border",
  },
  {
    question:
      "Để có thể cuộn chữ thành nhiều dòng trong ô, người dùng lựa chọn cách nào sau đây?",
    answer: "Home, chọn Alignment, chọn Wrap Text",
  },
  {
    question:
      "Muốn sao chép định dạng của bảng tính, người dùng lựa chọn cách nào sau đây?",
    answer: "Sử dụng chổi sơn định dạng trên thanh công cụ",
  },
  {
    question: "Câu nào sau đây là không đúng:",
    answer:
      "Trong một ô chỉ có thể hiển thị một hàng, không thể xuống hàng trong ô.",
  },
  {
    question:
      "Thẻ nào sau đây bạn sẽ sử dụng để nối hai ô lại với nhau, đồng thời căn lề giữa của ô nối?",
    answer: "Alignment",
  },
  {
    question:
      "Trong bảng tính Excel, thẻ Layout của nhóm Chart Tools  cho phép xác định các thông tin nào sau đây cho biểu đồ?",
    answer: "Tiêu đề; Chú giải cho các trục",
  },
  {
    question: "MS-Excel hỗ trợ vẽ những kiểu biểu đồ gì?",
    answer: "Tất cả các kiểu biểu đồ trên",
  },
  {
    question:
      "Để biểu diễn số liệu dạng phần trăm, sử dụng biểu đồ kiểu nào dưới đây là hợp lý nhất?",
    answer: "Biểu đồ dạng quạt tròn (Pie)",
  },
  {
    question: "Chọn phát biểu không đúng trong các câu sau:",
    answer: "Để tạo biểu đồ, chọn Home → Chart từ menu.",
  },
  {
    question: "Chọn phát biểu không đúng trong các câu sau:",
    answer: "Có thể thay đổi  kích thước của biểu đồ bằng vào thẻ View",
  },
  {
    question:
      "Cài đặt nào dưới đây được sử dụng cho việc điều chỉnh để in một trang tính ra Letterhead?",
    answer: "Margin",
  },
  {
    question:
      "Muốn thiết lập khổ giấy theo chiều dọc trước khi in, người dùng lựa chọn cách nào sau đây?",
    answer: "Page Layout\\ Page Setup\\ Orientation",
  },
  {
    question: "Muốn lựa chọn in một vùng người dùng lựa chọn cách nào sau đây?",
    answer: "Page Layout\\ Print Area",
  },
  {
    question:
      "Muốn căn chỉnh khổ giấy trước khi in người dùng lựa chọn cách nào sau đây?",
    answer: "PageLayout \\ Page Setup\\Margins",
  },
  {
    question:
      "Để chuẩn bị in một bảng tính Excel ra giấy? Lựa chọn nào sau đây là đúng?",
    answer: "Có thể khai báo đánh số trang in hoặc không",
  },
  // Module 5
  {
    question:
      "Thao tác nào sau đây dùng để thêm lệnh thường dùng vào  Quick Access Toolbar?",
    answer:
      "Nhấn chuột phải vào lệnh đó trên thanh Ribbon/ chọn Add to Quick Access Toolbar",
  },
  {
    question: "Chức năng Ribbon là gì?",
    answer:
      "Chức năng của Ribbon là sự kết hợp của thanh thực đơn và các thanh công cụ, được trình bày trong các ngăn (tab) chứa nút và danh sách lệnh.",
  },
  {
    question: "Để chuyển qua giữa các chế độ View ta làm thế nào?",
    answer:
      "Chọn tab View, hoặc chọn view buttons ở bên phải phía dưới của màn hình.",
  },
  {
    question:
      "Để sử dụng chế độ trình chiếu toàn màn hình, các Slide sẽ lần lượt xuất hiện theo thứ tự của chúng thì phải làm thế nào?",
    answer: "Tab View/ chọn Slide Show",
  },
  {
    question: "Người dùng làm gì để sử dụng chế độ thêm ghi chú vào Slide?",
    answer: "Tab View/ chọn Notes Page",
  },
  {
    question:
      "Để bắt đầu trình chiếu từ Slide hiện hành, người dùng nhấn phím …",
    answer: "Shift+F5",
  },
  {
    question:
      "Để gọi hộp thoại Zoom, người dùng có thể thực hiện những cách nào? (chọn 2 đáp án)",
    answer: "Chọn tab View/ Chọn Zoom, Nhấn tổ hợp phím Alt+W+Q",
  },
  {
    question:
      "Để hiển thị thanh thước ngang và dọc ta thực hiện các thao tác nào?",
    answer: "Thẻ View/ trong nhóm Show chọn Ruler",
  },
  {
    question: "Người dùng có thể tắt bớt thanh thước dọc bằng cách …",
    answer:
      "Vào File/ chọn Options/  chọn  Advance và tới mục Display bỏ chọn Show Vertical Ruler",
  },
  {
    question:
      "Trong MS-PowerPoint, để bật/tắt chức năng hiện đường lưới trên slide, người dùng cần làm gì?",
    answer: "Cả 3 cách trên đều đúng",
  },
  {
    question:
      "Để kiểm tra bài trình diễn trên màn hình ở chế độ tông màu xám, người dùng …",
    answer: "Chọn tab View trên thanh Ribbon/ chọn Greyscale",
  },
  {
    question:
      "Để kiểm tra bài trình diễn trên màn hình ở chế độ tông màu đen và trắng, người dùng …",
    answer: "Chọn tab View trên thanh Ribbon/ chọn Black and White",
  },
  {
    question:
      "Khi mở nhiều cửa sổ cùng một lúc bằng cách nhân bản hoặc do mở nhiều tập tin PowerPoint, người dùng có thể chọn chức năng sắp xếp để các cửa sổ sẽ được dàn ra trên màn hình và không bị chồng lên nhau, bằng cách …",
    answer: "Chọn thẻ View trên thanh Ribbon/ chọn Arrange All",
  },
  {
    question:
      "Khi mở nhiều cửa sổ cùng một lúc bằng cách nhân bản hoặc do mở nhiều tập tin PowerPoint, người dùng có thể chọn chức năng sắp xếp để các cửa sổ theo cách xếp chồng lên nhau, mỗi cửa sổ chỉ thấy thanh tiêu đề, bằng cách …",
    answer: "Chọn thẻ View trên thanh Ribbon/ chọn Cascade",
  },
  {
    question:
      "Để chuyển đổi qua lại giữa các cửa sổ làm việc của Power Point, người dùng …",
    answer:
      "Chọn thẻ View trên thanh Ribbon/ chọn Switch Windows / chọn tên tập tin PowerPoint cần xem.",
  },
  {
    question: "Để sử dụng chức năng trợ giúp trên Power Point, người dùng …",
    answer: "Nhấn phím F1",
  },
  {
    question:
      "Khi lưu bài trình diễn, tên của tập tin diễn có thể dài tối là bao nhiêu?",
    answer: "255 kí tự",
  },
  {
    question:
      "Để thiết lập thư mục lưu mặc định trong Power Point, người dùng …",
    answer:
      "Chọn thẻ  File/ Options/ Save/ nhập tên đường dẫn mặc định tại hộp Default file location",
  },
  {
    question: "Để kết thúc việc trình chiếu trên Power Point sử dụng phím nào?",
    answer: "ESC",
  },
  {
    question:
      "Để đặt mật khẩu tệp tin trình diễn trên Power Point, người dùng …",
    answer: "Chọn thẻ File/ Save As/ Tools/ General Options",
  },
  {
    question: "Để che dấu/ hiển thị thanh Ribbon, người dùng …",
    answer:
      "Nhấn chuột phải lên Tab bất kỳ hoặc lên vùng trống trên thanh menu và chọn Minimize the Ribbon.",
  },
  {
    question: "Để che dấu/ hiển thị thanh Ribbon, người dùng cần làm gì?",
    answer: "Giữ Ctrl và nhấn phím F1",
  },
  {
    question:
      "Khi đang làm việc với MS-PowerPoint, muốn chèn thêm một Slide mới, người dùng cần làm gì?",
    answer: "Chọn thẻ Home/ trong nhóm Slides chọn New Slide",
  },
  {
    question:
      "Khi đang làm việc với MS-PowerPoint, muốn thiết lập lại bố cục (trình bày về văn bản, hình ảnh, biểu đồ…) của Slide, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Home trên thanh Ribbon/chọn nhóm Slides/  nhấn chọn Layout",
  },
  {
    question:
      "Trong MS-PowerPoint, muốn thiết lập hiệu ứng chuyển tiếp giữa các Slide, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Transitions  trong nhóm Transition To This Slide nhấn chuột vào kí hiệu mũi tên hướng xuống để tìm đến hiệu ứng mong muốn.",
  },
  {
    question:
      "Muốn tạo một Slide Master trong PowerPoint, người dùng cần làm gì?",
    answer:
      "Chọn thẻ View trên thanh Ribbon/ chọn nhóm Master Views nhấn chọn Slide Master",
  },
  {
    question:
      "Khi làm việc với Ms PowerPoint, muốn xóa bỏ hiệu ứng trình diễn cho một đối tượng, người dùng cần làm gì?",
    answer:
      "Chọn đối tượng đó đã được thiết lập hiệu ứng (theo số thứ tự 0,1,2,…) trong hộp Custom Animation, rồi nhấn chuột phải  chọn Remove.",
  },
  {
    question:
      "Khi làm việc với MS-PowerPoint, muốn thiết lập hiệu ứng cho văn bản, hình ảnh,… người dùng cần làm gì?",
    answer:
      "Chọn văn bản, hình  ảnh đó  vào thẻ Animation trên thanh Ribbon chọn",
  },
  {
    question:
      "Khi đang làm việc với MS-PowerPoint, muốn xóa bỏ một Slide, người dùng cần làm gì?",
    answer: "Cả ba cách đều đúng",
  },
  {
    question:
      "Để chèn ClipArt vào Slide trong MS-Power Point, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Inserttrong nhóm Images  chọn ClipArt   cửa số ClipArt hiện ra, nhập từ khóa trong hộp Search for với những chủ đề gợi ý phân loại nhấn Go  Chọn một ClipArt thích hợp để chèn vào slide.",
  },
  {
    question: "Để chèn Picture vào Slide, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Inserttrong nhóm Images  nhấn chọn Pictrure Chỉ đường dẫn đến nơi chứa ảnh cần chèn và chọn ảnh thích hợp để chèn vào slide.",
  },
  {
    question: "Đề chèn âm thanh vào slide, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Insert chọn Audio tại nhóm Media  chọn đường dẫn nơi chứa tệp âm thanh  chọn 1 tệp âm thanh  nhấn OK",
  },
  {
    question: "Để chèn Video vào slide, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Insert chọn video tại nhóm Media  chọn đường dẫn nơi chứa file video  chọn file video cần chèn  nhấn OK",
  },
  {
    question: "Để chèn bảng vào slide, người dùng cần làm gì?",
    answer: "Chọn thẻ Insertchọn Table  di chuột chọn số ô cho bảng.",
  },
  {
    question: "Để chèn biểu đồ vào slide, người dùng cần làm gì?",
    answer: "Chọn thẻ Insertchọn Chart  chọn kiểu biểu đồ ưng ýchọn OK.",
  },
  {
    question:
      "Để chèn sơ đồ hình cây (SmartArt) vào slide, người dùng cần làm gì?",
    answer: "Cả ba cách trên đều đúng",
  },
  {
    question: "Để làm hình nền trong suốt cho ảnh, người dùng cần làm gì?",
    answer:
      "Chọn ảnh  chọn thẻ Format  trong nhóm Adjust chọn Remove background",
  },
  {
    question:
      "Để tạo nút nhấn giúp bài thuyết trình trở về Slide đầu tiên, ta chọn nút nào?",
    answer: "",
  },
  {
    question:
      "Để chèn một slide từ bài thuyết trình khác, người dùng cần làm gì?",
    answer:
      "Chọn thẻ Home  Nhấn mũi tên trên New Slide  chọn Reuse Slides  nhấn chọn Browse để tìm bài thuyết tình có slide người dùng muốn chèn.",
  },
  {
    question: "Để chọn chủ đề cho bài thuyết trình, người dùng cần làm gì?",
    answer:
      "Chọn tab Design  nhấn nút More mũi tên bên phải của nhóm Themes  nhấn chuột vào chủ đề ưng ý.",
  },
  {
    question:
      "Lựa chọn nào sau đây sẽ cho áp dụng mẫu chủ đề với những Slide được chọn:",
    answer: "Apply to selected Slides",
  },
  {
    question: "Để tạo bài trình diễn trống, người dùng cần làm gì?",
    answer: "Chọn thẻ File  Chọn New Chọn Blank Presentation Nhấn Creat",
  },
  {
    question: "Để tạo bài trình diễn trống, ta nhấn tổ hợp phím:",
    answer: "Ctrl +N",
  },
  {
    question: "Để tạo bài trình diễn từ mẫu có sẵn, người dùng cần làm gì?",
    answer: "Chọn thẻ File  Chọn New Chọn Sample Templates  Nhấn Creat",
  },
  {
    question:
      "Để dùng các mẫu thiết kế của người dùng tạo hoặc các mẫu sưu tầm đang lưu trên đĩa, ta làm như sau:",
    answer:
      "Chọn thẻ File chọn New chọn My Templates chọn mẫu mong muốn Nhấn OK",
  },
  {
    question: "Để tạo bài thuyết trình từ một tập tin có sẵn, ta làm như sau:",
    answer: "Chọn thẻ File  chọn New chọn New from Existing … Nhấn Creat",
  },
  {
    question: "Để lưu bài trình diễn lần đầu tiên, người dùng cần làm gì?",
    answer: "Cả ba cách đều đúng",
  },
  {
    question:
      "Để lưu bài trình diễn đang mở với một tên khác, người dùng cần làm gì?",
    answer: "Nhấn thẻ File Save As",
  },
  {
    question:
      "Để đặt mật khẩu cho phép mở tập tin MS-PowerPoint, người dùng cần làm gì?",
    answer:
      "Vào File Info Protect Presentation Nhập mật mã vào và nhấn nút OK Xác nhận lại mật mã một lần nữa và nhấn nút OK để hoàn thành.",
  },
  {
    question:
      "Để chuyển MS-PowerPoint sang định dạng PDF và XPS, người dùng có thể lựa chọn các cách nào sau đây?",
    answer:
      "Vào File  Save (nếu lưu lần đầu) tại hộp Save as type chọn PDF (*.pdf); Vào File  Save As  chọn PDF or XPS tại hộp Save as type chọn PDF (*.pdf)",
  },
  {
    question:
      "Để bắt đầu trình chiếu từ slide đầu tiên, người dùng lựa chọn các cách nào sau đây?",
    answer:
      "Vào tab Slide Show từ thanh Ribbon chọn From Begginning; Nhấn phím F5",
  },
  {
    question:
      "Để bắt đầu trình chiếu từ slide hiện hành, người dùng lựa chọn các cách nào sau đây?",
    answer: "Vào tab Slide Show từ thanh Ribbon chọn From Current Slide",
  },
  {
    question:
      "Trong khi trình chiếu, để chuyển nhanh đến một slide xác định, người dùng lựa chọn các cách nào sau đây?",
    answer:
      "Nhấn chuột phải lên màn hình trình chiếu chọn Go to slide chọn slide cần di chuyển đến",
  },
  {
    question:
      "Trong khi trình chiếu, để hiển thị màn hình màu đen, người dùng lựa chọn các cách nào sau đây?",
    answer: "Nhấn phím B",
  },
  {
    question:
      "Trong khi trình chiếu, để hiển thị màn hình màu trắng, người dùng lựa chọn các cách nào sau đây?",
    answer: "Nhấn phím W",
  },
  {
    question:
      "Trong khi trình chiếu, muốn chuyển đến Slide liền trước, người dùng lựa chọn các cách nào sau đây?",
    answer: "Nhấn PageUp",
  },
  {
    question:
      "Trong khi trình chiếu, muốn chuyển đến Slide kế tiếp, ta thực hiện :",
    answer: "Nhấn Pagedown",
  },
  {
    question:
      "Trong khi trình chiếu, muốn chuyển về Slide đầu tiên, ta thực hiện :",
    answer: "Nhấn Home",
  },
  {
    question:
      "Trong khi trình chiếu, muốn chuyển về Slide cuối cùng, người dùng cần làm gì?",
    answer: "Nhấn End",
  },
  {
    question:
      "Trong chế độ soạn thảo, khi nhấn tổ hợp phím Alt +H tức là người dùng đang chọn tab:",
    answer: "Home",
  },
  {
    question:
      "Có thể thêm chức năng Spelling vào thanh Quick Access Toolbar được không?",
    answer: "Có",
  },
  {
    question:
      "Trong chế độ soạn thảo với MS-PowerPoint, khi nhấn tổ hợp phím Alt +W tức là người dùng đang chọn tab:",
    answer: "View",
  },
  {
    question:
      "Trong chế độ soạn thảo với MS-PowerPoint, khi nhấn tổ hợp phím Alt +G tức là người dùng đang chọn tab:",
    answer: "Design",
  },
  {
    question:
      "Trong chế độ soạn thảo với MS-PowerPoint, khi nhấn tổ hợp phím Alt +S tức là người dùng đang chọn tab:",
    answer: "Slide Show",
  },
  {
    question:
      "Trong chế độ soạn thảo với MS-PowerPoint, khi nhấn tổ hợp phím Alt +F tức là người dùng đang chọn tab:",
    answer: "File",
  },
  {
    question:
      "Để thay đổi các tùy chọn thiết lập/ hủy bỏ chế độ kiểm tra lỗi chính tả trong MS-PowerPoint, người dùng có thể lựa chọn cách nào sau đây?",
    answer: "File chọn Options chọn Proofing",
  },
  {
    question:
      "Để thiết lập tính năng AutoCorrect Options, người dùng có thể lựa chọn cách nào sau đây?",
    answer: "File chọn Options chọn Proofing",
  },
  {
    question:
      "Để thay đổi tên người tạo tệp, người dùng có thể lựa chọn cách nào sau đây?",
    answer: "File chọn Options chọn General",
  },
  {
    question:
      "Một tệp tin có chứa mẫu được tạo trước và có thể được sử dụng cho một bài thuyết trình được gọi là gì?",
    answer: "Template",
  },
  {
    question: "Cách nào sau đây được sử dụng để khởi động MS-PowerPoint",
    answer: "Start > All Programs > Microsoft Office > Microsoft PowerPoint",
  },
  {
    question:
      "Tùy chọn nào dưới đây có thể được chọn để thiết lập bài trình chiếu lặp đi lặp lại liên tục",
    answer: "Loop continuously until Esc",
  },
  {
    question: "Để kích hoạt chế độ Use Presenter View, người dùng cần phải có",
    answer:
      "Màn hình thứ hai hoặc máy chiếu kết nối với máy tính của người dùng",
  },
  {
    question: "Phần mở rộng tệp tin mặc định của MS-PowerPoint là gì?",
    answer: ".pptx",
  },
  {
    question:
      "Trong Ms-PowerPoint, tùy chọn nào dưới đây cho phép thiết lập thời gian cho mỗi đối tượng trong PowerPoint Presentation?",
    answer: "Slide show, custom animation",
  },
  {
    question: "Trong MS-PowerPoint, master slide có chức năng gì",
    answer:
      "Thiết lập các nội dung mà người dùng muốn chúng hiển thị trên tất cả các slide như logo, font chữ",
  },
  {
    question:
      "Trong MS-PowerPoint, thẻ nào cho phép thiết lập hiệu ứng chuyển tiếp giữa các slide?",
    answer: "Transitions",
  },
  {
    question: "Trong MS-Microsot PowerPoint, tổ hợp phím Ctrl + D được dùng để",
    answer: "Nhân bản slide đang chọn",
  },
  {
    question: "Trong MS-PowerPoint có thể tạo bản trình diễn mới từ:",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Một trang trình diễn trong MS-PowerPoint được gọi là gì?",
    answer: "Một Slide",
  },
  {
    question: "MS-PowerPoint có các chế độ trình diễn nào?",
    answer: "Normal, Slide Sorter, Notes Page",
  },
  {
    question: "MS-PowerPoint không có chế độ trình diễn nào?",
    answer: "Reading Show",
  },
  {
    question: "Đâu không phải là phần mềm trình chiếu?",
    answer: "Microsoft Access",
  },
  {
    question: "Những điều nên làm để có một bản thuyết trình tốt",
    answer:
      "Sử dụng đề mục hoa thị hoặc số để thể hiện các bước của một nội dung, trình tự, Đưa biểu đồ vào slide để hiển thị mô hình hoặc xu hướng của dữ liệu, Chèn hình ảnh ở nhiều dạng khác nhau",
  },
  {
    question:
      "Chọn câu trả lời đúng cho việc xây dựng trình tự của trang thuyết trình",
    answer:
      "Slide tiêu đề -> Slide mục lục chương trình  -> Các slide nội dung -> slide tổng kết",
  },
  {
    question:
      "Nhập văn bản trong một bản thuyết trình thì có thể nhập vào đâu?",
    answer: "Nhập văn bản trong thẻ Outline, Nhập văn bản vào khung Slide",
  },
  {
    question:
      "Khi tạo một bản thuyết trình, lựa chọn nào dưới đây để tạo một bản thuyết trình trống chỉ có tiêu đề của slide; người dùng tự thêm nội dung và áp dụng các hiệu ứng theo ý mình",
    answer: "Blank Presentation",
  },
  {
    question:
      "Khi tạo một bản thuyết trình, lựa chọn nào dưới đây để chọn một bản thuyết trình đã được thiết kế sẵn với những hiệu ứng về màu sắc, font chữ , hình ảnh….; người dùng có thể nhập văn bản và thay đổi thiết kế",
    answer: "Installed Templates",
  },
  {
    question:
      "Khi tạo một bản thuyết trình, lựa chọn nào dưới đây để chọn sử dụng mẫu trình chiếu mà người dùng hoặc một ai đó trong tổ chức của người dùng tạo ra",
    answer: "My Templates",
  },
  {
    question:
      "Tùy chọn nào hiển thị thông tin trên bản trình chiếu mà chứa ba khung: Outline, Slide và Notes",
    answer: "Normal",
  },
  {
    question:
      "Hãy cho biết cách hiển thị nào sau đây hiển thị theo dạng liệt kê tất cả các slide của bài cùng một lúc trong PowerPoint?",
    answer: "Slide Sorter",
  },
  {
    question:
      "Hãy cho biết cách hiển thị nào sau đây hiển thị cả phần ghi chú của slide trong MS-PowerPoint?",
    answer: "Notes Page",
  },
  {
    question:
      "Hãy cho biết cách hiển thị nào sau đây là cách hiển thị dạng trình chiếu trong MS-PowerPoint?",
    answer: "Reading View",
  },
  {
    question:
      "Hãy cho biết lựa chọn nào sau đây xây dựng định dạng nội dung cho tất cả các slide trong MS-PowerPoint?",
    answer: "Slide Master",
  },
  {
    question:
      "Hãy cho biết lựa chọn nào sau đây xây dựng định dạng nội dung ghi chú cho tất cả các slide trong MS-PowerPoint?",
    answer: "Notes Master",
  },
  {
    question:
      "Hãy cho biết muốn thêm nút điều khiển quay trở về slide đầu tiên trong MS-PowerPoint, ta chọn cách nào sau đây:",
    answer: "Insert/Shapes",
  },
  {
    question: "Hãy cho biết trong MS-PowerPoint hỗ trợ các dạng âm thanh nào?",
    answer: "*. MP4, *.MP3, *.WAV",
  },
  {
    question: "Hãy cho biết trong PowerPoint hỗ trợ các dạng video nào?",
    answer: "*.AVI, *.WMV, *.ASF",
  },
  {
    question:
      "Ảnh H1 nằm trên ảnh H2 trên cùng một slide, để hiện ảnh H2 cần ẩn đi ảnh H1. Hỏi để ẩn ảnh H1 ta cần chọn hiệu ứng nào trong các hiệu ứng sau đây?",
    answer: "Exit",
  },
  {
    question:
      "Muốn thêm một ảnh từ một thư mục có sẵn trong máy tính ta chọn cách nào sau đây:",
    answer: "Insert/Picture",
  },
  {
    question: "Muốn thêm một sơ đồ vào slide ta chọn cách nào sau đây:",
    answer: "Insert/SmartArt",
  },
  {
    question:
      "Hãy cho biết muốn thêm một bảng vào slide ta chọn cách nào sau đây:",
    answer: "Insert/Table",
  },
  {
    question:
      "Hãy cho biết muốn thêm một đường cong vào slide ta chọn cách nào sau đây:",
    answer: "Insert/Shapes",
  },
  {
    question:
      "Hãy cho biết muốn thêm chữ nghệ thuật vào slide ta chọn cách nào sau đây:",
    answer: "Insert/Word Art",
  },
  {
    question:
      "Hãy cho biết để đổi màu dòng văn bản hiện ra ta chọn hiệu ứng nào trong các hiệu ứng sau đây?",
    answer: "Emphasis",
  },
  {
    question:
      "Hãy cho biết để hiển thị dòng văn bản chạy từ bên trái sang bên phải của slide, ta chọn hiệu ứng nào trong các hiệu ứng sau đây?",
    answer: "Entrance",
  },
  {
    question:
      "Hãy cho biết để dòng văn bản chạy ra theo một đường do người dùng xây dựng, ta chọn hiệu ứng nào trong các hiệu ứng sau đây?",
    answer: "Motion Paths",
  },
  {
    question:
      "Hãy cho biết để hiển thị dòng văn bản chạy từ bên trái sang bên phải của slide, ta chọn hiệu ứng nào trong các hiệu ứng sau đây?",
    answer: "Entrance",
  },
  {
    question:
      "Hãy cho biết để tạo hiệu ứng con ong bay đến bông hoa như hình dưới đây ta chọn hiệu ứng nào?",
    answer: "Motion Paths",
  },
  {
    question:
      "Hãy cho biết để tạo hiệu ứng chữ bay từ dưới lên trong MS-PowerPoint thì chọn hiệu ứng nào sau đây:",
    answer: "Fly In",
  },
  {
    question:
      "Để sử dụng trợ giúp trong MS-PowerPoint, có thể sử dụng lệnh gì dưới đây?",
    answer: "Nhấn phím F1, Kích chuột vào biểu tượng   ở góc bên phải màn hình",
  },
  {
    question:
      "Để định dạng văn bản về font chữ, màu chữ, kích cỡ chữ, chọn nhóm nào dưới đây trong thẻ Home",
    answer: "Font",
  },
  {
    question:
      "Để định dạng căn lề văn bản (Left, Centered, Right…) chọn nhóm nào dưới đây trong thẻ Home",
    answer: "Paragraph",
  },
  {
    question:
      "Để đối tượng Shape có sẵn thay đổi màu nền, chọn phương án nào đúng dưới đây:",
    answer: "Shape Fill",
  },
  {
    question:
      "Để đối tượng Shape có sẵn thay đổi màu viền, chọn phương án nào đúng dưới đây:",
    answer: "Shape Outline",
  },
  {
    question:
      "Để đối tượng Shape thay đổi hiệu ứng, chọn phương án nào đúng dưới đây:",
    answer: "Shape Effects",
  },
  {
    question: "Các kiểu danh sách được sử dụng để định dạng văn bản (Chọn 2)",
    answer: "Bullets, Numbering",
  },
  {
    question: "Kiểu danh sách không có thứ tự là kiểu nào dưới đây",
    answer: "Bullets",
  },
  {
    question:
      "Thụt lề trái của văn bản về phía bên trong sử dụng chức năng nào dưới đây",
    answer: "Increase Indent",
  },
  {
    question:
      "Thụt lề trái của văn bản về phía bên ngoài sử dụng chức năng nào dưới đây",
    answer: "Decrease Indent",
  },
  {
    question:
      "Trong Ms-Power Point để thêm tên của biểu đồ người dùng chọn mục nào?",
    answer: "Chart Title",
  },
  {
    question:
      "Để thay đổi kiểu biểu đồ hiển thị, tùy chọn chức năng gì dưới đây là đúng?",
    answer:
      "Thẻ Design nhóm công cụ ngữ cảnh Chart Tools -> chọn nhóm Type -> chọn Change Chart Type",
  },
  {
    question:
      "Trong Powerpoint, người dùng có một  textbox trên màn hình, con trỏ ở vị trí như hình dưới\n\nKhi người dùng chọn công cụ BOLD, ký tự nào sẽ bị ảnh hưởng",
    answer: "Cả từ ‘and’",
  },
  {
    question:
      "Những thẻ nào không xuất hiện ở thực đơn bên trái của bản trình chiếu khi bản thuyết trình được mở",
    answer: "Notes",
  },
  {
    question: "Để mở ứng dụng Microsoft PowerPoint chọn",
    answer: "Chọn Start -> Run và gõ powerpnt sau đó nhấn Enter",
  },
  {
    question:
      "Tại một Slide hiện hành ta bấm delete (trên bàn phím) lệnh này sẽ...",
    answer: "Xóa slide",
  },
  {
    question: "Thêm 1 slide rỗng ta dùng tổ hợp phím nào sau đây ?",
    answer: "ALT+I+N",
  },
  {
    question:
      'Muốn chữ "Powerpoint" trong một văn bản định dạng thành "Powerpoint" ta:',
    answer:
      'Đưa con trỏ văn bản đến chữ "Powerpoint" và nhấn tổ hợp phím CTRL+U rồi CTRL + B (hoặc ngược lại)',
  },
  {
    question:
      "Hãy cho biết để tạo hiệu ứng từng chữ xoay tròn và hiện ra trong PowerPoint thì chọn hiệu ứng nào sau đây:",
    answer: "Pinwheel",
  },
  {
    question:
      "Điểm xử lý nào trên ảnh đã được chọn cho phép người dùng thay đổi kích thước của hai bên ảnh cùng một lúc",
    answer: "Một trong các điểm xử lý ở góc",
  },
  {
    question: "Mục đích của việc tạo ghi chú vào bản trình chiếu",
    answer: "Tất cả các đáp án trên",
  },
  {
    question: "Để thêm một biểu đồ vào trong slide, chọn đáp án nào dưới đây ?",
    answer: "SmartArt",
  },
  {
    question: "Nhóm Create Graphic xuất hiện khi chọn thẻ gì dưới đây",
    answer: "Design trong thanh công cụ mở rộng của SmartArt Tools",
  },
  {
    question:
      "Để thay đổi độ rộng của hàng và cột trong bảng, trong thẻ Layout, người dùng chọn nhóm thẻ nào dưới đây (Chọn 2)",
    answer: "Cell Size, Table Size",
  },
  {
    question:
      "Hiệu ứng trong Animation mà: Các đối tượng áp dụng hiệu ứng sẽ xuất hiện trên slide hoặc có xu hướng di chuyển từ bên ngoài slide vào trong slide",
    answer: "Hiệu ứng Entrance",
  },
  {
    question:
      "Hiệu ứng trong Animation mà: Nhấn mạnh nội dung áp dụng hiệu ứng",
    answer: "Hiệu ứng Emphasis",
  },
  {
    question:
      "Trong Ms.Power Point, tùy chọn thay đổi tham số cho sự xuất hiện slide hay sử dụng nhấp chuột để chuyển trang, trong nhóm lệnh Timing của thẻ?",
    answer: "Transitions",
  },
  {
    question: "Tối đa có thể in được bao nhiêu slide trên một trang",
    answer: "9",
  },
  {
    question:
      "Để chọn chức năng kiểm tra chính tả trong PowerPoint chọn thẻ nào dưới đây ?",
    answer: "Review",
  },
  {
    question: "Nhóm Language nằm trong thẻ gì dưới đây",
    answer: "Review",
  },
  {
    question: "Spelling có chức năng gì trong PowerPoint",
    answer: "Chức năng tìm kiếm, kiểm tra lỗi và chỉnh sửa lỗi chính tả",
  },
  {
    question: "Lệnh Group có chức năng gì ?",
    answer: "Để tạo nhóm các đối tượng riêng lẻ thành 1 nhóm",
  },
  {
    question: "Tùy chọn danh sách dưới đây thuộc nhóm :",
    answer: "Bullets",
  },
  {
    question: "Tùy chọn danh sách dưới đây thuộc nhóm :",
    answer: "Numbering",
  },
  {
    question:
      "In ấn tài liệu dành cho diễn giả (người thuyết trình) thường ở dạng nào dưới đây (Chọn 2)",
    answer: "Notes Page, Outline",
  },
  {
    question:
      "In ấn tài liệu dành cho người nghe thuyết trình thường ở dạng nào dưới đây (Chọn 2)",
    answer: "Handout, Slide",
  },
  {
    question: "Hiệu ứng dưới đây nằm trong nhóm lệnh nào ?",
    answer: "Transitions",
  },
  {
    question: "Hiệu ứng dưới đây nằm trong nhóm lệnh nào ?",
    answer: "Animation",
  },
  {
    question: "Những lựa chọn nào sau đây là sai (chọn 2)?",
    answer:
      "Insert Above: Chèn dòng ngay dưới ô đang chọn, Insert Below: Chèn dòng ngay trên ô đang chọn",
  },
  {
    question:
      "Trong Ms.Power Point, để di chuyển đối tượng Shape lên trên một vị trí chọn ?",
    answer: "Move Up",
  },
  {
    question:
      "Trong Ms.Power Point, làm thế nào để đảo chiều các đối tượng Shape trong SmartArt?",
    answer: "Right to left",
  },
  // Module 6
  {
    question: "Mạng Internet ra đời vào năm nào?",
    answer: "1969",
  },
  {
    question:
      "Dịch vụ Internet được chính thức cung cấp tại Việt Nam vào năm nào?",
    answer: "1997",
  },
  {
    question: "Arpanet là gì?",
    answer: "Tiền thân của Internet",
  },
  {
    question: "Ethernet là gì?",
    answer: "Một chuẩn mạng cục bộ (LAN)",
  },
  {
    question: "Để 2 mạng có thể kết nối với nhau thì:",
    answer:
      "Cần dùng 1 thiết bị để kết nối 2 mạng đó và phải có các giao thức truyền tin như các ngôn ngữ để 2 mạng có thể trao đổi.",
  },
  {
    question:
      "Các quy tắc điều khiển, quản lý việc truyền thông máy tính được gọi là gì?",
    answer: "Các giao thức mạng",
  },
  {
    question: "Thiết bị thường dùng để kết nối các mạng trên Internet?",
    answer: "Router",
  },
  {
    question: "TCP/IP là gì?",
    answer: "1 bộ giao thức",
  },
  {
    question: "Bộ giao thức TCP\\IP có mấy tầng?",
    answer: "4 tầng",
  },
  {
    question: "Mô hình OSI có mấy tầng?",
    answer: "7 tầng",
  },
  {
    question: "Bộ giao thức được dùng chủ yếu trên Internet?",
    answer: "TCP/IP",
  },
  {
    question:
      "Các tầng nào dưới đây không thuộc bộ giao thức TCP/IP? (chọn 2 đáp án)",
    answer: "Tầng vật lý, Tầng giao vận",
  },
  {
    question:
      "Trong các thuật ngữ dưới, những thuật ngữ nào không chỉ bộ giao thức?",
    answer: "LAN/WAN",
  },
  {
    question:
      "Trong các thuật ngữ dưới đây, những thuật ngữ nào không chỉ dịch vụ Internet?",
    answer: "TCP/IP (Transmission Control Protocol/Internet Protocol)",
  },
  {
    question:
      "Đâu là tên viết tắt đầy đủ của các nhà cung cấp dịch vụ Internet? (chọn 3 đáp án)",
    answer: "IAP, ISP, ICP",
  },
  {
    question:
      "Phương pháp kết nối Internet nào phổ biến nhất đối với người dùng riêng lẻ?",
    answer: "Kết nối qua modem",
  },
  {
    question: "Những cấu trúc địa chỉ IP nào dưới đây là đúng? (chọn 2 đáp án)",
    answer: "192.168.1.0, 172.193.0.0",
  },
  {
    question: "Mục đích chính của việc đưa ra tên miền?",
    answer: "Dễ nhớ",
  },
  {
    question: "Hệ thống tên miền được tổ chức theo?",
    answer: "Mô hình phân cấp",
  },
  {
    question: "Internet Explorer là gì?",
    answer: "Trình duyệt web dùng để hiển thị các trang web trên Internet",
  },
  {
    question: "Ngôn ngữ đánh dấu siêu văn bản được viết tắt là?",
    answer: "HTML",
  },
  {
    question: "Ngôn ngữ đánh dấu siêu văn bản?",
    answer:
      "Là ngôn ngữ đơn giản, sử dụng các thẻ để tạo ra các trang văn bản hỗn hợp.",
  },
  {
    question:
      "Để kết nối Internet thông qua mạng cục bộ (LAN), cần thông tin nào? (chọn 2 đáp án)",
    answer:
      "Địa chỉ IP máy chủ Proxy., Card mạng và đường kết nối đến máy chủ Proxy.",
  },
  {
    question:
      "Để thiết lập địa chỉ Proxy, cần thực hiện thao tác nào trong các thao tác sau? (chọn 3 đáp án)",
    answer:
      "Chọn thẻ Connection trong hộp thoại Internet Option., Nhấn vào nút LAN Settings., Nhập các thông số do người quản trị mạng cung cấp.",
  },
  {
    question: "Đâu không phải là một địa chỉ IP? (chọn 2 đáp án)",
    answer: "250.256.10.12, 189.199.260.11",
  },
  {
    question: "Giao thức duyệt Web an toàn là?",
    answer: "HTTPs",
  },
  {
    question:
      "Các phương pháp kết nối Internet đang phổ biến nhất tại Việt Nam hiện nay? (chọn 2 đáp án)",
    answer: "ADSL, Cáp quang",
  },
  {
    question: "Để tìm kiếm thông tin trên Internet, ta có thể tìm bằng cách?",
    answer: "Mở một trang Web tìm kiếm, nhập từ khóa tìm kiếm và chọn Search",
  },
  {
    question: "Đâu là các trình duyệt Web thông dụng? (chọn 2 đáp án)",
    answer: "Internet Explorer, Mozilla Firefox",
  },
  {
    question: "Chỉ ra định nghĩa đúng về URL?",
    answer:
      "Là một chuỗi ký tự phù hợp với mô hình và định dạng chuẩn, sử dụng các nguồn tài nguyên trên Internet bằng cách định vị hoặc nhận dạng",
  },
  {
    question: "Giao thức mạng nào sau đây là giao thức truyền tệp an toàn?",
    answer: "FTPs",
  },
  {
    question: "Những kết nối nào là các kết nối không dây? (chọn 2 đáp án)",
    answer: "Bluetooth, Wi-fi",
  },
  {
    question:
      "Hai lựa chọn nào cho bạn biết rằng bạn đang ở trên một trang web an toàn? (chọn 2 đáp án)",
    answer:
      "Địa chỉ URL trong thanh sẽ bắt đầu với https://., Một biểu tượng của một ổ khóa màu vàng sẽ được hiển thị trong thanh địa chỉ",
  },
  {
    question: "Hai lựa chọn nào là đặc điểm của một mạng LAN? (chọn 2 đáp án)",
    answer: "Là mạng tương đối nhỏ, Có một tốc độ truyền tải cao",
  },
  {
    question:
      "Tính đến năm 2012, hai trình duyệt được sử dụng phổ biến nhất là gì? (chọn 2 đáp án)",
    answer: "Firefox, Internet Explorer",
  },
  {
    question:
      "..... là một phần mềm dùng để hiện thị nội dung của trang Web tại phía người dùng.",
    answer: "Trình duyệt (Browser)",
  },
  {
    question:
      ".....là một dịch vụ trên Internet, cho phép người dùng có thể tải tệp (download file) từ Internet.",
    answer: "FTP",
  },
  {
    question:
      "Người dùng sử dụng trường BCC khi gửi thư trong Outlook để làm gì?",
    answer: "Những người nhận BBC không nhìn thấy nhau",
  },
  {
    question:
      "Các lệnh nào sau đây không sử dụng thông điệp ICMP cũng như Time to Live khi thực thi? (chọn 2 đáp án)",
    answer: "Nslookup, Route",
  },
  {
    question:
      "Các biện pháp phòng ngừa nào có thể giúp người dùng tránh được việc ăn cắp các tư liệu có bản quyền? (chọn 2 đáp án)",
    answer:
      "Đảm bảo tất cả các phần mềm đi kèm với một thỏa thuận cấp phép, Đăng ký phần mềm tải về hoặc mua phần mềm",
  },
  {
    question:
      "Các phát biểu nào dưới đây là đúng nói về sự khác biệt giữa World Wide Web và Internet? (chọn 3 đáp án)",
    answer:
      "Internet có thể tồn tại mà không cần có World Wide Web, World Wide Web chỉ là một phần của toàn bộ mạng Internet., World Wide là một bộ sưu tập toàn cầu kết nối các tài liệu và các nguồn lực khác. Internet là một kết nối toàn cầu của các mạng máy tính trên toàn thế giới.",
  },
  {
    question:
      "Chỉ ra hai công cụ cho phép tìm kiếm thông tin trên Internet? (chọn 2 đáp án)",
    answer: "Yahoo, Google",
  },
  {
    question: "Chỉ ra phát biểu đúng về kết nối an toàn.",
    answer:
      "Khi bạn nhấn chuột vào biểu tượng ổ khóa trên thanh an toàn bạn sẽ có được thông tin về danh tính của trang web",
  },
  {
    question: "Chỉ ra 2 toán tử tìm kiếm được sử dụng bởi Google?",
    answer: "$, ^",
  },
  {
    question: "Chỉ ra phát biểu đúng về mạng P2P?",
    answer:
      "Là mạng mà tất cả các máy tính trong mạng có vai trò như nhau và không có máy chủ trung tâm",
  },
  {
    question:
      "Đâu là thuật ngữ chỉ một chương trình mã độc có khả năng tự lây nhiễm qua mạng với tốc độ nhanh?",
    answer: "Worm",
  },
  {
    question: "Chỉ ra điều mà bạn mong muốn khi lựa chọn một trình duyệt Web?",
    answer: "Đơn giản, tốc độ và bảo mật",
  },
  {
    question:
      "Dịch vụ nào cung cấp cho người sử dụng Internet một hệ thống có thể lưu trữ âm thanh, hành ảnh, image, video hoặc các nội dung khác và có khả năng truy cập thông qua Internet.",
    answer: "Hosting",
  },
  {
    question: "Diễn đàn là nơi mọi người có thể làm gì?",
    answer: "Thảo luận theo các chủ đề",
  },
  {
    question: "DNS giúp bạn xác định một website bằng cách nào?",
    answer: "Cho phép bạn truy cập website bằng tên miền thay vì địa chỉ IP",
  },
  {
    question:
      "Hai khung thời gian được sử dụng khi nói về giao tiếp trên mạng máy tính?",
    answer: "Thời gian thực và có trì hoãn",
  },
  {
    question: "Mạng máy tính là gì?",
    answer:
      "Tập hợp các máy tính được kết nối với nhau bằng các thiết bị mạng và tuân theo một quy ước truyền thông",
  },
  {
    question:
      "Máy tính của bạn gặp vấn đề, bạn nhận được nhiều lời khuyên về cách xử lý từ diễn đàn chuyên xử lý sự cố máy tính. Làm thế nào để bạn có thể đánh giá được các lời khuyên này là hữu ích. (chọn 2 đáp án)",
    answer:
      "Lời nhận xét mang tính xây dựng từ những thành viên của diễn đàn khác về chủ đề trên diễn đàn, Sự cố đã được giải quyết thành công tại một chủ đề tương tự trên diễn đàn",
  },
  {
    question: "Tùy chọn nào dưới đây là đúng khi xóa cache trình duyệt?",
    answer:
      "Xóa các tập tin tạm (Temporary Internet Files) phát sinh từ các trang web đã được truy cập trước đó.",
  },
  {
    question:
      "Trong Outlook, ý nghĩa của biểu tượng “Kẹp giấy” xuất hiện bên cạnh các thư mà bạn nhận được là gì?",
    answer: "Có tệp tin đính kèm",
  },
  {
    question: "Ba dấu hiệu chỉ ra máy tính của bạn đang bị nhiễm virus?",
    answer:
      "Xuất hiện các thanh công cụ mở rộng, Các chương trình thường xuyên bị khóa, Các biểu tượng không sử dụng xuất hiện trên Desktop",
  },
  {
    question:
      "Bạn cùng nhóm bạn tạo một tài khoản của một bạn cùng lớp trên mạng giả. Trên trang chủ của tài khoản, bạn post các thông tin sai về người bạn đó. Chỉ ra hai định nghĩa đúng về điều này:",
    answer: "Nhạo báng, Phỉ báng",
  },
  {
    question:
      "..... là một cố gắng để thuyết phục ai đó làm điều gì đó hoặc tiết lộ thông tin bí mật. Những điều mà họ chưa từng làm hoặc sẽ không bao giờ làm.",
    answer:
      "Phương pháp phi kỹ thuật đột nhập vào hệ thống (Social engineering)",
  },
  {
    question:
      "..... là một ngôn ngữ được sử dụng bởi các máy tính để giao tiếp, trao đổi thông tin với nhau qua việc sử dụng hệ thống mạng",
    answer: "Giao thức (Protocol)",
  },
  {
    question:
      "..... là quá trình cải thiện một cách có hệ thống khả năng hiển thị của một trang web trong các công cụ tìm kiếm khác nhau.",
    answer: "Xếp hạng trong công cụ tìm kiếm",
  },
  {
    question:
      "..... xác minh danh tính của một máy tính khi kết nối với một máy chủ.",
    answer: "Chứng thực máy khách (Client authentication)",
  },
  {
    question:
      ".....là một dịch vụ Internet, cho phép bạn kết nối từ xa đến một máy tính.",
    answer: "Telnet",
  },
  {
    question:
      "......kiểm soát hoặc loại trừ các ấn phẩm trên Internet hoặc hạn chế truy cập các ấn phẩm.",
    answer: "Kiểm duyệt Internet",
  },
  {
    question:
      "....là một ứng dụng web có hỗ trợ các cuộc thảo luận và ý kiến trực tuyến, cho phép người sử dụng thể hiện ý tưởng hoặc ý kiến của họ về một chủ đề.",
    answer: "Diễn đàn",
  },
  {
    question:
      "Ba yêu cầu nào là cần thiết để có một trang Web trên Internet? (chọn 3 đáp án)",
    answer:
      "Thiết kế trang web, Đăng ký tên miền, Hợp đồng với một dịch vụ lưu trữ",
  },
  {
    question:
      "Người dùng muốn tải lại (Refresh) một trang web đang hiển thị trên một trình duyệt phổ biến, nên sử dụng phím tắt nào?",
    answer: "F5",
  },
  {
    question: "Ba thuận lợi của việc sử dụng Internet là?",
    answer:
      "Cập nhật định kỳ hệ điều hành, phần sụn (Firmware), và phần mềm thường là đơn giản, Làm cho việc tìm kiếm thông tin dễ dàng hơn, Cho phép giao tiếp với mọi người trên toàn thế giới",
  },
  {
    question:
      "Các .... của trình duyệt là nơi mà dữ liệu và hình ảnh của những trang web cuối cùng được truy cập bởi người dùng được lưu  trữ tạm thời. Nếu một trong những trang web trước đó được truy cập lại, trình duyệt sẽ hiển thị lại trang web với các dữ liệu được lưu trữ thay vì phải truy lục lại một cách trực tuyến.",
    answer: "Cache",
  },
  {
    question:
      "Các dấu ngoặc kép được sử dụng trong công cụ tìm kiếm có tác dụng gì?",
    answer:
      "Để hạn chế kết quả tìm kiếm trên những trang bao gồm những từ cụ thể",
  },
  {
    question:
      "Cộng đồng ảo, nơi người dùng có thể tương tác với những người khác được gọi là gì?",
    answer: "Các mạng xã hội (Social Networks)",
  },
  {
    question: "Diễn đàn trên Internet dùng để?",
    answer:
      "Các thành viên có thể trao đổi, học hỏi về nhiều lĩnh vực có cùng sự quan tâm.",
  },
  {
    question: "Tham gia vào diễn đàn, người dùng có thể: (chọn 3 đáp án)",
    answer:
      "Có những người bạn cùng chí hướng về một lĩnh vực nào đó, Tìm kiếm và chia sẻ những thông tin bổ ích, Giao lưu trực tuyến",
  },
  {
    question: "WWW là viết tắt của?",
    answer: "World Wide Web",
  },
  {
    question: "Trang Web là?",
    answer:
      "Là trang siêu văn bản phối hợp giữa văn bản thông thường với hình ảnh, âm thanh, video và cả các mối liên kết đến các trang siêu văn bản khác.",
  },
  {
    question: "Tốc độ kết nối lớn nhất của ADSL là",
    answer: "12 Mbps",
  },
  {
    question:
      "Chương trình phần mềm thường được sử dụng để xem các trang Web được gọi là?",
    answer: "Trình duyệt Web",
  },
  {
    question: "Để xem một trang Web, cần phải gõ địa chỉ của trang đó vào?",
    answer: "Thanh địa chỉ của trình duyệt",
  },
  {
    question: "Nút Back trên các trình duyệt Web dùng để?",
    answer: "Quay trở lại trang Web trước đó",
  },
  {
    question: "Nút Forward trên các trình duyệt Web dùng để?",
    answer: "Đi đến trang Web tiếp theo",
  },
  {
    question: "Nút Home trên các trình duyệt Web dùng để?",
    answer: "Trở về trang mặc định của trình duyệt",
  },
  {
    question:
      "Trên trình duyệt  Web IE, muốn lưu các địa chỉ yêu thích (Favorites), sử dụng chức năng nào?",
    answer: "Add to Favorite",
  },
  {
    question:
      "Muốn xem 1 trang Web offline đã được lưu trên máy cục bộ, người dùng lựa chọn cách nào dưới đây?",
    answer: "Chọn File > Work Offline",
  },
  {
    question:
      "Muốn sao lưu một trang Web lên máy tính cá nhân, người dùng lựa chọn cách nào dưới đây?",
    answer: "Chọn File > Save As",
  },
  {
    question: "IP là viết tắt của từ nào?",
    answer: "Internet Protocol",
  },
  {
    question: "Địa chỉ IP phải là gì?",
    answer: "Một địa chỉ đơn nhất (trong cùng một cấp mạng)",
  },
  {
    question: "Địa chỉ IP tĩnh là gì?",
    answer: "Địa chỉ được thiết lập cố định",
  },
  {
    question: "Địa chỉ IP động là gì?",
    answer: "Địa chỉ được cấp khi kết nối mạng",
  },
  {
    question: "Địa chỉ IP động là địa chỉ được cung cấp bởi?",
    answer: "DHCP Server",
  },
  {
    question: "Dung lượng tối đa của tệp tin đính kèm khi gửi thư điện tử là?",
    answer: "Tùy thuộc vào từng hệ thống Email.",
  },
  {
    question: "Phát biểu nào sau đây là đúng về SMTP?",
    answer: "SMTP là giao thức gửi thư điện tử, SMTP là giao thức tin cậy",
  },
  {
    question: "Phát biểu nào sau đây là đúng về POP3?",
    answer: "POP3 là giao thức nhận thư điện tử, POP3 là giao thức tin cậy",
  },
  {
    question: "Lựa chọn các máy tìm kiếm phổ biến?",
    answer: "Google, Yahoo, Bing",
  },
  {
    question: "Đâu không phải là thành phần của một URL?",
    answer: "Địa chỉ Email, Ký tự “@”",
  },
  {
    question: "Lựa chọn các phát biểu đúng về dịch vụ Telnet?",
    answer:
      "Telnet cho phép người dùng điều khiển được thiết bị từ xa, Telnet là giao thức tin cậy",
  },
  {
    question:
      "Lựa chọn các phát biểu đúng về thuật ngữ “Download” và “Upload”?",
    answer:
      "“Download” là quá trình chuyển tải dữ liệu từ máy tính khác sang máy tính của bạn qua Internet, “Upload” đây là quá trình chuyển tải dữ liệu từ máy tính của bạn sang một máy tính khác qua Internet",
  },
  {
    question: "Đâu là các Email Client?",
    answer: "MS.Outllook, Mozilla thunderbird",
  },
  {
    question: "Đâu là phát biểu đúng nhất về nhiệm vụ của DNS?",
    answer: '"dịch" tên miền sang địa chỉ IP và ngược lại',
  },
  {
    question: "DNS là viết tắt của?",
    answer: "Domain Name System",
  },
  {
    question: "DHCP là viết tắt của?",
    answer: "Dynamic Host Configuration Protocol",
  },
  {
    question: "Dịch vụ tin nhắn tức thời – IM là viết tắt của?",
    answer: "Instant Messaging",
  },
  {
    question: "Chọn phát biểu đúng về thương mại điện tử?",
    answer:
      "Là sự mua bán sản phẩm hay dịch vụ trên các hệ thống điện tử như Internet và các mạng máy tính",
  },
  {
    question: "Trong thanh toán điện tử, thuật ngữ OTP là viết tắt của từ nào?",
    answer: "One Time Password",
  },
  {
    question:
      "Trong thanh toán điện tử, mật khẩu sử dụng một lần - OTP thường được gửi tới người dùng thông qua những hình thức nào?",
    answer: "SMS, Email, Token",
  },
  {
    question:
      "Để định danh một thiết bị/tài nguyên trên mạng người ta sử dụng địa chỉ IP. Địa chỉ IP có hai phiên bản nào?",
    answer: "IPv4, IPv6",
  },
  {
    question: "Subnetmask dùng để làm gì?",
    answer: "Chia một mạng thành nhiều mạng con",
  },
  {
    question: "Nút Refresh trong trình duyệt IE có tác dụng gì?",
    answer: "Làm tươi (tải lại) nội dung của trang web đang mở",
  },
  {
    question: "Để thiết lập Proxy server trong IE, người dùng cần phải?",
    answer: "Vào Tool  Internet Options  Connections  LAN settings",
  },
  {
    question:
      "Để thiết lập trang khởi động mặc định trong IE, người dùng cần phải?",
    answer: "Vào Tool  Internet Options  General",
  },
  {
    question:
      'Nếu nhập vào ô tìm kiếm của Google từ khóa "máy tính" thì kết quả sẽ là các trang có từ?',
    answer: "Máy tính",
  },
  {
    question:
      "Bạn muốn ngăn chặn những người nhận thư khác từ việc biết bạn đang gửi cho ông chủ của bạn một bản sao của một thư quan trọng.Tính năng gì bạn sẽ sử dụng để ẩn thông tin này từ những người nhận thư khác trên Outlook.com?",
    answer: "BCC",
  },
  {
    question: "Web Server là gì?",
    answer: "Là máy chủ để đặt các trang web trên Internet",
  },
  {
    question: "Chọn phát biểu đúng về Email?",
    answer: "Là dịch vụ cho phép gửi và nhận thư điện tử",
  },
  {
    question: "Chọn những phát biểu đúng về tên miền?",
    answer:
      "Tên miền là tên gợi nhớ, Tên miền là tên giao dịch của một công ty hay một tổ chức sử dụng trên Internet, Công việc chuyển đổi tên miền sang địa chỉ IP do máy chủ DNS đảm trách",
  },
  {
    question: "HTTP là gì?",
    answer: "Là giao thức truyền siêu văn bản",
  },
  {
    question: "Có thể mở các file .html bằng?",
    answer: "Trình duyệt web Internet Explorer, Trình duyệt web Mozila Firefox",
  },
  {
    question: "Để truy cập vào một trang web người dùng cần phải biết?",
    answer: "Tên miền của trang web",
  },
  {
    question: "TCP/IP được viết tắt từ?",
    answer: "Transmission Control Protocol / Internet Protocol.",
  },
  {
    question: "Chọn phát biểu đúng về Web Server?",
    answer:
      "Các trang web được lưu trên các Web Server., Khi có nhu cầu xem nội dung một trang web máy Client sẽ gửi yêu cầu đến Web Server., Sau khi nhận yêu cầu, Web Server sẽ gửi nội dung trang web về máy Client và hiển thị trên Web Browser.",
  },
  {
    question: "Cấu trúc đúng của một địa chỉ Email là?",
    answer: "<Tên_người_dùng>@<Tên_miền>",
  },
  {
    question:
      "Internet chính thức được cung cấp tại Việt Nam vào ngày tháng năm nào?",
    answer: "01/12/1997",
  },
  {
    question: '"www.goccay.vn". "vn" trên địa chỉ trang web có nghĩa là?',
    answer: "Ký hiệu tên nước Việt Nam",
  },
  {
    question: '"www.goccay.com". "com" trên địa chỉ trang web có nghĩa là?',
    answer: "Đây là địa chỉ của các trang web thương mại, dịch vụ",
  },
  {
    question: '"www.goccay.edu". "edu" trên địa chỉ trang web có nghĩa là gì?',
    answer: "Đây là địa chỉ của các trang web giáo dục",
  },
  {
    question: '"www.goccay.org". "org" trên địa chỉ trang web có nghĩa là?',
    answer:
      "Đây là địa chỉ các trang web của các tổ chức phi lợi nhuận và các tổ chức liên kết thương mại",
  },
  {
    question: '"www.goccay.info". "info" trên địa chỉ trang web có nghĩa là?',
    answer: "Đây là địa chỉ của các trang web tài nguyên",
  },
  {
    question: "Mạng Internet gồm những thành phần nào? (chọn 3 đáp án)",
    answer:
      "Các máy tính; Các thiết bị mạng đảm bảo việc kết nối giữa các máy tính với nhau; Phần mềm hỗ trợ kết nối giữa các máy với nhau",
  },
  {
    question:
      "Trong các thiết bị dưới đây, thiết bị nào không phải là thiết bị mạng? (chọn 2 đáp án)",
    answer: "Headphone; Webcam",
  },
  {
    question:
      "Để máy tính có thể kết nối mạng không dây đơn giản cần có? (chọn 2 đáp án)",
    answer:
      "Điểm truy cập không dây WAP(Wireless Access Point); Mỗi máy tính tham gia mạng có card mạng không dây",
  },
  {
    question: "Chọn phát biểu sai?",
    answer: "Mạng có dây có thể đặt cáp đến bất cứ địa điểm và không gian nào",
  },
  {
    question: "Để kết nối các máy tính người ta …",
    answer: "Sử dụng cáp quang, cáp đôi dây xoắn, đường truyền vô tuyến",
  },
  {
    question: "Phát biểu nào sau đây về mạng không dây là sai?",
    answer:
      "Mạng không dây thông thường có tốc độ truyền dữ liệu cao hơn hẳn mạng có dây",
  },
  {
    question: "Máy tính nào dưới đây cung cấp dịch vụ cho máy tính cá nhân?",
    answer: "Máy trạm (Workstation)",
  },
  {
    question: "Mô hình Client – Server là mô hình gì?",
    answer:
      "Xử lý phân tán ở nhiều máy, trong đó máy chủ cung cấp tài nguyên và các dịch vụ theo yêu cầu từ máy khách",
  },
  {
    question: "Phát biểu nào dưới đây về bộ định tuyến là đúng nhất?",
    answer:
      "Là thiết bị để kết nối hai mạng máy tính sao cho máy từ mạng này có thể gửi gói tin sang máy của mạng kia.",
  },
  {
    question: "Chọn phát biểu đúng?",
    answer:
      "Trong mô hình ngang hàng, một máy tính đóng vai trò máy chủ khi cung cấp tài nguyên cho máy khác và đóng vai trò máy khách khi sử dụng tài nguyên do máy khác cung cấp",
  },
  {
    question: "Phát biểu nào dưới đây là sai?",
    answer: "WAP không cho phép kết nối mạng không dây vào mạng có dây",
  },
  {
    question:
      "Mục đích của việc kết nối các máy tính thành mạng là gì? (chọn 2 đáp án)",
    answer:
      "Dùng chung dữ liệu giữa các máy tính; Chia sẻ thông tin giữa các tính",
  },
  {
    question:
      "Mạng có phạm vi bán kính nhỏ hơn 1Km, thường lắp đặt trong một văn phòng, công ty, trường học… là mạng?",
    answer: "LAN",
  },
  {
    question: "Modem là thiết bị phần cứng dùng để làm gì?",
    answer: "Chuyển đổi tín hiệu từ dạng tương tự sang dạng số và ngược lại",
  },
  {
    question:
      "Để truyền dữ liệu trên Internet bộ giao thức TCP/IP đảm bảo việc phân chia dữ liệu thành các ...",
    answer: "Gói tin",
  },
  {
    question:
      "Các phép toán Boolean sử dụng để tìm kiếm trong Google là? (chọn 3 đáp án)",
    answer: "AND; OR; NEAR",
  },
  {
    question:
      "Khi tìm kiếm nâng cao trên Google, muốn tìm kiếm dựa theo tiêu đề trang ta sử dụng từ khóa nào?",
    answer: "Intitle",
  },
  {
    question:
      "Khi tìm kiếm nâng cao trên Google, muốn tìm kiếm dựa theo tên mở rộng của file ta sử dụng từ khóa nào?",
    answer: "Filetype",
  },
  {
    question: "Đâu là các toán tử trong tìm kiếm trong Google?",
    answer: "Phép “+”; Phép “-”",
  },
  {
    question: "Dịch vụ nào được sử dụng để truyền file trên Internet?",
    answer: "Dịch vụ FTP",
  },
  {
    question: "IRC là viết tắt của từ nào?",
    answer: "Internet Relay Chat",
  },
  {
    question: "FTP là viết tắt của từ nào?",
    answer: "File Transfer Protocol",
  },
  {
    question: "LAN là viết tắt của từ nào?",
    answer: "Local Area Netwok",
  },
  {
    question: "Đâu không phải là trình duyệt Web Client?",
    answer: "Microsoft Word",
  },
  {
    question: "Để truy cập thư điện tử (Email), người dùng cần phải làm gì?",
    answer:
      "Sử dụng một giao diện Web hoặc một ứng dụng thư điện tử trên máy khách",
  },
];

document.addEventListener("mouseup", function () {
  // Lấy đoạn văn bản được bôi đen sau khi nhả chuột
  const selectedText = window.getSelection().toString().trim();
  if (selectedText.length > 0) {
    // Lấy phạm vi của đoạn văn bản được bôi đen
    const range = window.getSelection().getRangeAt(0);
    // Lấy vị trí và kích thước của đoạn văn bản được bôi đen trên màn hình
    const rect = range.getBoundingClientRect();
    // Xóa biểu tượng nếu có
    const iconPrevios = document.getElementById("textScannerIcon");
    if (iconPrevios) {
      iconPrevios.remove();
    }
    // Tạo một thẻ div để làm biểu tượng tiện ích
    const icon = document.createElement("div");
    // Gán id cho thẻ div
    icon.id = "textScannerIcon";
    // Đặt vị trí tuyệt đối cho thẻ div dựa trên vị trí của đoạn văn bản được bôi đen
    icon.style.position = "absolute";
    icon.style.left = `${rect.right + window.scrollX}px`;
    icon.style.top = `${rect.top + window.scrollY}px`;
    // Đặt kích thước của thẻ div
    icon.style.width = "20px";
    icon.style.height = "20px";
    // Đặt màu nền cho thẻ div (có thể thay bằng hình ảnh như đã đề cập trước đó)
    icon.style.backgroundColor = "#F5F5F5";
    icon.style.backgroundSize = "cover";
    // Làm cho thẻ div có hình tròn
    icon.style.borderRadius = "40%";
    // Thay đổi con trỏ chuột khi di chuyển lên thẻ div
    icon.style.cursor = "pointer";
    // Đặt chỉ số z-index cao để thẻ div luôn hiển thị trên cùng
    icon.style.zIndex = "99999999";
    // Thêm thẻ div vào body của trang
    document.body.appendChild(icon);

    // Thêm sự kiện onclick cho biểu tượng để hiển thị văn bản đã bôi đen
    icon.onclick = () => showSelectedText(selectedText, rect);
  }
});

function showSelectedText(text, rect) {
  // Xóa bất kỳ thẻ hiển thị văn bản nào đang tồn tại
  removeTextDisplay();

  // Tạo một thẻ div để hiển thị văn bản đã bôi đen
  const displayDiv = document.createElement("div");
  displayDiv.id = "textDisplay";
  displayDiv.style.position = "absolute";
  // Đặt vị trí của thẻ div phía trên đoạn văn bản được bôi đen
  displayDiv.style.left = `${rect.left + window.scrollX}px`;
  displayDiv.style.top = `${rect.top + window.scrollY - 30}px`;
  displayDiv.style.backgroundColor = "white";
  displayDiv.style.border = "1px solid white";
  displayDiv.style.padding = "3px";
  displayDiv.style.color = "gray";
  displayDiv.style.zIndex = "99999999";
  displayDiv.style.fontSize = "10px"; // Chữ nhỏ hơn
  displayDiv.style.opacity = "0.7"; // Chữ mờ hơn

  // Kiểm tra xem đoạn văn bản đã bôi đen có trong data không
  const entry = data.find((item) => item.question.includes(text));
  if (entry) {
    // Nếu có, hiển thị câu trả lời
    displayDiv.textContent = entry.answer;
  } else {
    // Nếu không, hiển thị đoạn văn bản đã bôi đen
    displayDiv.textContent = "Không biết";
  }

  // Thêm thẻ div vào body của trang
  document.body.appendChild(displayDiv);

  // Thêm sự kiện để ẩn văn bản khi nhấp vào bất kỳ chỗ nào khác trên trang
  document.addEventListener("click", hideTextOnClick, true);

  // Xóa biểu tượng sau khi hiển thị văn bản
  const icon = document.getElementById("textScannerIcon");
  if (icon) {
    icon.remove();
  }
}

function hideTextOnClick(event) {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");
  // Nếu thẻ hiển thị văn bản tồn tại và không phải là thẻ được nhấp vào
  if (displayDiv && !displayDiv.contains(event.target)) {
    // Xóa thẻ hiển thị văn bản
    removeTextDisplay();
    // Xóa sự kiện click để ẩn văn bản
    document.removeEventListener("click", hideTextOnClick, true);
  }
}

function removeTextDisplay() {
  // Lấy thẻ hiển thị văn bản
  const displayDiv = document.getElementById("textDisplay");

  // Nếu thẻ hiển thị văn bản tồn tại thì xóa nó
  if (displayDiv) {
    displayDiv.remove();
  }
}
